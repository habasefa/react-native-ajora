import { ReactNode } from "react";
import { StyleProp, ViewStyle, TextStyle } from "react-native";
export interface OnUploadProps {
    file: {
        fileUri: string;
        displayName: string;
        mimeType: string;
    };
    onProgress?: (progress: number, isUploaded?: boolean) => void;
    onSuccess?: (uploadedUrl: string) => void;
    onError?: (error: any) => void;
}
export interface ActionsProps {
    options?: {
        [key: string]: () => void;
    };
    optionTintColor?: string;
    icon?: () => ReactNode;
    wrapperStyle?: StyleProp<ViewStyle>;
    iconTextStyle?: StyleProp<TextStyle>;
    containerStyle?: StyleProp<ViewStyle>;
    onPressActionButton?(): void;
    onUpload?(props: OnUploadProps): Promise<void>;
}
export declare function Actions({ options, optionTintColor: _optionTintColor, icon: _icon, wrapperStyle: _wrapperStyle, iconTextStyle, onPressActionButton, onUpload, }: ActionsProps): import("react").JSX.Element;
