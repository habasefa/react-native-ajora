import React from "react";
import { Actions } from "../Actions";
import Bubble from "../Bubble";
import { Composer } from "../Composer";
import { LoadEarlier } from "../LoadEarlier";
import Message from "../Message";
import MessageContainer from "../MessageContainer";
import { MessageImage } from "../MessageImage";
import { MessageText } from "../MessageText";
import { IMessage } from "../types";
import { Send } from "../Send";
import * as utils from "../utils";
import { AjoraProps } from "./types";
import { InputToolbar } from "../InputToolbar";
declare function AjoraWrapper<TMessage extends IMessage = IMessage>(props: AjoraProps<TMessage>): React.JSX.Element;
declare namespace AjoraWrapper {
    var append: <TMessage extends IMessage>(currentMessages: TMessage[] | undefined, messages: TMessage[]) => TMessage[];
    var prepend: <TMessage extends IMessage>(currentMessages: TMessage[] | undefined, messages: TMessage[]) => TMessage[];
}
export * from "../types";
export { AjoraWrapper as Ajora, Actions, Bubble, MessageImage, MessageText, Composer, InputToolbar, LoadEarlier, Message, MessageContainer, Send, utils, };
