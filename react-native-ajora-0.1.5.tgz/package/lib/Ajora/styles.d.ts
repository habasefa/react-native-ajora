declare const _default: {
    contentContainer: {
        flex: number;
        overflow: "hidden";
        backgroundColor: "#F9FAFB";
    };
    container: {
        shadowColor: "#000000";
        shadowOffset: {
            readonly width: 0;
            readonly height: 1;
        };
        shadowOpacity: 0.05;
        shadowRadius: 2;
        elevation: 2;
        backgroundColor: "#FFFFFF";
        borderRadius: 8;
        borderWidth: number;
        borderColor: "#E5E7EB";
    };
    surface: {
        backgroundColor: "#F3F4F6";
        borderRadius: 8;
    };
    border: {
        borderWidth: number;
        borderColor: "#E5E7EB";
    };
    rounded: {
        borderRadius: 8;
    };
    roundedLg: {
        borderRadius: 8;
    };
    roundedXl: {
        borderRadius: 12;
    };
};
export default _default;
