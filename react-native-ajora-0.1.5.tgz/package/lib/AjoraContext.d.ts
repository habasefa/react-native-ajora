import { ActionSheetOptions } from "@expo/react-native-action-sheet";
import { Ajora } from "./hooks/useAjora";
export interface IAjoraContext {
    actionSheet(): {
        showActionSheetWithOptions: (options: ActionSheetOptions, callback: (buttonIndex?: number) => void | Promise<void>) => void;
    };
    getLocale(): string;
    getTimezone(): string;
    ajora: Ajora;
}
export declare const AjoraContext: import("react").Context<IAjoraContext>;
export declare const useChatContext: () => IAjoraContext;
