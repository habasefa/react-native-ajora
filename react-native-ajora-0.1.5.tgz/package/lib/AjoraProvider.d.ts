import React, { ReactNode } from "react";
import { Ajora } from "./hooks/useAjora";
interface AjoraProviderProps {
    children: ReactNode;
    ajora: Ajora;
}
export declare const AjoraProvider: React.FC<AjoraProviderProps>;
export {};
