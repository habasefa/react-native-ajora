declare const styles: {
    left: {
        container: {
            alignItems: "flex-start";
        };
        wrapper: {
            borderRadius: 16;
            backgroundColor: string;
            marginRight: number;
            minHeight: number;
            justifyContent: "flex-end";
            paddingHorizontal: 16;
            paddingVertical: 8;
        };
        containerToNext: {
            borderBottomLeftRadius: 8;
        };
        containerToPrevious: {
            borderTopLeftRadius: 8;
        };
        bottom: {
            flexDirection: "row";
            justifyContent: "flex-start";
        };
    };
    right: {
        container: {
            alignItems: "flex-end";
        };
        wrapper: {
            shadowColor: "#000000";
            shadowOffset: {
                readonly width: 0;
                readonly height: 2;
            };
            shadowOpacity: 0.1;
            shadowRadius: 4;
            elevation: 3;
            borderRadius: 16;
            backgroundColor: "#4095E5";
            borderWidth: number;
            borderColor: "#4095E5";
            marginLeft: number;
            minHeight: number;
            justifyContent: "flex-end";
            paddingHorizontal: 16;
            paddingVertical: 12;
        };
        containerToNext: {
            borderBottomRightRadius: 8;
        };
        containerToPrevious: {
            borderTopRightRadius: 8;
        };
        bottom: {
            flexDirection: "row";
            justifyContent: "flex-end";
        };
    };
    content: {
        tick: {
            fontSize: number;
            backgroundColor: string;
            color: "#FFFFFF";
            fontWeight: "500";
        };
        tickView: {
            flexDirection: "row";
            marginRight: 16;
            alignItems: "center";
        };
    };
};
export default styles;
