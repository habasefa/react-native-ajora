declare const _default: {
    textInput: {
        marginLeft: number;
        fontSize: number;
        lineHeight: number;
        color: "#1F2937";
        backgroundColor: "#F9FAFB";
    };
};
export default _default;
