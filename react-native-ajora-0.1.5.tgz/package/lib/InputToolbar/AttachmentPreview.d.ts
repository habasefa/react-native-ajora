import React from "react";
interface AttachmentPreviewProps {
    renderAttachment?: () => React.ReactNode;
}
export declare function AttachmentPreview({ renderAttachment, }: AttachmentPreviewProps): string | number | boolean | Iterable<React.ReactNode> | React.JSX.Element | null | undefined;
export {};
