declare const _default: {
    container: {
        borderTopWidth: number;
        borderTopColor: "#E5E7EB";
        backgroundColor: "#FFFFFF";
    };
    primary: {
        flexDirection: "row";
        alignItems: "flex-end";
    };
    accessory: {
        height: number;
    };
    composer: {
        borderWidth: number;
        borderColor: "#E5E7EB";
        minHeight: number;
        margin: number;
        borderRadius: number;
        justifyContent: "center";
    };
    actionsContainer: {
        flexDirection: "row";
        justifyContent: "space-between";
    };
};
export default _default;
