import React from "react";
interface LoadingAnimationProps {
    containerStyle?: any;
    dotColor?: string;
    dotSize?: number;
    gap?: number;
}
declare const LoadingAnimation: React.FC<LoadingAnimationProps>;
export default LoadingAnimation;
