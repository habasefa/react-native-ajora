declare const _default: {
    left: {
        container: {
            flexDirection: "row";
            alignItems: "flex-end";
            justifyContent: "flex-start";
            marginLeft: number;
            marginRight: number;
            marginVertical: number;
        };
    };
    right: {
        container: {
            flexDirection: "row";
            alignItems: "flex-end";
            justifyContent: "flex-end";
            marginLeft: number;
            marginRight: number;
            marginVertical: number;
        };
    };
    messageContainer: {
        maxWidth: string;
        minWidth: number;
    };
    messageWrapper: {
        paddingHorizontal: number;
        paddingVertical: number;
    };
    avatar: {
        marginHorizontal: number;
        marginBottom: number;
    };
    timestamp: {
        fontSize: number;
        color: "#6B7280";
        marginTop: number;
        fontWeight: string;
    };
    status: {
        fontSize: number;
        color: "#6B7280";
        marginTop: number;
        fontWeight: string;
    };
};
export default _default;
