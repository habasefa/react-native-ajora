import React from "react";
import { IMessage } from "./types";
export interface MessageActionsProps {
    message: IMessage;
    renderMessageActions?: (props: MessageActionsProps) => React.ReactNode;
    position: "left" | "right";
    onCopy?: (text: string) => void;
    onRegenerate?: (message: IMessage) => void;
}
declare const MessageActions: React.FC<MessageActionsProps>;
export default MessageActions;
