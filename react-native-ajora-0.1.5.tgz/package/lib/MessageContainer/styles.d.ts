declare const _default: {
    containerAlignTop: {
        flexDirection: "row";
        alignItems: "flex-start";
    };
    contentContainerStyle: {
        flexGrow: number;
        justifyContent: "flex-start";
        paddingHorizontal: number;
        paddingVertical: number;
    };
    emptyChatContainerInverted: {
        transform: ({
            scaleY: number;
            scaleX?: undefined;
        } | {
            scaleX: number;
            scaleY?: undefined;
        })[];
    };
    scrollToBottomStyle: {
        opacity: number;
        position: "absolute";
        right: number;
        bottom: number;
        zIndex: number;
        height: number;
        width: number;
        borderRadius: number;
        backgroundColor: "#FFFFFF";
        shadowColor: "#000000";
        shadowOpacity: number;
        shadowOffset: {
            width: number;
            height: number;
        };
        shadowRadius: number;
        elevation: number;
    };
    scrollToBottomIcon: {
        fontSize: number;
        fontWeight: "600";
        color: "#1F2937";
    };
    container: {
        backgroundColor: "#F9FAFB";
        flex: number;
    };
    scrollContainer: {
        backgroundColor: "#F3F4F6";
    };
    messageList: {
        paddingBottom: number;
    };
    loadingContainer: {
        paddingVertical: number;
        alignItems: "center";
    };
    emptyState: {
        flex: number;
        justifyContent: "center";
        alignItems: "center";
        paddingHorizontal: number;
    };
    emptyStateText: {
        fontSize: number;
        color: "#6B7280";
        textAlign: "center";
        marginTop: number;
    };
    emptyChatContainer: {
        flex: number;
        height: number;
        justifyContent: "center";
        alignItems: "center";
        paddingHorizontal: number;
        gap: number;
    };
    emptyChatContent: {
        alignItems: "center";
        marginBottom: number;
        flex: number;
        justifyContent: "center";
    };
    emptyChatIcon: {
        marginBottom: number;
    };
    emptyChatTitle: {
        fontSize: number;
        fontWeight: "600";
        color: "#1F2937";
        marginBottom: number;
        textAlign: "center";
    };
    emptyChatSubtitle: {
        fontSize: number;
        color: "#6B7280";
        textAlign: "center";
        lineHeight: number;
    };
    suggestedQuestionsContainer: {
        width: "100%";
        maxWidth: number;
    };
    suggestedQuestionsTitle: {
        fontSize: number;
        fontWeight: "700";
        color: "#111827";
        marginBottom: number;
        textAlign: "center";
        letterSpacing: number;
    };
    suggestedQuestionsRow: {
        flexDirection: "row";
        paddingHorizontal: number;
    };
    suggestedQuestionCard: {
        width: number;
        height: number;
        backgroundColor: "#F3F4F6";
        paddingHorizontal: number;
        paddingVertical: number;
        borderRadius: number;
        borderWidth: number;
        borderColor: "#E5E7EB";
        marginRight: number;
        alignItems: "center";
        justifyContent: "center";
    };
    suggestedQuestionIcon: {
        marginBottom: number;
    };
    suggestedQuestionTitle: {
        fontSize: number;
        fontWeight: "700";
        color: "#6B7280";
        textAlign: "center";
        marginBottom: number;
        textTransform: "uppercase";
        letterSpacing: number;
    };
    suggestedQuestionText: {
        fontSize: number;
        fontWeight: "500";
        color: "#111827";
        textAlign: "center";
        lineHeight: number;
        letterSpacing: number;
    };
};
export default _default;
