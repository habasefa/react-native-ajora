import React from "react";
import { ViewStyle, StyleProp, ViewProps } from "react-native";
import { IMessage } from "./types";
export interface MessageFileProps<TMessage extends IMessage> {
    currentMessage: TMessage;
    containerStyle?: StyleProp<ViewStyle>;
    fileProps?: Partial<ViewProps>;
    onPress?: () => void;
    onDownload?: () => void;
    onOpen?: () => void;
}
export declare function MessageFile<TMessage extends IMessage = IMessage>({ containerStyle, fileProps, currentMessage, onPress, onDownload, onOpen, }: MessageFileProps<TMessage>): React.JSX.Element | null;
