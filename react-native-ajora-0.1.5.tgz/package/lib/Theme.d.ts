export declare const colors: {
    readonly appPrimary: "#4095E5";
    readonly appSecondary: "#F3F4F6";
    readonly text: "#1F2937";
    readonly primaryText: "#111827";
    readonly secondaryText: "#6B7280";
    readonly background: "#F9FAFB";
    readonly white: "#FFFFFF";
    readonly success: "#10B981";
    readonly error: "#EF4444";
    readonly warning: "#F59E0B";
    readonly border: "#E5E7EB";
    readonly shadow: "#000000";
    readonly darkGrey: "#4B5563";
};
export declare const typography: {
    readonly getScaledFontSize: (size: number) => number;
    readonly sizes: {
        readonly xs: 12;
        readonly sm: 14;
        readonly base: 16;
        readonly lg: 18;
        readonly xl: 20;
        readonly "2xl": 24;
        readonly "3xl": 28;
        readonly "4xl": 32;
    };
    readonly weights: {
        readonly normal: "400";
        readonly medium: "500";
        readonly semibold: "600";
        readonly bold: "700";
    };
};
export declare const spacing: {
    readonly xs: 4;
    readonly sm: 8;
    readonly md: 12;
    readonly base: 16;
    readonly lg: 24;
    readonly xl: 32;
    readonly "2xl": 40;
    readonly "3xl": 48;
};
export declare const borderRadius: {
    readonly sm: 8;
    readonly base: 12;
    readonly lg: 16;
    readonly xl: 24;
    readonly full: 9999;
};
export declare const shadows: {
    readonly sm: {
        readonly shadowColor: "#000000";
        readonly shadowOffset: {
            readonly width: 0;
            readonly height: 1;
        };
        readonly shadowOpacity: 0.05;
        readonly shadowRadius: 2;
        readonly elevation: 2;
    };
    readonly base: {
        readonly shadowColor: "#000000";
        readonly shadowOffset: {
            readonly width: 0;
            readonly height: 2;
        };
        readonly shadowOpacity: 0.1;
        readonly shadowRadius: 4;
        readonly elevation: 3;
    };
    readonly lg: {
        readonly shadowColor: "#000000";
        readonly shadowOffset: {
            readonly width: 0;
            readonly height: 4;
        };
        readonly shadowOpacity: 0.15;
        readonly shadowRadius: 8;
        readonly elevation: 5;
    };
};
