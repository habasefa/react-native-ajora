import React from "react";
import { TypingIndicatorProps } from "./types";
export * from "./types";
declare const TypingIndicator: ({ isThinking }: TypingIndicatorProps) => React.JSX.Element | null;
export default TypingIndicator;
