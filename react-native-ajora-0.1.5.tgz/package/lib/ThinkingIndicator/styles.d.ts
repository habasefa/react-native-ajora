declare const _default: {
    container: {
        marginLeft: number;
        width: number;
        borderRadius: number;
        backgroundColor: string;
        paddingHorizontal: number;
        paddingVertical: number;
    };
    dots: {
        flexDirection: "row";
        justifyContent: "center";
        alignItems: "center";
    };
    wrapper: {
        flexDirection: "row";
        alignItems: "center";
        paddingHorizontal: number;
    };
    text: {
        fontSize: number;
        color: "#6B7280";
        marginLeft: number;
        fontWeight: "400";
    };
};
export default _default;
