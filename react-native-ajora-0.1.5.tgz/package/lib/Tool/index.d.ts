import React from "react";
import { IMessage } from "../types";
import { MessageToolCallProps } from "./types";
export declare function MessageToolCall<TMessage extends IMessage = IMessage>({ currentMessage, position, containerStyle, tools, }: MessageToolCallProps<TMessage>): (React.JSX.Element | null)[] | null;
