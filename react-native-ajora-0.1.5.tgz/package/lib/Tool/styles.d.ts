declare const _default: {
    container: {
        width: number;
    };
    leftContainer: {};
    rightContainer: {};
    toolCallHeader: {
        flexDirection: "row";
        alignItems: "center";
        marginBottom: number;
    };
    toolIcon: {
        marginRight: number;
        fontSize: number;
    };
    toolName: {
        fontSize: number;
        fontWeight: "600";
        color: "#1F2937";
    };
    argsContainer: {
        width: number;
        backgroundColor: string;
        padding: number;
        borderRadius: number;
        borderColor: "#E5E7EB";
        marginBottom: number;
        shadowColor: "#000000";
        shadowOffset: {
            width: number;
            height: number;
        };
        shadowOpacity: number;
        shadowRadius: number;
        elevation: number;
    };
    argsText: {
        fontSize: number;
        color: "#1F2937";
        lineHeight: number;
        fontWeight: "600";
    };
    argsSubText: {
        fontSize: number;
        color: "#4B5563";
        lineHeight: number;
        marginTop: number;
        fontFamily: string;
    };
    responseContainer: {
        width: number;
        padding: number;
        backgroundColor: string;
        borderRadius: number;
        borderColor: "#E5E7EB";
        shadowColor: "#000000";
        shadowOffset: {
            width: number;
            height: number;
        };
        shadowOpacity: number;
        shadowRadius: number;
        elevation: number;
    };
    responseText: {
        fontSize: number;
        color: "#111827";
        fontWeight: "300";
        fontStyle: "italic";
        lineHeight: number;
    };
    toolCallWrapper: {
        backgroundColor: string;
        borderRadius: number;
        borderColor: "#E5E7EB";
        shadowColor: "#000000";
        shadowOffset: {
            width: number;
            height: number;
        };
        shadowOpacity: number;
        shadowRadius: number;
        elevation: number;
    };
    toolCallContent: {
        padding: number;
    };
    toolCallTitle: {
        fontSize: number;
        fontWeight: "600";
        color: "#1F2937";
        marginBottom: number;
    };
    toolCallDescription: {
        fontSize: number;
        color: "#4B5563";
        lineHeight: number;
    };
};
export default _default;
