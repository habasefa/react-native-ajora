import { IMessage } from "./types";
import { SourceProps } from "./source/types";
import { SuggestionProps } from "./suggestion/types";
import { Thread } from "./Thread/types";
export interface ApiConfig {
    baseUrl: string;
    bearerToken?: string;
    debug?: boolean;
}
export type UserEvent = {
    type: "text";
    message: IMessage;
    mode?: string;
} | {
    type: "attachement";
    message: IMessage;
    mode?: string;
} | {
    type: "function_response";
    message: IMessage;
    mode?: string;
} | {
    type: "regenerate";
    message: IMessage;
    mode?: string;
} | {
    type: "tool_confirmation";
    message: IMessage;
};
export interface MessageEvent {
    type: "message";
    message: IMessage;
}
export interface FunctionResponseEvent {
    type: "function_response";
    message: IMessage;
}
export interface ThreadTitleEvent {
    type: "thread_title";
    threadTitle: string | Thread;
}
export interface SourcesEvent {
    type: "sources";
    sources: SourceProps[];
}
export interface SuggestionsEvent {
    type: "suggestions";
    suggestions: SuggestionProps[];
}
export interface IsThinkingEvent {
    type: "is_thinking";
    is_thinking: boolean;
}
export interface CompleteEvent {
    type: "complete";
    is_complete: boolean;
}
export interface ErrorEvent {
    type: "error";
    error: {
        thread_id: string;
        message_id: string;
        error: string;
    };
}
export type AgentEvent = MessageEvent | FunctionResponseEvent | ThreadTitleEvent | SourcesEvent | SuggestionsEvent | IsThinkingEvent | CompleteEvent | ErrorEvent;
export interface StreamResponseOptions {
    onOpen?: () => void;
    onChunk: (chunk: AgentEvent) => void;
    onFunctionResponse: (functionResponse: FunctionResponseEvent) => void;
    onThreadTitle: (threadTitle: ThreadTitleEvent) => void;
    onSources: (sources: SourcesEvent) => void;
    onSuggestions: (suggestions: SuggestionsEvent) => void;
    onComplete: (complete: AgentEvent) => void;
    onIsThinking: (isThinking: IsThinkingEvent) => void;
    onError: (error: ErrorEvent) => void;
    abortSignal?: AbortSignal;
}
export declare class ApiService {
    private config;
    private eventSource;
    constructor(config: ApiConfig);
    private get apiBase();
    private get streamBase();
    /**
     * Stream a response from the API using Server-Sent Events
     */
    streamResponse(query: UserEvent, options: StreamResponseOptions): () => void;
    private close;
    getMessages(threadId: string, limit?: number, offset?: number): Promise<{
        messages: IMessage[];
        pagination: {
            total: number;
            limit?: number;
            offset: number;
            hasMore: boolean;
        };
    }>;
    updateConfig(newConfig: Partial<ApiConfig>): void;
    getConfig(): ApiConfig;
}
export declare const defaultApiService: ApiService;
export declare const streamResponse: (query: UserEvent, options: StreamResponseOptions) => () => void;
export default ApiService;
