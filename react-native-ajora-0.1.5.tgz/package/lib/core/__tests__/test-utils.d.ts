import { Message } from "@ag-ui/client";
import { DynamicSuggestionsConfig, FrontendTool } from "../types";
export interface MockAgentOptions {
    messages?: Message[];
    newMessages?: Message[];
    error?: Error | string;
    runAgentDelay?: number;
    runAgentCallback?: (input: any) => void;
    agentId?: string;
    threadId?: string;
    state?: Record<string, any>;
}
export declare class MockAgent {
    messages: Message[];
    state: Record<string, any>;
    agentId?: string;
    threadId?: string;
    addMessages: any;
    addMessage: any;
    abortRun: any;
    clone: any;
    private newMessages;
    private error?;
    private runAgentDelay;
    runAgentCallback?: (input: any) => void;
    runAgentCalls: any[];
    private _parentAgent?;
    constructor(options?: MockAgentOptions);
    runAgent(input: any, subscriber?: any): Promise<{
        newMessages: Message[];
    }>;
    private _cloneImpl;
    subscribe(_subscriber?: any): {
        unsubscribe: () => void;
    };
    setNewMessages(messages: Message[]): void;
}
export declare function createMessage(overrides?: Partial<Message>): Message;
export declare function createAssistantMessage(overrides?: Partial<Message>): Message;
export declare function createToolCallMessage(toolCallName: string, args?: any, overrides?: Partial<Message>): Message;
export declare function createToolResultMessage(toolCallId: string, content: string, overrides?: Partial<Message>): Message;
export declare function createTool<T extends Record<string, unknown>>(overrides?: Partial<FrontendTool<T>>): FrontendTool<T>;
export declare function createMultipleToolCallsMessage(toolCalls: Array<{
    name: string;
    args?: any;
}>, overrides?: Partial<Message>): Message;
export declare function waitForCondition(condition: () => boolean, timeout?: number, interval?: number): Promise<void>;
/**
 * Retry a callback until it stops throwing, similar to @testing-library waitFor.
 */
export declare function waitFor(callback: () => void | Promise<void>, { timeout, interval }?: {
    timeout?: number;
    interval?: number;
}): Promise<void>;
/**
 * Helper to create a dynamic suggestions config
 */
export declare function createSuggestionsConfig(overrides?: Partial<DynamicSuggestionsConfig>): DynamicSuggestionsConfig;
/**
 * Helper to create a tool call message for ajoraSuggest
 */
export declare function createSuggestionToolCall(suggestions: Array<{
    title: string;
    message: string;
}>, overrides?: Partial<Message>): Message;
/**
 * Helper to create streaming suggestion messages with partial JSON
 * Returns an array of JSON chunks that can be assembled into complete suggestions
 */
export declare function createStreamingSuggestionChunks(): string[];
