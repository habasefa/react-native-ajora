import { BaseEvent, HttpAgent, HttpAgentConfig, Message, RunAgentInput, RunAgentResult, AgentSubscriber, RunAgentParameters } from "@ag-ui/client";
import { Observable } from "rxjs";
import { AjoraRuntimeTransport } from "./types";
import { AjoraCoreErrorCode } from "./core/core-types";
export interface ProxiedAjoraRuntimeAgentConfig extends Omit<HttpAgentConfig, "url"> {
    runtimeUrl?: string;
    transport?: AjoraRuntimeTransport;
}
export interface FetchHistoryRequest {
    threadId: string;
    /** Cursor: return messages that appear BEFORE this message id. */
    beforeMessageId?: string;
    /** Page size (default 50, server clamps to [1, 200]). */
    limit?: number;
    /** Optional signal to abort the request (e.g. on thread switch). */
    signal?: AbortSignal;
}
export interface FetchHistoryResponse {
    /** Messages ordered oldest → newest. */
    messages: Message[];
    /** Whether more messages exist before `oldestMessageId`. */
    hasMore: boolean;
    /** Cursor to pass as `beforeMessageId` for the next "load earlier" page. */
    oldestMessageId: string | null;
}
export interface ThreadRecord {
    id: string;
    title: string;
    resource_id: string;
    created_at: string;
    updated_at: string;
}
export interface CreateThreadRequest {
    title?: string;
    subject?: string;
    userId?: string | number;
    id?: string;
    modelId?: string;
    agentId?: string;
    signal?: AbortSignal;
}
export interface ListThreadsRequest {
    resourceId: string;
    cursor?: string;
    limit?: number;
    signal?: AbortSignal;
}
export interface ListThreadsResponse {
    threads: ThreadRecord[];
    nextCursor: string | null;
    hasMore: boolean;
}
export declare class FetchHistoryError extends Error {
    readonly status: number;
    readonly code: AjoraCoreErrorCode;
    /** Milliseconds until the client should retry (from Retry-After header). Null if not rate-limited. */
    readonly retryAfterMs: number | null;
    constructor(message: string, status: number, retryAfterMs?: number | null);
    /**
     * Parse the Retry-After response header into milliseconds.
     * Handles both `Retry-After: <seconds>` and `Retry-After: <HTTP-date>`.
     * Returns null if the header is missing or unparseable.
     */
    static parseRetryAfter(headers: Headers): number | null;
    private static statusToCode;
}
export declare class ProxiedAjoraRuntimeAgent extends HttpAgent {
    runtimeUrl?: string;
    private transport;
    private singleEndpointUrl?;
    constructor(config: ProxiedAjoraRuntimeAgentConfig);
    abortRun(): Promise<boolean>;
    connect(input: RunAgentInput): Observable<BaseEvent>;
    /**
     * Hard cap on how long we'll wait for `agent/connect` to finish. The
     * underlying `super.connectAgent` awaits `lastValueFrom` on the SSE
     * pipeline, which only resolves when the stream completes (server closes
     * or emits a terminal event). If the server holds the stream open — a
     * common dev-server bug, especially for empty threads where there's
     * nothing to send — `isRunning` stays `true` indefinitely, which locks
     * the chat input into "processing" mode and gives the appearance of a
     * frozen UI.
     *
     * After this timeout we abort the underlying fetch and forcibly clear
     * `isRunning` so the agent is usable again. The next `runAgent` call
     * creates a fresh AbortController (per @ag-ui/client semantics), so
     * aborting here doesn't poison subsequent runs.
     */
    private static readonly CONNECT_TIMEOUT_MS;
    connectAgent(parameters?: RunAgentParameters, subscriber?: AgentSubscriber): Promise<RunAgentResult>;
    run(input: RunAgentInput): Observable<BaseEvent>;
    /**
     * Fetch persisted messages for a thread from the runtime's history endpoint.
     *
     * Unlike `connect()`/`run()`, this is a plain JSON POST (not SSE) and does
     * not feed events into the agent's internal `apply` pipeline. The caller
     * (typically `AjoraCore.loadHistory`) decides how to merge the returned
     * messages into the in-memory `messages` array.
     *
     * Throws `FetchHistoryError` for any non-2xx response so the caller can
     * surface auth failures (401/403) distinctly from network errors.
     */
    fetchHistory(request: FetchHistoryRequest): Promise<FetchHistoryResponse>;
    /**
     * Derive the base URL for thread management endpoints.
     *
     * For the single-endpoint transport the runtimeUrl IS the single route,
     * so we strip the last path segment to get the server origin/base.
     * For REST transport the runtimeUrl is already the server base.
     */
    private get threadsBaseUrl();
    /**
     * Create a new thread on the server.
     */
    createThread(request: CreateThreadRequest): Promise<ThreadRecord>;
    /**
     * List threads for a given resource (user).
     */
    listThreads(request: ListThreadsRequest): Promise<ListThreadsResponse>;
    clone(): ProxiedAjoraRuntimeAgent;
    private createSingleRouteRequestInit;
}
