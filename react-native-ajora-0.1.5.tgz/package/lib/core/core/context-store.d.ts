import { Context } from "@ag-ui/client";
import type { AjoraCoreFriendsAccess } from "./core-types";
/**
 * Manages context storage and lifecycle for AjoraCore.
 * Context represents additional information available to agents during execution.
 */
export declare class ContextStore {
    private core;
    private _context;
    constructor(core: AjoraCoreFriendsAccess);
    /**
     * Get all context entries as a readonly record
     */
    get context(): Readonly<Record<string, Context>>;
    /**
     * Add a new context entry
     * @returns The ID of the created context entry
     */
    addContext({ description, value }: Context): string;
    /**
     * Remove a context entry by ID
     */
    removeContext(id: string): void;
    /**
     * Notify all subscribers of context changes
     */
    private notifySubscribers;
}
