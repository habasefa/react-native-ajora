import { AbstractAgent, Context, State } from "@ag-ui/client";
import type { RuntimeModelInfo } from "../../shared";
import { FrontendTool, SuggestionsConfig, AjoraRuntimeTransport } from "../types";
import { AjoraCoreAddAgentParams } from "./agent-registry";
import { AjoraCoreGetSuggestionsResult } from "./suggestion-engine";
export type { AjoraCoreGetSuggestionsResult };
import { AjoraCoreRunAgentParams, AjoraCoreConnectAgentParams, AjoraCoreLoadHistoryParams, AjoraCoreGetToolParams } from "./run-handler";
import { type FetchHistoryResponse, type CreateThreadRequest, type ListThreadsRequest, type ListThreadsResponse, type ThreadRecord } from "../agent";
import { AjoraCoreRuntimeConnectionStatus, AjoraCoreSubscriber, AjoraCoreSubscription } from "./core-types";
export { AjoraCoreErrorCode, AjoraCoreRuntimeConnectionStatus, AjoraCoreFriendsAccess, AjoraCoreSubscriber, AjoraCoreSubscription, } from "./core-types";
/** Configuration options for `AjoraCore`. */
export interface AjoraCoreConfig {
    /** The endpoint of the AjoraRuntime. */
    runtimeUrl?: string;
    /** Transport style for AjoraRuntime endpoints. Defaults to REST. */
    runtimeTransport?: AjoraRuntimeTransport;
    /** Mapping from agent name to its `AbstractAgent` instance. For development only - production requires AjoraRuntime. */
    agents__unsafe_dev_only?: Record<string, AbstractAgent>;
    /** Headers appended to every HTTP request made by `AjoraCore`. */
    headers?: Record<string, string>;
    /** Properties sent as `forwardedProps` to the AG-UI agent. */
    properties?: Record<string, unknown>;
    /** Ordered collection of frontend tools available to the core. */
    tools?: FrontendTool<any>[];
    /** Suggestions config for the core. */
    suggestionsConfig?: SuggestionsConfig[];
}
export type { AjoraCoreAddAgentParams };
export type { AjoraCoreRunAgentParams, AjoraCoreConnectAgentParams, AjoraCoreLoadHistoryParams, AjoraCoreGetToolParams, };
export type { FetchHistoryResponse, ThreadRecord, CreateThreadRequest, ListThreadsRequest, ListThreadsResponse, } from "../agent";
export interface AjoraCoreStopAgentParams {
    agent: AbstractAgent;
}
export declare class AjoraCore {
    private _headers;
    private _properties;
    private subscribers;
    private agentRegistry;
    private contextStore;
    private suggestionEngine;
    private runHandler;
    private stateManager;
    constructor({ runtimeUrl, runtimeTransport, headers, properties, agents__unsafe_dev_only, tools, suggestionsConfig, }: AjoraCoreConfig);
    /**
     * Internal method used by delegate classes and subclasses to notify subscribers
     */
    protected notifySubscribers(handler: (subscriber: AjoraCoreSubscriber) => void | Promise<void>, errorMessage: string): Promise<void>;
    /**
     * Internal method used by delegate classes to emit errors
     */
    private emitError;
    /**
     * Snapshot accessors
     */
    get context(): Readonly<Record<string, Context>>;
    get agents(): Readonly<Record<string, AbstractAgent>>;
    get tools(): Readonly<FrontendTool<any>[]>;
    get runtimeUrl(): string | undefined;
    setRuntimeUrl(runtimeUrl: string | undefined): void;
    get runtimeTransport(): AjoraRuntimeTransport;
    setRuntimeTransport(runtimeTransport: AjoraRuntimeTransport): void;
    get runtimeVersion(): string | undefined;
    get headers(): Readonly<Record<string, string>>;
    get properties(): Readonly<Record<string, unknown>>;
    get runtimeConnectionStatus(): AjoraCoreRuntimeConnectionStatus;
    get models(): Readonly<RuntimeModelInfo[]>;
    get extraData(): Readonly<Record<string, unknown>>;
    /**
     * Configuration updates
     */
    setHeaders(headers: Record<string, string>): void;
    setProperties(properties: Record<string, unknown>): void;
    /**
     * Agent management (delegated to AgentRegistry)
     */
    setAgents__unsafe_dev_only(agents: Record<string, AbstractAgent>): void;
    addAgent__unsafe_dev_only(params: AjoraCoreAddAgentParams): void;
    removeAgent__unsafe_dev_only(id: string): void;
    getAgent(id: string): AbstractAgent | undefined;
    /**
     * Context management (delegated to ContextStore)
     */
    addContext(context: Context): string;
    removeContext(id: string): void;
    /**
     * Suggestions management (delegated to SuggestionEngine)
     */
    addSuggestionsConfig(config: SuggestionsConfig): string;
    removeSuggestionsConfig(id: string): void;
    reloadSuggestions(agentId: string): void;
    clearSuggestions(agentId: string): void;
    getSuggestions(agentId: string): AjoraCoreGetSuggestionsResult;
    /**
     * Tool management (delegated to RunHandler)
     */
    addTool<T extends Record<string, unknown> = Record<string, unknown>>(tool: FrontendTool<T>): void;
    removeTool(id: string, agentId?: string): void;
    getTool(params: AjoraCoreGetToolParams): FrontendTool<any> | undefined;
    setTools(tools: FrontendTool<any>[]): void;
    /**
     * Subscription lifecycle
     */
    subscribe(subscriber: AjoraCoreSubscriber): AjoraCoreSubscription;
    /**
     * Agent connectivity (delegated to RunHandler)
     */
    connectAgent(params: AjoraCoreConnectAgentParams): Promise<import("@ag-ui/client").RunAgentResult>;
    stopAgent(params: AjoraCoreStopAgentParams): Promise<boolean>;
    runAgent(params: AjoraCoreRunAgentParams): Promise<import("@ag-ui/client").RunAgentResult>;
    /**
     * Load persisted history for a thread and merge it into the agent's
     * in-memory `messages` array. See {@link RunHandler.loadHistory}.
     */
    loadHistory(params: AjoraCoreLoadHistoryParams): Promise<FetchHistoryResponse>;
    /**
     * Create a new thread on the server. Requires a runtime agent to derive
     * the server base URL and auth headers.
     */
    createThread(agentId: string, request: CreateThreadRequest): Promise<ThreadRecord>;
    /**
     * List threads for a given resource (user) from the server.
     */
    listThreads(agentId: string, request: ListThreadsRequest): Promise<ListThreadsResponse>;
    /**
     * State management (delegated to StateManager)
     */
    getStateByRun(agentId: string, threadId: string, runId: string): State | undefined;
    getRunIdForMessage(agentId: string, threadId: string, messageId: string): string | undefined;
    getRunIdsForThread(agentId: string, threadId: string): string[];
    /**
     * Internal method used by RunHandler to build frontend tools
     */
    private buildFrontendTools;
}
