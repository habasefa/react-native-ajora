import { AbstractAgent, RunAgentResult, Tool } from "@ag-ui/client";
import { type AjoraCoreFriendsAccess } from "./core-types";
import { FrontendTool } from "../types";
import { type FetchHistoryResponse } from "../agent";
export interface AjoraCoreRunAgentParams {
    agent: AbstractAgent;
    /** Optional model ID to forward to the runtime as `model` in forwardedProps */
    modelId?: string;
}
export interface AjoraCoreConnectAgentParams {
    agent: AbstractAgent;
    /** Optional model ID to forward to the runtime as `model` in forwardedProps */
    modelId?: string;
}
export interface AjoraCoreLoadHistoryParams {
    agent: AbstractAgent;
    threadId: string;
    /** Cursor: return messages that appear BEFORE this message id (load earlier). */
    beforeMessageId?: string;
    /** Page size (default 50, server clamps to [1, 200]). */
    limit?: number;
    /** Optional signal to abort the request (e.g. on thread switch). */
    signal?: AbortSignal;
}
export interface AjoraCoreGetToolParams {
    toolName: string;
    agentId?: string;
}
/**
 * Handles agent execution, tool calling, and agent connectivity for AjoraCore.
 * Manages the complete lifecycle of agent runs including tool execution and follow-ups.
 */
export declare class RunHandler {
    private core;
    private _tools;
    constructor(core: AjoraCoreFriendsAccess);
    /**
     * Get all tools as a readonly array
     */
    get tools(): Readonly<FrontendTool<any>[]>;
    /**
     * Initialize with tools
     */
    initialize(tools: FrontendTool<any>[]): void;
    /**
     * Add a tool to the registry
     */
    addTool<T extends Record<string, unknown> = Record<string, unknown>>(tool: FrontendTool<T>): void;
    /**
     * Remove a tool by name and optionally by agentId
     */
    removeTool(id: string, agentId?: string): void;
    /**
     * Get a tool by name and optionally by agentId.
     * If agentId is provided, it will first look for an agent-specific tool,
     * then fall back to a global tool with the same name.
     */
    getTool(params: AjoraCoreGetToolParams): FrontendTool<any> | undefined;
    /**
     * Set all tools at once. Replaces existing tools.
     */
    setTools(tools: FrontendTool<any>[]): void;
    /**
     * Connect an agent (establish initial connection)
     */
    connectAgent({ agent, modelId, }: AjoraCoreConnectAgentParams): Promise<RunAgentResult>;
    /**
     * Load persisted history for a thread and merge it into the agent's
     * in-memory `messages` array.
     *
     * - When `beforeMessageId` is omitted (initial load): replaces the agent's
     *   messages with the fetched page. Existing messages are discarded.
     * - When `beforeMessageId` is provided (load earlier): prepends the fetched
     *   page to the existing messages, deduplicating by id so a stale cursor
     *   never produces duplicates.
     *
     * Returns the raw `FetchHistoryResponse` so the caller can drive pagination
     * UI (`hasMore`, `oldestMessageId`).
     */
    loadHistory({ agent, threadId, beforeMessageId, limit, signal, }: AjoraCoreLoadHistoryParams): Promise<FetchHistoryResponse>;
    /**
     * Run an agent
     */
    runAgent({ agent, modelId, executedToolCallIds, }: AjoraCoreRunAgentParams & {
        executedToolCallIds?: Set<string>;
    }): Promise<RunAgentResult>;
    /**
     * Process agent result and execute tools.
     *
     * `executedToolCallIds` tracks tool call IDs that have already been executed
     * across the entire run chain (including follow-up runs). This prevents
     * duplicate execution if the server sends the same TOOL_CALL_START event
     * twice (e.g. retry/resend after a network hiccup).
     */
    private processAgentResult;
    /**
     * Execute a specific tool
     */
    private executeSpecificTool;
    /**
     * Execute a wildcard tool
     */
    private executeWildcardTool;
    /**
     * Build frontend tools for an agent
     */
    buildFrontendTools(agentId?: string): Tool[];
    /**
     * Create an agent error subscriber
     */
    private createAgentErrorSubscriber;
}
