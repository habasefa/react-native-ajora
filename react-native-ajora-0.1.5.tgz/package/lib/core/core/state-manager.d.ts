import { AbstractAgent, State } from "@ag-ui/client";
import type { AjoraCore } from "./core";
/**
 * Manages state and message tracking by run for AjoraCore.
 * Tracks agent state snapshots and message-to-run associations.
 */
export declare class StateManager {
    private core;
    private stateByRun;
    private messageToRun;
    private agentSubscriptions;
    constructor(core: AjoraCore);
    /**
     * Initialize state tracking for an agent
     */
    initialize(): void;
    /**
     * Subscribe to an agent's events to track state and messages
     */
    subscribeToAgent(agent: AbstractAgent): void;
    /**
     * Unsubscribe from an agent's events
     */
    unsubscribeFromAgent(agentId: string): void;
    /**
     * Get state for a specific run
     * Returns a deep copy to prevent external mutations
     */
    getStateByRun(agentId: string, threadId: string, runId: string): State | undefined;
    /**
     * Get runId associated with a message
     */
    getRunIdForMessage(agentId: string, threadId: string, messageId: string): string | undefined;
    /**
     * Get all states for an agent's thread
     */
    getStatesForThread(agentId: string, threadId: string): Map<string, State>;
    /**
     * Get all run IDs for an agent's thread
     */
    getRunIdsForThread(agentId: string, threadId: string): string[];
    /**
     * Handle run started event
     */
    private handleRunStarted;
    /**
     * Handle run finished event
     */
    private handleRunFinished;
    /**
     * Handle state snapshot event
     */
    private handleStateSnapshot;
    /**
     * Handle state delta event
     */
    private handleStateDelta;
    /**
     * Handle messages snapshot event
     */
    private handleMessagesSnapshot;
    /**
     * Handle new message event
     */
    private handleNewMessage;
    /**
     * Save state for a specific run
     */
    private saveState;
    /**
     * Associate a message with a run
     */
    private associateMessageWithRun;
    /**
     * Clear all state for an agent
     */
    clearAgentState(agentId: string): void;
    /**
     * Clear all state for a thread
     */
    clearThreadState(agentId: string, threadId: string): void;
}
