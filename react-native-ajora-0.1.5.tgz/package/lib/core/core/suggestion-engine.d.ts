import { Message } from "@ag-ui/client";
import type { AjoraCore } from "./core";
import { Suggestion, SuggestionsConfig } from "../types";
export type AjoraCoreGetSuggestionsResult = {
    suggestions: Suggestion[];
    isLoading: boolean;
};
/**
 * Manages suggestion generation, streaming, and lifecycle for AjoraCore.
 * Handles both dynamic (AI-generated) and static suggestions.
 */
export declare class SuggestionEngine {
    private core;
    private _suggestionsConfig;
    private _suggestions;
    private _runningSuggestions;
    constructor(core: AjoraCore);
    /**
     * Initialize with suggestion configs
     */
    initialize(suggestionsConfig: SuggestionsConfig[]): void;
    /**
     * Add a suggestion configuration
     * @returns The ID of the created config
     */
    addSuggestionsConfig(config: SuggestionsConfig): string;
    /**
     * Remove a suggestion configuration by ID
     */
    removeSuggestionsConfig(id: string): void;
    /**
     * Reload suggestions for a specific agent
     * This triggers generation of new suggestions based on current configs
     */
    reloadSuggestions(agentId: string): void;
    /**
     * Clear all suggestions for a specific agent
     */
    clearSuggestions(agentId: string): void;
    /**
     * Get current suggestions for an agent
     */
    getSuggestions(agentId: string): AjoraCoreGetSuggestionsResult;
    /**
     * Generate suggestions using a provider agent
     */
    private generateSuggestions;
    /**
     * Finalize suggestions by marking them as no longer loading
     */
    private finalizeSuggestions;
    /**
     * Extract suggestions from messages (called during streaming)
     */
    extractSuggestions(messages: Message[], suggestionId: string, consumerAgentId: string, isRunning: boolean): void;
    /**
     * Notify subscribers of suggestions config changes
     */
    private notifySuggestionsConfigChanged;
    /**
     * Notify subscribers of suggestions changes
     */
    private notifySuggestionsChanged;
    /**
     * Notify subscribers that suggestions started loading
     */
    private notifySuggestionsStartedLoading;
    /**
     * Notify subscribers that suggestions finished loading
     */
    private notifySuggestionsFinishedLoading;
    /**
     * Check if suggestions should be shown based on availability and message count
     */
    private shouldShowSuggestions;
    /**
     * Add static suggestions directly without AI generation
     */
    private addStaticSuggestions;
}
