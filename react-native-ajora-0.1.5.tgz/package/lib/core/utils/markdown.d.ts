export declare function completePartialMarkdown(input: string): string;
