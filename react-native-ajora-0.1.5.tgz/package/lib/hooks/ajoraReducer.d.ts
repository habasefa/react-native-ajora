import { Thread } from "../Thread/types";
import { IMessage } from "../types";
import { AjoraState, Attachement } from "./useAjora";
export type Action = {
    type: "ADD_MESSAGES";
    payload: {
        messages: IMessage[];
    };
} | {
    type: "ADD_EARLIER_MESSAGES";
    payload: {
        messages: IMessage[];
        threadId: string;
        pagination: any;
    };
} | {
    type: "SET_LOADING_MESSAGES";
    payload: {
        isLoading: boolean;
    };
} | {
    type: "SET_LOADING_EARLIER";
    payload: {
        isLoading: boolean;
    };
} | {
    type: "ADD_PENDING_MESSAGE";
    payload: {
        message: IMessage;
        threadId: string;
    };
} | {
    type: "ADD_FUNCTION_RESPONSE";
    payload: {
        message: IMessage;
    };
} | {
    type: "UPDATE_STREAMING_MESSAGE";
    payload: {
        message: IMessage;
    };
} | {
    type: "UPDATE_THREAD_TITLE";
    payload: {
        thread: Thread;
    };
} | {
    type: "ADD_NEW_THREAD";
} | {
    type: "SWITCH_THREAD";
    payload: {
        threadId: string;
    };
} | {
    type: "SET_THINKING";
    payload: {
        isThinking: boolean;
    };
} | {
    type: "SET_LOADING_EARLIER";
    payload: {
        loadEarlier: boolean;
    };
} | {
    type: "SET_MODE";
    payload: {
        mode: string;
    };
} | {
    type: "CLEAR_STREAM";
} | {
    type: "REMOVE_MESSAGE";
    payload: {
        messageId: string | number;
        threadId: string;
    };
} | {
    type: "SET_THREADS";
    payload: {
        threads: Thread[];
    };
} | {
    type: "SET_MESSAGES";
    payload: {
        messages: IMessage[];
        threadId: string;
        pagination?: any;
    };
} | {
    type: "SET_COMPLETE";
    payload: {
        isComplete: boolean;
    };
} | {
    type: "SET_ATTACHEMENT";
    payload: {
        attachement: Attachement;
    };
} | {
    type: "UPDATE_ATTACHEMENT";
    payload: {
        attachement: Attachement;
    };
} | {
    type: "SET_IS_RECORDING";
    payload: {
        isRecording: boolean;
    };
} | {
    type: "CLEAR_ATTACHEMENT";
};
export declare const ajoraReducer: (state: AjoraState, action: Action) => AjoraState;
