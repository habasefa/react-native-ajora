import { IMessage } from "../types";
import ApiService, { UserEvent } from "../api";
import { Thread } from "../Thread/types";
import { FileData } from "@google/genai";
interface Messages {
    [key: string]: IMessage[];
}
export interface Attachement extends FileData {
    progress?: number;
    isUploaded?: boolean;
}
export type AjoraState = {
    stream: IMessage[];
    messages: Messages;
    threads: Thread[];
    activeThreadId: string | null;
    isThinking: boolean;
    loadEarlier: boolean;
    isLoadingMessages?: boolean;
    mode: string;
    baseUrl: string;
    apiService: ApiService | null;
    isComplete: boolean;
    attachement: Attachement | undefined;
    isRecording: boolean;
};
export type Ajora = AjoraState & {
    messagesByThread: IMessage[];
    submitQuery: (query: UserEvent) => Promise<void>;
    stopStreaming: () => void;
    addNewThread: () => void;
    switchThread: (threadId: string) => void;
    getMessages: (threadId: string) => void;
    setIsThinking: (isThinking: boolean) => void;
    setIsLoadingEarlier: (loadEarlier: boolean) => void;
    setMode: (mode: string) => void;
    regenerateMessage: (message: IMessage) => void;
    setIsComplete: (isComplete: boolean) => void;
    setAttachement: (attachement: Attachement) => void;
    updateAttachement: (attachement: Attachement) => void;
    clearAttachement: () => void;
    setIsRecording: (isRecording: boolean) => void;
};
declare const useAjora: ({ initialMessages, initialThreads, baseUrl, bearerToken, debug, }: {
    initialMessages?: Record<string, IMessage[]>;
    initialThreads?: Thread[];
    baseUrl?: string;
    bearerToken?: string;
    debug?: boolean;
}) => {
    messagesByThread: IMessage[];
    submitQuery: (query: UserEvent) => Promise<void>;
    stopStreaming: () => void;
    addNewThread: () => void;
    switchThread: (threadId: string) => void;
    getMessages: (threadId: string) => Promise<void>;
    setIsThinking: (isThinking: boolean) => void;
    setIsLoadingEarlier: (loadEarlier: boolean) => void;
    setMode: (mode: string) => void;
    regenerateMessage: (message: IMessage) => void;
    setIsComplete: (isComplete: boolean) => void;
    setAttachement: (attachement: Attachement) => void;
    updateAttachement: (attachement: Attachement) => void;
    clearAttachement: () => void;
    setIsRecording: (isRecording: boolean) => void;
    stream: IMessage[];
    messages: Messages;
    threads: Thread[];
    activeThreadId: string | null;
    isThinking: boolean;
    loadEarlier: boolean;
    isLoadingMessages?: boolean;
    mode: string;
    baseUrl: string;
    apiService: ApiService | null;
    isComplete: boolean;
    attachement: Attachement | undefined;
    isRecording: boolean;
};
export default useAjora;
