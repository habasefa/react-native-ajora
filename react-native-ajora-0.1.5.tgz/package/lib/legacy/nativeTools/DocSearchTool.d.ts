import React from "react";
import { ToolRequest, ToolResponse } from "../Tool/types";
import { UserEvent } from "../api";
import { IMessage } from "../types";
interface DocSearchToolProps {
    message: IMessage;
    request: ToolRequest;
    onResponse?: (response: ToolResponse) => void;
    submitQuery?: (query: UserEvent) => Promise<void>;
}
declare const DocSearchTool: React.FC<DocSearchToolProps>;
export default DocSearchTool;
