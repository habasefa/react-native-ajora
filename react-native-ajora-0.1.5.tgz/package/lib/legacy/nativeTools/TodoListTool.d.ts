import React from "react";
import { ToolRequest, ToolResponse } from "../Tool/types";
import { UserEvent } from "../api";
import { IMessage } from "../types";
interface TodoListToolProps {
    message: IMessage;
    request: ToolRequest;
    onResponse?: (response: ToolResponse) => void;
    submitQuery?: (query: UserEvent) => Promise<void>;
}
declare const TodoListTool: React.FC<TodoListToolProps>;
export default TodoListTool;
