import React from "react";
interface Props {
    text: string;
    isThinking?: boolean;
    textColor?: string;
    fontSize?: number;
    lineHeight?: number;
}
declare const RichText: ({ text, isThinking, textColor: propTextColor, fontSize: propFontSize, lineHeight: propLineHeight, }: Props) => React.JSX.Element;
export default RichText;
