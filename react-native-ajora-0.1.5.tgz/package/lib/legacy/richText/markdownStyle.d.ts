export declare const baseStyles: {
    body: {
        fontSize: number;
    };
    heading1: {
        flexDirection: string;
        fontSize: number;
    };
    heading2: {
        flexDirection: string;
        fontSize: number;
    };
    heading3: {
        flexDirection: string;
        fontSize: number;
    };
    heading4: {
        flexDirection: string;
        fontSize: number;
    };
    heading5: {
        flexDirection: string;
        fontSize: number;
    };
    heading6: {
        flexDirection: string;
        fontSize: number;
    };
    hr: {
        backgroundColor: string;
        height: number;
    };
    strong: {
        fontWeight: string;
    };
    em: {
        fontStyle: string;
    };
    s: {
        textDecorationLine: string;
    };
    blockquote: {
        backgroundColor: string;
        borderColor: string;
        borderLeftWidth: number;
        marginLeft: number;
        paddingHorizontal: number;
    };
    bullet_list: {};
    ordered_list: {};
    list_item: {
        flexDirection: string;
        justifyContent: string;
    };
    bullet_list_icon: {
        marginLeft: number;
        marginRight: number;
    };
    bullet_list_content: {
        flex: number;
    };
    ordered_list_icon: {
        marginLeft: number;
        marginRight: number;
    };
    ordered_list_content: {
        flex: number;
    };
    code_inline: {
        fontFamily?: string | undefined;
        borderWidth: number;
        borderColor: string;
        backgroundColor: string;
        padding: number;
        borderRadius: number;
    };
    code_block: {
        fontFamily?: string | undefined;
        borderWidth: number;
        borderColor: string;
        backgroundColor: string;
        padding: number;
        borderRadius: number;
    };
    fence: {
        fontFamily?: string | undefined;
        borderWidth: number;
        borderColor: string;
        backgroundColor: string;
        padding: number;
        borderRadius: number;
    };
    table: {
        borderWidth: number;
        borderColor: string;
        borderRadius: number;
    };
    thead: {};
    tbody: {};
    th: {
        flex: number;
        padding: number;
    };
    tr: {
        borderBottomWidth: number;
        borderColor: string;
        flexDirection: string;
    };
    td: {
        flex: number;
        padding: number;
    };
    link: {
        textDecorationLine: string;
        color: string;
    };
    blocklink: {
        flex: number;
        borderColor: string;
        borderBottomWidth: number;
        color: string;
    };
    image: {
        flex: number;
    };
    text: {};
    textgroup: {};
    paragraph: {
        marginTop: number;
        marginBottom: number;
        flexWrap: string;
        flexDirection: string;
        alignItems: string;
        justifyContent: string;
        width: string;
    };
    hardbreak: {
        width: string;
        height: number;
    };
    softbreak: {};
    pre: {};
    inline: {};
    span: {};
};
/**
 * Returns a new styles object.
 *
 * @param color - the color to apply to text-based styles
 * @param overrides - an optional object containing style overrides for specific keys
 */
export declare function createMarkdownStyles(color: string, overrides?: Partial<typeof baseStyles>): Record<string, any>;
