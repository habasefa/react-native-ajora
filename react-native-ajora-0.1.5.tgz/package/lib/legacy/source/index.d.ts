import React from "react";
import { SourceProps } from "./types";
declare const Source: ({ id, name, content, url }: SourceProps) => React.JSX.Element;
export default Source;
