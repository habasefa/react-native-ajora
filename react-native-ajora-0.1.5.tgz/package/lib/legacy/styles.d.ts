declare const _default: {
    fill: {
        flex: number;
    };
    centerItems: {
        justifyContent: "center";
        alignItems: "center";
    };
    card: {
        shadowColor: "#000000";
        shadowOffset: {
            readonly width: 0;
            readonly height: 1;
        };
        shadowOpacity: 0.05;
        shadowRadius: 2;
        elevation: 2;
        backgroundColor: "#FFFFFF";
        borderRadius: 8;
        borderWidth: number;
        borderColor: "#E5E7EB";
    };
    surface: {
        backgroundColor: "#F3F4F6";
        borderRadius: 8;
    };
    border: {
        borderWidth: number;
        borderColor: "#E5E7EB";
    };
    rounded: {
        borderRadius: 8;
    };
    roundedLg: {
        borderRadius: 8;
    };
    roundedXl: {
        borderRadius: 12;
    };
    shadow: {
        shadowColor: "#000000";
        shadowOffset: {
            readonly width: 0;
            readonly height: 1;
        };
        shadowOpacity: 0.05;
        shadowRadius: 2;
        elevation: 2;
    };
    shadowMd: {
        shadowColor: "#000000";
        shadowOffset: {
            readonly width: 0;
            readonly height: 2;
        };
        shadowOpacity: 0.1;
        shadowRadius: 4;
        elevation: 3;
    };
};
export default _default;
