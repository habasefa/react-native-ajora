import React from "react";
declare const Suggestion: () => React.JSX.Element;
export default Suggestion;
