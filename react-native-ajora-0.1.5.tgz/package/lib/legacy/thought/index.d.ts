import React from "react";
declare const Thought: () => React.JSX.Element;
export default Thought;
