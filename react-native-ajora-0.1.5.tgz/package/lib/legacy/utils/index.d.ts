import { Thread } from "../Thread/types";
import { IMessage } from "../types";
/**
 * Search for a thread in messages and return the index of the thread
 * @param messages - The messages to search in
 * @param threadId - The id of the thread to search for
 * @returns The index of the thread or undefined if not found
 */
export declare const findThreadInMessages: (messages: IMessage, threadId: string) => string | undefined;
/**
 * Create a default thread
 * @returns The default thread
 */
export declare const createDefaultThread: () => Thread;
/**
 * Merge functionCall and functionResponse messages
 * @param messages - The messages to merge
 * @returns The merged messages
 */
export declare const mergeFunctionCallsAndResponses: (messages: Record<string, IMessage[]> | IMessage[]) => Record<string, IMessage[]> | IMessage[];
