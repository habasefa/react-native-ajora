import { Attachement } from "../hooks/useAjora";
export default function getPermissionAsync(permission: "camera" | "mediaLibrary" | "location"): Promise<boolean>;
export declare function pickImageAsync(onAttachement: (attachement: Attachement) => void): Promise<void>;
export declare function takePictureAsync(onAttachement: (attachement: Attachement) => void): Promise<void>;
export declare function filePickerAsync(onAttachement: (attachement: Attachement) => void): Promise<void>;
export declare function audioPickerAsync(onAttachement: (audios: Attachement) => void): Promise<void>;
