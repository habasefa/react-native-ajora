import React from "react";
import { type MarkdownTheme } from "./markdownStyle";
export interface RichTextProps {
    text: string;
    /** Semantic theme — drives all markdown colors, sizes, and borders. */
    theme?: MarkdownTheme;
    isThinking?: boolean;
    streaming?: boolean;
    onLinkPress?: (url: string) => void;
}
declare const RichText: ({ text, theme: propTheme, isThinking, streaming, onLinkPress: propOnLinkPress, }: RichTextProps) => React.JSX.Element;
export default RichText;
