export interface MarkdownTheme {
    /** Primary text color for headings, paragraphs, lists, etc. */
    textColor: string;
    /** Muted text color (thinking state, secondary info) */
    mutedColor: string;
    /** Background for code blocks and inline code */
    codeBg: string;
    /** Border color shared by code blocks, blockquotes, tables, hr */
    borderColor: string;
    /** Link color */
    linkColor: string;
    /** Base font size for body text */
    fontSize: number;
    /** Base line height for body text */
    lineHeight: number;
}
/** Sensible default for when no theme is provided (visible on any background). */
export declare const DEFAULT_MARKDOWN_THEME: MarkdownTheme;
export interface MarkdownStyle {
    h1?: {
        fontSize?: number;
        fontWeight?: string;
        color?: string;
        marginTop?: number;
        marginBottom?: number;
    };
    h2?: {
        fontSize?: number;
        fontWeight?: string;
        color?: string;
        marginTop?: number;
        marginBottom?: number;
    };
    h3?: {
        fontSize?: number;
        fontWeight?: string;
        color?: string;
        marginTop?: number;
        marginBottom?: number;
    };
    h4?: {
        fontSize?: number;
        fontWeight?: string;
        color?: string;
        marginTop?: number;
        marginBottom?: number;
    };
    h5?: {
        fontSize?: number;
        fontWeight?: string;
        color?: string;
        marginTop?: number;
        marginBottom?: number;
    };
    h6?: {
        fontSize?: number;
        fontWeight?: string;
        color?: string;
        marginTop?: number;
        marginBottom?: number;
    };
    paragraph?: {
        fontSize?: number;
        color?: string;
        marginTop?: number;
        marginBottom?: number;
        lineHeight?: number;
    };
    strong?: {
        fontWeight?: string;
        color?: string;
    };
    emphasis?: {
        fontStyle?: string;
        color?: string;
    };
    strikethrough?: {
        color?: string;
    };
    blockquote?: {
        borderColor?: string;
        borderWidth?: number;
        backgroundColor?: string;
        color?: string;
    };
    list?: {
        bulletColor?: string;
        markerColor?: string;
        gapWidth?: number;
        marginLeft?: number;
        color?: string;
    };
    inlineCode?: {
        fontFamily?: string;
        fontSize?: number;
        color?: string;
        backgroundColor?: string;
        borderColor?: string;
    };
    codeBlock?: {
        fontFamily?: string;
        fontSize?: number;
        color?: string;
        backgroundColor?: string;
        borderColor?: string;
        borderRadius?: number;
        borderWidth?: number;
        padding?: number;
    };
    link?: {
        color?: string;
        underline?: boolean;
    };
    table?: {
        fontSize?: number;
        borderColor?: string;
        borderWidth?: number;
        borderRadius?: number;
        headerBackgroundColor?: string;
        headerFontFamily?: string;
        cellPaddingHorizontal?: number;
        cellPaddingVertical?: number;
    };
    thematicBreak?: {
        color?: string;
        height?: number;
        marginTop?: number;
        marginBottom?: number;
    };
    image?: {
        height?: number;
        borderRadius?: number;
        marginTop?: number;
        marginBottom?: number;
    };
    math?: {
        fontSize?: number;
        color?: string;
        backgroundColor?: string;
        padding?: number;
    };
    inlineMath?: {
        color?: string;
    };
    taskList?: {
        checkedColor?: string;
        borderColor?: string;
        checkmarkColor?: string;
    };
}
/**
 * Derives a full MarkdownStyle from a MarkdownTheme.
 * Every visual token is pulled from the theme — no hardcoded colors.
 */
export declare function createMarkdownStyles(theme: MarkdownTheme, overrides?: Partial<MarkdownStyle>): MarkdownStyle;
