import { AjoraChatView, AjoraChatViewProps } from "./AjoraChatView";
import { AjoraChatLabels } from "../../providers/AjoraChatConfigurationProvider";
import { Suggestion } from "../../../core";
import React from "react";
import { SlotValue } from "../../lib/slots";
export type AjoraChatProps = Omit<AjoraChatViewProps, "messages" | "isRunning" | "suggestions" | "suggestionLoadingIndexes" | "onSelectSuggestion"> & {
    agentId?: string;
    modelId?: string;
    threadId?: string;
    labels?: Partial<AjoraChatLabels>;
    chatView?: SlotValue<typeof AjoraChatView>;
    isModalDefaultOpen?: boolean;
    isLoading?: boolean;
    starterSuggestions?: Suggestion[];
    /** Called when a message is long pressed */
    onMessageLongPress?: (message: any) => void;
    /** Called when an action is performed on a message (copy, edit, etc.) */
    onMessageAction?: (action: "copy" | "edit" | "delete" | "regenerate", message: any) => void;
    /** Called when user starts typing */
    onTypingStart?: () => void;
    /** Called when user stops typing (debounced) */
    onTypingEnd?: () => void;
    /** Called when user scrolls to the top of the chat */
    onScrollToTop?: () => void;
    /** Called when user scrolls to the bottom of the chat */
    onScrollToBottom?: () => void;
    /** Called when an attachment is added */
    onAttachmentAdd?: (attachment: {
        uri: string;
        type: string;
        name?: string;
    }) => void;
    /** Called when an attachment is removed */
    onAttachmentRemove?: (attachmentId: string) => void;
    /** Called when message send fails */
    onSendError?: (error: Error) => void;
    /** Called when a message is successfully sent */
    onSendSuccess?: (message: any) => void;
    /** Renderer applied to both user and assistant messages unless a
        side-specific renderer is provided. */
    textRenderer?: (props: {
        content: string;
    }) => React.ReactNode;
    /** Overrides `textRenderer` for user messages only. */
    userTextRenderer?: (props: {
        content: string;
    }) => React.ReactNode;
    /** Overrides `textRenderer` for assistant messages only. */
    assistantTextRenderer?: (props: {
        content: string;
    }) => React.ReactNode;
};
export declare function AjoraChat({ agentId, modelId, threadId, labels, chatView, isModalDefaultOpen, isLoading, starterSuggestions, ...props }: AjoraChatProps): React.JSX.Element;
export declare namespace AjoraChat {
    const View: typeof AjoraChatView;
}
