import React from "react";
import { StyleProp, ViewStyle } from "react-native";
import { AssistantMessage, Message } from "@ag-ui/core";
import { WithSlots } from "../../lib/slots";
import AjoraChatToolCallsView from "./AjoraChatToolCallsView";
import AjoraChatThoughtsBubble from "./AjoraChatThoughtsBubble";
export type FeedbackType = "thumbsUp" | "thumbsDown" | null;
export type AjoraChatAssistantMessageProps = WithSlots<{
    markdownRenderer: typeof AjoraChatAssistantMessage.MarkdownRenderer;
    toolbar: typeof AjoraChatAssistantMessage.Toolbar;
    copyButton: typeof AjoraChatAssistantMessage.CopyButton;
    thumbsUpButton: typeof AjoraChatAssistantMessage.ThumbsUpButton;
    thumbsDownButton: typeof AjoraChatAssistantMessage.ThumbsDownButton;
    readAloudButton: typeof AjoraChatAssistantMessage.ReadAloudButton;
    regenerateButton: typeof AjoraChatAssistantMessage.RegenerateButton;
    toolCallsView: typeof AjoraChatToolCallsView;
    thoughtsBubble: typeof AjoraChatThoughtsBubble;
}, {
    onThumbsUp?: (message: AssistantMessage) => void;
    onThumbsDown?: (message: AssistantMessage) => void;
    onReadAloud?: (message: AssistantMessage) => void;
    onRegenerate?: (message: AssistantMessage) => void;
    onCopy?: (content: string) => void;
    message: AssistantMessage;
    messages?: Message[];
    isRunning?: boolean;
    additionalToolbarItems?: React.ReactNode;
    toolbarVisible?: boolean;
    /** Custom colors override (highest priority) */
    colors?: AjoraChatAssistantMessageColorsOverride;
    showCopyButton?: boolean;
    showThumbsButtons?: boolean;
    showReadAloudButton?: boolean;
    showRegenerateButton?: boolean;
    textRenderer?: (props: {
        content: string;
    }) => React.ReactNode;
    onLinkPress?: (url: string) => void;
    style?: StyleProp<ViewStyle>;
}>;
export interface AjoraChatAssistantMessageColorsOverride {
    text?: string;
    textSecondary?: string;
    border?: string;
    buttonBackground?: string;
    buttonBackgroundHover?: string;
    buttonBackgroundActive?: string;
    accent?: string;
    success?: string;
    error?: string;
    thumbsUp?: string;
    thumbsDown?: string;
    iconColor?: string;
}
interface AjoraChatAssistantMessageColors {
    text: string;
    textSecondary: string;
    border: string;
    buttonBackground: string;
    buttonBackgroundHover: string;
    buttonBackgroundActive: string;
    accent: string;
    success: string;
    error: string;
    thumbsUp: string;
    thumbsDown: string;
    iconColor: string;
}
export declare function AjoraChatAssistantMessage({ message, messages, isRunning, onThumbsUp, onThumbsDown, onReadAloud, onRegenerate, onCopy, additionalToolbarItems, colors: colorOverrides, toolbarVisible, showCopyButton, showThumbsButtons, showReadAloudButton, showRegenerateButton, markdownRenderer, toolbar, copyButton, thumbsUpButton, thumbsDownButton, readAloudButton, regenerateButton, toolCallsView, thoughtsBubble, textRenderer, onLinkPress, children, style, ...props }: AjoraChatAssistantMessageProps): React.JSX.Element;
export declare namespace AjoraChatAssistantMessage {
    const MarkdownRenderer: React.FC<{
        content: string;
        style?: StyleProp<ViewStyle>;
        streaming?: boolean;
        colors?: AjoraChatAssistantMessageColors;
        textRenderer?: (props: {
            content: string;
        }) => React.ReactNode;
        onLinkPress?: (url: string) => void;
    }>;
    const Toolbar: React.FC<{
        children: React.ReactNode;
        style?: StyleProp<ViewStyle>;
    }>;
    const CopyButton: React.FC<{
        onClick?: () => void;
        copied?: boolean;
        style?: StyleProp<ViewStyle>;
        colors: AjoraChatAssistantMessageColors;
    }>;
    const ThumbsUpButton: React.FC<{
        onClick?: () => void;
        isActive?: boolean;
        style?: StyleProp<ViewStyle>;
        colors: AjoraChatAssistantMessageColors;
    }>;
    const ThumbsDownButton: React.FC<{
        onClick?: () => void;
        isActive?: boolean;
        style?: StyleProp<ViewStyle>;
        colors: AjoraChatAssistantMessageColors;
    }>;
    const ReadAloudButton: React.FC<{
        onClick?: () => void;
        style?: StyleProp<ViewStyle>;
        colors: AjoraChatAssistantMessageColors;
    }>;
    const RegenerateButton: React.FC<{
        onClick?: () => void;
        style?: StyleProp<ViewStyle>;
        colors: AjoraChatAssistantMessageColors;
    }>;
}
export default AjoraChatAssistantMessage;
