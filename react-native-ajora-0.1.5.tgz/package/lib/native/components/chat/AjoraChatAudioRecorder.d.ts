import * as React from "react";
export interface AjoraChatAudioRecorderProps {
    onRecordingComplete: (blob: Blob) => void;
    isRunning?: boolean;
}
/**
 * Placeholder for AjoraChatAudioRecorder in React Native.
 * TODO: Implement native audio recording using a library like `react-native-audio-recorder-player` or `expo-av`.
 */
export declare function AjoraChatAudioRecorder({ onRecordingComplete, isRunning, }: AjoraChatAudioRecorderProps): React.JSX.Element;
export default AjoraChatAudioRecorder;
