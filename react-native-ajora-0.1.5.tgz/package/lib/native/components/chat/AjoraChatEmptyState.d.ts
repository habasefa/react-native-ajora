import * as React from "react";
import { StyleProp, ViewStyle, TextStyle } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { WithSlots } from "../../lib/slots";
import { Suggestion } from "../../../core";
/**
 * Color overrides for the empty state component
 */
export interface AjoraChatEmptyStateColors {
    /** Icon color */
    icon?: string;
    /** Title text color */
    title?: string;
    /** Subtitle text color */
    subtitle?: string;
    /** Suggestion card background color */
    suggestionBackground?: string;
    /** Suggestion card text color */
    suggestionText?: string;
    /** Suggestion card subtitle/description color */
    suggestionSubtitle?: string;
    /** Suggestion card border color */
    suggestionBorder?: string;
    /** Suggestion card icon color */
    suggestionIcon?: string;
    /** Suggestion card icon background color */
    suggestionIconBackground?: string;
    /** Suggestion card arrow color */
    suggestionArrow?: string;
    /** Background color */
    background?: string;
}
/**
 * Supported icon families from @expo/vector-icons (for internal use)
 */
type IconFamily = "Ionicons" | "MaterialIcons" | "MaterialCommunityIcons" | "FontAwesome" | "FontAwesome5" | "FontAwesome6" | "Feather" | "AntDesign" | "Entypo" | "EvilIcons" | "Foundation" | "Octicons" | "SimpleLineIcons" | "Zocial";
export interface AjoraChatEmptyStateIconProps {
    name?: keyof typeof Ionicons.glyphMap;
    size?: number;
    color?: string;
    style?: StyleProp<ViewStyle>;
}
export interface AjoraChatEmptyStateTitleProps {
    children?: React.ReactNode;
    style?: StyleProp<TextStyle>;
}
export interface AjoraChatEmptyStateSubtitleProps {
    children?: React.ReactNode;
    style?: StyleProp<TextStyle>;
}
export interface AjoraChatEmptyStateSuggestionProps {
    suggestion: Suggestion;
    onPress?: (suggestion: Suggestion) => void;
    style?: StyleProp<ViewStyle>;
    textStyle?: StyleProp<TextStyle>;
    colors?: AjoraChatEmptyStateColors;
    /** Override icon name for this suggestion */
    icon?: string;
    /** Override icon family for this suggestion */
    iconFamily?: IconFamily;
    /** Show subtitle/description */
    showDescription?: boolean;
}
export interface AjoraChatEmptyStateSuggestionsProps {
    suggestions?: Suggestion[];
    onSelectSuggestion?: (suggestion: Suggestion) => void;
    style?: StyleProp<ViewStyle>;
    colors?: AjoraChatEmptyStateColors;
}
type EmptyStateSlots = {
    icon: typeof AjoraChatEmptyState.Icon;
    titleContent: typeof AjoraChatEmptyState.Title;
    subtitleContent: typeof AjoraChatEmptyState.Subtitle;
    suggestionsContent: typeof AjoraChatEmptyState.Suggestions;
};
type EmptyStateRestProps = {
    /** Custom icon name */
    iconName?: keyof typeof Ionicons.glyphMap;
    /** Custom title text */
    title?: string;
    /** Custom subtitle text */
    subtitle?: string;
    /** Starter suggestions to show */
    suggestions?: Suggestion[];
    /** Callback when a suggestion is selected */
    onSelectSuggestion?: (suggestion: Suggestion) => void;
    /** Color overrides */
    colors?: AjoraChatEmptyStateColors;
    /** Icon size */
    iconSize?: number;
    /** Container style */
    style?: StyleProp<ViewStyle>;
};
export type AjoraChatEmptyStateProps = WithSlots<EmptyStateSlots, EmptyStateRestProps>;
export declare function AjoraChatEmptyState({ iconName, title, subtitle, suggestions, onSelectSuggestion, colors: colorOverrides, iconSize, style, icon, titleContent, subtitleContent, suggestionsContent, children, ...rest }: AjoraChatEmptyStateProps): React.JSX.Element;
export declare namespace AjoraChatEmptyState {
    const Icon: React.FC<AjoraChatEmptyStateIconProps>;
    const Title: React.FC<AjoraChatEmptyStateTitleProps>;
    const Subtitle: React.FC<AjoraChatEmptyStateSubtitleProps>;
    const Suggestion: React.FC<AjoraChatEmptyStateSuggestionProps>;
    const Suggestions: React.FC<AjoraChatEmptyStateSuggestionsProps>;
}
export default AjoraChatEmptyState;
