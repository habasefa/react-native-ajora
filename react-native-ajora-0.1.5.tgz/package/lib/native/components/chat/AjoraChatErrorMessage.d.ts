import React from "react";
import { AjoraChatError } from "../../types";
export interface AjoraChatErrorMessageProps {
    message: string | AjoraChatError;
    onRetry?: () => void;
}
export default function AjoraChatErrorMessage({ message, onRetry, }: AjoraChatErrorMessageProps): React.JSX.Element;
