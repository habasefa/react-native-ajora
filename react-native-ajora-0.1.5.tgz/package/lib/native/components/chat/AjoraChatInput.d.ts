import React from "react";
import { TextInput as RNTextInput, StyleProp, ViewStyle, TextStyle, TextInputProps } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { AjoraChatAudioRecorder } from "./AjoraChatAudioRecorder";
import { type AttachmentType, type AgentOption, type ModelOption } from "../sheets";
import { type FileAttachment } from "../../lib/fileSystem";
import { MentionSuggestion } from "./AjoraMentionSuggestions";
export type AjoraChatInputMode = "input" | "transcribe" | "processing";
/**
 * Attachment preview item
 */
export interface AttachmentPreviewItem extends FileAttachment {
}
/**
 * Agent type option for selection
 */
export interface AgentTypeOption {
    id: string;
    label: string;
    description?: string;
    icon?: keyof typeof Ionicons.glyphMap;
}
/**
 * Theme configuration for AjoraChatInput styling
 */
export interface AjoraChatInputTheme {
    /** Main container style */
    container?: StyleProp<ViewStyle>;
    /** Inner wrapper for the input area */
    inputWrapper?: StyleProp<ViewStyle>;
    /** Text input style */
    textInput?: StyleProp<TextStyle>;
    /** Toolbar container (left side buttons) */
    toolbarContainer?: StyleProp<ViewStyle>;
    /** Actions container (right side buttons) */
    actionsContainer?: StyleProp<ViewStyle>;
    /** Icon button base style */
    iconButton?: StyleProp<ViewStyle>;
    /** Agent selector pill style */
    agentSelector?: StyleProp<ViewStyle>;
    /** Agent selector text style */
    agentSelectorText?: StyleProp<TextStyle>;
    /** Send button style */
    sendButton?: StyleProp<ViewStyle>;
    /** Stop button style */
    stopButton?: StyleProp<ViewStyle>;
    /** Mic button style */
    micButton?: StyleProp<ViewStyle>;
    /** Color scheme */
    colors?: {
        background?: string;
        inputBackground?: string;
        text?: string;
        placeholder?: string;
        primary?: string;
        secondary?: string;
        accent?: string;
        iconDefault?: string;
        iconActive?: string;
        border?: string;
        error?: string;
    };
}
export interface AjoraChatInputProps {
    /** Current input mode */
    mode?: AjoraChatInputMode;
    /** Whether auto-focus is enabled */
    autoFocus?: boolean;
    /** Callback when message is submitted */
    onSubmitMessage?: (value: string, attachments?: FileAttachment[]) => void;
    /** Callback to stop the current operation */
    onStop?: () => void;
    /** Whether the agent is currently running */
    isRunning?: boolean;
    /** Callback when transcription starts */
    onStartTranscribe?: () => void;
    /** Callback when transcription is cancelled */
    onCancelTranscribe?: () => void;
    /** Callback when transcription is finished */
    onFinishTranscribe?: () => void;
    /** Controlled value */
    value?: string;
    /** Callback when value changes */
    onChange?: (value: string) => void;
    /** Custom theme overrides */
    theme?: AjoraChatInputTheme;
    /** Maximum number of lines before scrolling */
    maxLines?: number;
    /** Placeholder text override */
    placeholder?: string;
    /** Test ID for testing */
    testID?: string;
    /** Whether to use dark mode */
    darkMode?: boolean;
    /** Agent type options */
    agentTypes?: AgentTypeOption[];
    /** Currently selected agent type ID */
    selectedAgentType?: string;
    /** Callback when agent type changes */
    onAgentTypeChange?: (agentType: AgentTypeOption) => void;
    /** Show agent type selector */
    showAgentSelector?: boolean;
    /** List of suggestions for mentions */
    mentionSuggestions?: MentionSuggestion[];
    /** Callback when a mention suggestion is selected */
    onMentionSelect?: (suggestion: MentionSuggestion) => void;
    /** Callback when the mention keyword changes */
    onMentionKeywordChange?: (keyword: string | null) => void;
    /** Show add button */
    showAddButton?: boolean;
    /** Callback when add button is pressed */
    onAddPress?: () => void;
    /** Show settings button */
    showSettingsButton?: boolean;
    /** Callback when settings button is pressed */
    onSettingsPress?: () => void;
    /** Style for mention text in input */
    mentionTextStyle?: StyleProp<TextStyle>;
    /** Whether mentions are loading */
    mentionLoading?: boolean;
    /** Custom component to render suggestion item */
    SuggestionItem?: React.ComponentType<any>;
    /** Function to get string representation of mention for input */
    getMentionPlainString?: (suggestion: MentionSuggestion) => string;
    /** Function to get value of mention */
    getMentionValue?: (suggestion: MentionSuggestion) => string;
    /** Maximum number of suggestions to display */
    maxSuggestions?: number;
    /** Custom text input component */
    textInput?: React.ReactElement;
    /** Custom send button component */
    sendButton?: React.ReactElement;
    /** Custom stop button component */
    stopButton?: React.ReactElement;
    /** Custom start transcribe button component */
    startTranscribeButton?: React.ReactElement;
    /** Custom audio recorder component */
    audioRecorder?: React.ReactElement;
    /** Render function for custom layout */
    children?: (props: AjoraChatInputChildrenArgs) => React.ReactNode;
    /** Container style */
    style?: StyleProp<ViewStyle>;
    /** Callback when an attachment type is selected */
    onAttachmentSelect?: (type: AttachmentType) => void;
    /** Callback when an agent is selected from the picker */
    onAgentSelect?: (agent: AgentOption) => void;
    /** Currently selected agent ID for the agent picker */
    selectedAgentId?: string;
    /** Custom agent options for the agent picker */
    agents?: AgentOption[];
    /** Callback when a model is selected */
    onModelSelect?: (model: ModelOption) => void;
    /** Currently selected model ID */
    selectedModelId?: string;
    /** Custom model options */
    models?: ModelOption[];
    /** Called when an attachment is rejected by validation (size/MIME/count). */
    onAttachmentRejected?: (rejections: Array<{
        file: FileAttachment;
        reason: string;
    }>) => void;
    /** Custom icons to override default icons */
    icons?: {
        /** Custom send icon */
        send?: React.ReactNode | ((props: {
            size: number;
            color: string;
        }) => React.ReactNode);
        /** Custom stop icon */
        stop?: React.ReactNode | ((props: {
            size: number;
            color: string;
        }) => React.ReactNode);
        /** Custom attachment/add icon */
        attachment?: React.ReactNode | ((props: {
            size: number;
            color: string;
        }) => React.ReactNode);
        /** Custom microphone icon */
        microphone?: React.ReactNode | ((props: {
            size: number;
            color: string;
        }) => React.ReactNode);
        /** Custom model selector icon */
        model?: React.ReactNode | ((props: {
            size: number;
            color: string;
        }) => React.ReactNode);
        /** Custom agent selector icon */
        agent?: React.ReactNode | ((props: {
            size: number;
            color: string;
        }) => React.ReactNode);
        /** Custom settings icon */
        settings?: React.ReactNode | ((props: {
            size: number;
            color: string;
        }) => React.ReactNode);
    };
}
/**
 * Child render function arguments
 */
export interface AjoraChatInputChildrenArgs {
    textInput: React.ReactElement;
    sendButton: React.ReactElement;
    stopButton: React.ReactElement;
    startTranscribeButton: React.ReactElement;
    audioRecorder: React.ReactElement;
    agentSelector: React.ReactElement;
    addButton: React.ReactElement | null;
    settingsButton: React.ReactElement;
    attachmentPreview: React.ReactElement | null;
    mode: AjoraChatInputMode;
    isRunning: boolean;
    value: string;
    canSend: boolean;
    canStop: boolean;
    colors: Required<NonNullable<AjoraChatInputTheme["colors"]>>;
    attachments: AttachmentPreviewItem[];
}
/**
 * Ref handle for imperative actions
 */
export interface AjoraChatInputRef {
    focus: () => void;
    blur: () => void;
    clear: () => void;
    getValue: () => string;
}
export interface AjoraChatTextInputProps extends Omit<TextInputProps, "style"> {
    style?: StyleProp<TextStyle>;
    testID?: string;
    colors?: AjoraChatInputTheme["colors"];
    mentionSuggestions?: MentionSuggestion[];
    onMentionSelect?: (suggestion: MentionSuggestion) => void;
    onMentionKeywordChange?: (keyword: string | null) => void;
    mentionTextStyle?: StyleProp<TextStyle>;
    mentionLoading?: boolean;
    SuggestionItem?: React.ComponentType<any>;
    getMentionPlainString?: (suggestion: MentionSuggestion) => string;
    getMentionValue?: (suggestion: MentionSuggestion) => string;
    maxSuggestions?: number;
}
export interface AjoraChatIconButtonProps {
    onPress?: () => void;
    disabled?: boolean;
    icon: keyof typeof Ionicons.glyphMap;
    iconFamily?: "ionicons" | "material" | "feather";
    size?: number;
    color?: string;
    activeColor?: string;
    isActive?: boolean;
    style?: StyleProp<ViewStyle>;
    testID?: string;
    accessibilityLabel?: string;
}
export interface AgentSelectorProps {
    options: AgentTypeOption[];
    selectedId?: string;
    onSelect: (option: AgentTypeOption) => void;
    colors: Required<NonNullable<AjoraChatInputTheme["colors"]>>;
    style?: StyleProp<ViewStyle>;
    testID?: string;
}
/**
 * TextInput sub-component
 */
declare const AjoraChatTextInput: React.ForwardRefExoticComponent<AjoraChatTextInputProps & React.RefAttributes<RNTextInput>>;
/**
 * Icon Button sub-component
 */
declare const AjoraChatIconButton: React.FC<AjoraChatIconButtonProps>;
/**
 * Agent Type Selector sub-component
 */
declare const AgentSelector: React.FC<AgentSelectorProps>;
interface AttachmentPreviewProps {
    attachments: AttachmentPreviewItem[];
    onRemove: (id: string) => void;
    colors: Required<NonNullable<AjoraChatInputTheme["colors"]>>;
    testID?: string;
}
/**
 * Attachment Preview sub-component - shows image thumbnails with upload spinner
 */
declare const AttachmentPreview: React.FC<AttachmentPreviewProps>;
declare const AjoraChatInputComponent: React.ForwardRefExoticComponent<AjoraChatInputProps & React.RefAttributes<AjoraChatInputRef>>;
type AjoraChatInputType = typeof AjoraChatInputComponent & {
    TextInput: typeof AjoraChatTextInput;
    IconButton: typeof AjoraChatIconButton;
    AgentSelector: typeof AgentSelector;
    AudioRecorder: typeof AjoraChatAudioRecorder;
    AttachmentPreview: typeof AttachmentPreview;
};
export declare const AjoraChatInput: AjoraChatInputType;
export default AjoraChatInput;
