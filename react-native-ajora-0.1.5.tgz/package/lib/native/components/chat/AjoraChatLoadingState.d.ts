import * as React from "react";
import { StyleProp, ViewStyle, TextStyle } from "react-native";
import { WithSlots } from "../../lib/slots";
/**
 * Theme configuration for the loading state
 */
export interface AjoraChatLoadingStateTheme {
    /** Background color */
    backgroundColor?: string;
    /** Spinner/dot color */
    spinnerColor?: string;
    /** Text color */
    textColor?: string;
    /** Dot size */
    dotSize?: number;
}
/**
 * Default light theme - uses consistent project colors
 * @deprecated Use useAjoraTheme() instead
 */
export declare const DEFAULT_LOADING_STATE_LIGHT_THEME: AjoraChatLoadingStateTheme;
/**
 * Default dark theme - uses consistent project colors
 * @deprecated Use useAjoraTheme() instead
 */
export declare const DEFAULT_LOADING_STATE_DARK_THEME: AjoraChatLoadingStateTheme;
export type AjoraChatLoadingStateType = "connecting" | "loading" | "thinking" | "reconnecting";
export interface AjoraChatLoadingStateDotsProps {
    color?: string;
    size?: number;
    style?: StyleProp<ViewStyle>;
}
export interface AjoraChatLoadingStateTextProps {
    children?: React.ReactNode;
    style?: StyleProp<TextStyle>;
}
type LoadingStateSlots = {
    dots: typeof AjoraChatLoadingState.Dots;
    text: typeof AjoraChatLoadingState.Text;
};
type LoadingStateRestProps = {
    /** Type of loading state */
    type?: AjoraChatLoadingStateType;
    /** Custom loading text */
    text?: string;
    /** Whether to show the loading text */
    showText?: boolean;
    /** Theme configuration */
    theme?: AjoraChatLoadingStateTheme;
    /** Container style */
    style?: StyleProp<ViewStyle>;
    /** Layout direction */
    layout?: "horizontal" | "vertical";
};
export type AjoraChatLoadingStateProps = WithSlots<LoadingStateSlots, LoadingStateRestProps>;
export declare function AjoraChatLoadingState({ type, text, showText, theme: customTheme, style, layout, dots, text: textSlot, children, ...rest }: AjoraChatLoadingStateProps): React.JSX.Element;
export declare namespace AjoraChatLoadingState {
    const Dots: React.FC<AjoraChatLoadingStateDotsProps>;
    const Text: React.FC<AjoraChatLoadingStateTextProps>;
}
export default AjoraChatLoadingState;
