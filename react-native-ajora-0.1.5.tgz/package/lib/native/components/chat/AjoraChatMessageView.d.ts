import * as React from "react";
import { StyleProp, ViewStyle } from "react-native";
import { WithSlots } from "../../lib/slots";
import AjoraChatAssistantMessage from "./AjoraChatAssistantMessage";
import AjoraChatUserMessage from "./AjoraChatUserMessage";
import AjoraChatThinkingIndicator from "./AjoraChatThinkingIndicator";
import { AssistantMessage, Message } from "@ag-ui/core";
import AjoraChatErrorMessage from "./AjoraChatErrorMessage";
export type AjoraChatMessageViewProps = Omit<WithSlots<{
    assistantMessage: typeof AjoraChatAssistantMessage;
    userMessage: typeof AjoraChatUserMessage;
    thinkingIndicator: typeof AjoraChatThinkingIndicator;
    errorMessage: typeof AjoraChatErrorMessage;
}, {
    isRunning?: boolean;
    messages?: Message[];
    onRegenerate?: (message: AssistantMessage) => void;
    onMessageLongPress?: (message: Message) => void;
    /** Renderer applied to both user and assistant messages unless a
        side-specific renderer is provided. */
    textRenderer?: (props: {
        content: string;
    }) => React.ReactNode;
    /** Overrides `textRenderer` for user messages only. */
    userTextRenderer?: (props: {
        content: string;
    }) => React.ReactNode;
    /** Overrides `textRenderer` for assistant messages only. */
    assistantTextRenderer?: (props: {
        content: string;
    }) => React.ReactNode;
    /** Whether to show the thinking indicator when isRunning is true */
    showThinkingIndicator?: boolean;
    /** Error message to display at the bottom of the chat */
    error?: string | null;
    /** Callback to retry the agent run upon an error */
    onRetryError?: () => void;
    style?: StyleProp<ViewStyle>;
}>, "children"> & {
    children?: (props: {
        isRunning: boolean;
        messages: Message[];
        messageElements: React.ReactElement[];
        thinkingIndicator: React.ReactElement | null;
    }) => React.ReactElement;
};
/**
 * Stable per-message renderer suitable for both the legacy `<View>`-based
 * `AjoraChatMessageView` and FlashList's `renderItem`. Returns a single
 * React element per message (custom-before + main + custom-after wrapped
 * in a Fragment) so FlashList can virtualize one cell per data row.
 *
 * Pulled out of `AjoraChatMessageView` so the FlashList code path inside
 * `AjoraChatViewInner` doesn't need to construct the entire `messageElements`
 * array up-front — that defeats virtualization.
 */
export declare function useRenderMessage({ messages, isRunning, assistantMessage, userMessage, onRegenerate, onMessageLongPress, textRenderer, assistantTextRenderer, userTextRenderer, }: {
    messages: Message[];
    isRunning: boolean;
    assistantMessage?: AjoraChatMessageViewProps["assistantMessage"];
    userMessage?: AjoraChatMessageViewProps["userMessage"];
    onRegenerate?: (message: AssistantMessage) => void;
    onMessageLongPress?: (message: Message) => void;
    textRenderer?: (props: {
        content: string;
    }) => React.ReactNode;
    assistantTextRenderer?: (props: {
        content: string;
    }) => React.ReactNode;
    userTextRenderer?: (props: {
        content: string;
    }) => React.ReactNode;
}): (message: Message, _index: number) => React.ReactElement | null;
/**
 * Deduplicate messages by id, keeping the most recent occurrence. FlashList
 * requires unique keys, and streaming sometimes emits the same message id
 * multiple times before settling. Exposed so the FlashList callsite can
 * dedupe before passing `data` instead of relying on this component.
 */
export declare function dedupeMessagesById(messages: Message[]): Message[];
export declare function AjoraChatMessageView({ messages, assistantMessage, userMessage, thinkingIndicator, errorMessage, isRunning, showThinkingIndicator, onRegenerate, onMessageLongPress, textRenderer, userTextRenderer, assistantTextRenderer, children, style, error, onRetryError, ...props }: AjoraChatMessageViewProps): React.JSX.Element;
export default AjoraChatMessageView;
