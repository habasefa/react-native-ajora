import * as React from "react";
import { StyleProp, ViewStyle } from "react-native";
import { WithSlots } from "../../lib/slots";
import AjoraChatAssistantMessage from "./AjoraChatAssistantMessage";
import AjoraChatUserMessage from "./AjoraChatUserMessage";
import AjoraChatThinkingIndicator from "./AjoraChatThinkingIndicator";
import { AssistantMessage, Message } from "@ag-ui/core";
import AjoraChatErrorMessage from "./AjoraChatErrorMessage";
export type AjoraChatMessageViewProps = Omit<WithSlots<{
    assistantMessage: typeof AjoraChatAssistantMessage;
    userMessage: typeof AjoraChatUserMessage;
    thinkingIndicator: typeof AjoraChatThinkingIndicator;
    errorMessage: typeof AjoraChatErrorMessage;
}, {
    isRunning?: boolean;
    messages?: Message[];
    onRegenerate?: (message: AssistantMessage) => void;
    onMessageLongPress?: (message: Message) => void;
    textRenderer?: (props: {
        content: string;
    }) => React.ReactNode;
    /** Whether to show the thinking indicator when isRunning is true */
    showThinkingIndicator?: boolean;
    /** Error message to display at the bottom of the chat */
    error?: string | null;
    /** Callback to retry the agent run upon an error */
    onRetryError?: () => void;
    style?: StyleProp<ViewStyle>;
}>, "children"> & {
    children?: (props: {
        isRunning: boolean;
        messages: Message[];
        messageElements: React.ReactElement[];
        thinkingIndicator: React.ReactElement | null;
    }) => React.ReactElement;
};
export declare function AjoraChatMessageView({ messages, assistantMessage, userMessage, thinkingIndicator, errorMessage, isRunning, showThinkingIndicator, onRegenerate, onMessageLongPress, textRenderer, children, style, error, onRetryError, ...props }: AjoraChatMessageViewProps): React.JSX.Element;
export default AjoraChatMessageView;
