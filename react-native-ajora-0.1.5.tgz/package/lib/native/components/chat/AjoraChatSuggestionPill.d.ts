import * as React from "react";
import { ViewStyle, TextStyle, StyleProp } from "react-native";
export interface AjoraChatSuggestionPillColorsOverride {
    background?: string;
    border?: string;
    text?: string;
    icon?: string;
    pressedBackground?: string;
    loader?: string;
}
export interface AjoraChatSuggestionPillProps {
    /** The content to display inside the pill. */
    children: React.ReactNode;
    /** Whether the pill should display a loading spinner. */
    isLoading?: boolean;
    /** Optional icon to render on the left side when not loading. */
    icon?: React.ReactNode;
    /** Callback when the pill is pressed. */
    onPress?: () => void;
    /** Optional style override for the container. */
    style?: StyleProp<ViewStyle>;
    /** Optional style override for the text. */
    textStyle?: StyleProp<TextStyle>;
    /** Whether the button is disabled. */
    disabled?: boolean;
    /** Custom colors override */
    colors?: AjoraChatSuggestionPillColorsOverride;
}
export declare const AjoraChatSuggestionPill: React.ForwardRefExoticComponent<AjoraChatSuggestionPillProps & React.RefAttributes<any>>;
export default AjoraChatSuggestionPill;
