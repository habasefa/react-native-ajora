import * as React from "react";
import { View, StyleProp, ViewStyle } from "react-native";
export interface AjoraChatSuggestionShimmerProps {
    /** Width of the shimmer placeholder. Varying widths across placeholders
     *  reads more naturally than a uniform row. */
    width?: number;
    /** Override the base + highlight colors. Defaults derive from theme. */
    colors?: readonly [string, string];
    /** Override the skeleton color mode — otherwise inferred from theme. */
    colorMode?: "light" | "dark";
    style?: StyleProp<ViewStyle>;
}
export declare const AjoraChatSuggestionShimmer: React.ForwardRefExoticComponent<AjoraChatSuggestionShimmerProps & React.RefAttributes<View>>;
export default AjoraChatSuggestionShimmer;
