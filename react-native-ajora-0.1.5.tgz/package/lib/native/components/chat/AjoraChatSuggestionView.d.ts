import * as React from "react";
import { View, StyleProp, ViewStyle } from "react-native";
import { Suggestion } from "../../../core";
import { WithSlots } from "../../lib/slots";
import AjoraChatSuggestionPill, { AjoraChatSuggestionPillProps } from "./AjoraChatSuggestionPill";
import AjoraChatSuggestionShimmer, { AjoraChatSuggestionShimmerProps } from "./AjoraChatSuggestionShimmer";
declare const DefaultContainer: React.ForwardRefExoticComponent<{
    children: React.ReactNode;
    style?: StyleProp<ViewStyle>;
} & React.RefAttributes<any>>;
export type AjoraChatSuggestionViewProps = WithSlots<{
    container: typeof DefaultContainer;
    suggestion: typeof AjoraChatSuggestionPill;
    shimmer: typeof AjoraChatSuggestionShimmer;
}, {
    suggestions: Suggestion[];
    onSelectSuggestion?: (suggestion: Suggestion, index: number) => void;
    loadingIndexes?: ReadonlyArray<number>;
    /**
     * When true and no suggestions have arrived yet, the view renders
     * shimmer placeholders instead of an empty row. The existing per-pill
     * `loadingIndexes` / `suggestion.isLoading` spinner still handles the
     * "user clicked this pill" case independently.
     */
    isLoading?: boolean;
    style?: StyleProp<ViewStyle>;
}>;
export declare const AjoraChatSuggestionView: React.ForwardRefExoticComponent<{
    container?: import("../..").SlotValue<React.ForwardRefExoticComponent<{
        children: React.ReactNode;
        style?: StyleProp<ViewStyle>;
    } & React.RefAttributes<any>>> | undefined;
    suggestion?: import("../..").SlotValue<React.ForwardRefExoticComponent<AjoraChatSuggestionPillProps & React.RefAttributes<any>>> | undefined;
    shimmer?: import("../..").SlotValue<React.ForwardRefExoticComponent<AjoraChatSuggestionShimmerProps & React.RefAttributes<View>>> | undefined;
} & {
    children?: ((props: {
        container: React.ReactElement<unknown, string | React.JSXElementConstructor<any>>;
        suggestion: React.ReactElement<unknown, string | React.JSXElementConstructor<any>>;
        shimmer: React.ReactElement<unknown, string | React.JSXElementConstructor<any>>;
    } & Omit<{
        suggestions: Suggestion[];
        onSelectSuggestion?: (suggestion: Suggestion, index: number) => void;
        loadingIndexes?: ReadonlyArray<number>;
        /**
         * When true and no suggestions have arrived yet, the view renders
         * shimmer placeholders instead of an empty row. The existing per-pill
         * `loadingIndexes` / `suggestion.isLoading` spinner still handles the
         * "user clicked this pill" case independently.
         */
        isLoading?: boolean;
        style?: StyleProp<ViewStyle>;
    }, "shimmer" | "container" | "suggestion">) => React.ReactNode) | undefined;
} & Omit<{
    suggestions: Suggestion[];
    onSelectSuggestion?: (suggestion: Suggestion, index: number) => void;
    loadingIndexes?: ReadonlyArray<number>;
    /**
     * When true and no suggestions have arrived yet, the view renders
     * shimmer placeholders instead of an empty row. The existing per-pill
     * `loadingIndexes` / `suggestion.isLoading` spinner still handles the
     * "user clicked this pill" case independently.
     */
    isLoading?: boolean;
    style?: StyleProp<ViewStyle>;
}, "shimmer" | "children" | "container" | "suggestion"> & React.RefAttributes<any>>;
export default AjoraChatSuggestionView;
