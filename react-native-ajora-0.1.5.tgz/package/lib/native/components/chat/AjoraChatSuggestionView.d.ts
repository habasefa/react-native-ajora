import * as React from "react";
import { StyleProp, ViewStyle } from "react-native";
import { Suggestion } from "../../../core";
import { WithSlots } from "../../lib/slots";
import AjoraChatSuggestionPill, { AjoraChatSuggestionPillProps } from "./AjoraChatSuggestionPill";
declare const DefaultContainer: React.ForwardRefExoticComponent<{
    children: React.ReactNode;
    style?: StyleProp<ViewStyle>;
} & React.RefAttributes<any>>;
export type AjoraChatSuggestionViewProps = WithSlots<{
    container: typeof DefaultContainer;
    suggestion: typeof AjoraChatSuggestionPill;
}, {
    suggestions: Suggestion[];
    onSelectSuggestion?: (suggestion: Suggestion, index: number) => void;
    loadingIndexes?: ReadonlyArray<number>;
    style?: StyleProp<ViewStyle>;
}>;
export declare const AjoraChatSuggestionView: React.ForwardRefExoticComponent<{
    container?: import("../..").SlotValue<React.ForwardRefExoticComponent<{
        children: React.ReactNode;
        style?: StyleProp<ViewStyle>;
    } & React.RefAttributes<any>>> | undefined;
    suggestion?: import("../..").SlotValue<React.ForwardRefExoticComponent<AjoraChatSuggestionPillProps & React.RefAttributes<any>>> | undefined;
} & {
    children?: ((props: {
        container: React.ReactElement<unknown, string | React.JSXElementConstructor<any>>;
        suggestion: React.ReactElement<unknown, string | React.JSXElementConstructor<any>>;
    } & Omit<{
        suggestions: Suggestion[];
        onSelectSuggestion?: (suggestion: Suggestion, index: number) => void;
        loadingIndexes?: ReadonlyArray<number>;
        style?: StyleProp<ViewStyle>;
    }, "container" | "suggestion">) => React.ReactNode) | undefined;
} & Omit<{
    suggestions: Suggestion[];
    onSelectSuggestion?: (suggestion: Suggestion, index: number) => void;
    loadingIndexes?: ReadonlyArray<number>;
    style?: StyleProp<ViewStyle>;
}, "children" | "container" | "suggestion"> & React.RefAttributes<any>>;
export default AjoraChatSuggestionView;
