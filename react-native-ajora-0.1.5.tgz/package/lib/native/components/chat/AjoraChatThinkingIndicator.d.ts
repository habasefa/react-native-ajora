import React from "react";
import { StyleProp, ViewStyle } from "react-native";
export interface AjoraChatThinkingIndicatorProps {
    /** Whether the assistant is currently thinking/running */
    isThinking?: boolean;
    /** Optional title from THINKING_START (e.g., "Planning"). Renders bold
     *  above the streamed text. */
    title?: string;
    /** Optional live thinking text. Only the last non-empty line is shown,
     *  truncated to a single line so the indicator stays compact. */
    text?: string;
    /** Custom dot color */
    dotColor?: string;
    /** Size of each dot */
    dotSize?: number;
    /** Gap between dots */
    gap?: number;
    /** Container style override */
    style?: StyleProp<ViewStyle>;
    /** Custom colors override */
    colors?: {
        background?: string;
        dotDefault?: string;
        title?: string;
        text?: string;
    };
}
export declare function AjoraChatThinkingIndicator({ isThinking, title, text, dotColor, dotSize, gap, style, colors: colorOverrides, }: AjoraChatThinkingIndicatorProps): React.JSX.Element | null;
export default AjoraChatThinkingIndicator;
