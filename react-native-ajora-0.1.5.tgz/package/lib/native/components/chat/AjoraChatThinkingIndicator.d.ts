import React from "react";
import { StyleProp, ViewStyle } from "react-native";
export interface AjoraChatThinkingIndicatorProps {
    /** Whether the assistant is currently thinking/running */
    isThinking?: boolean;
    /** Custom dot color */
    dotColor?: string;
    /** Size of each dot */
    dotSize?: number;
    /** Gap between dots */
    gap?: number;
    /** Container style override */
    style?: StyleProp<ViewStyle>;
    /** Custom colors override */
    colors?: {
        background?: string;
        dotDefault?: string;
    };
}
export declare function AjoraChatThinkingIndicator({ isThinking, dotColor, dotSize, gap, style, colors: colorOverrides, }: AjoraChatThinkingIndicatorProps): React.JSX.Element | null;
export default AjoraChatThinkingIndicator;
