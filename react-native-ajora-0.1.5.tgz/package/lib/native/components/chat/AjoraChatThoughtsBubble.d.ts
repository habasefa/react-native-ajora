import React from "react";
import { StyleProp, ViewStyle } from "react-native";
import type { ThinkingBlock } from "../../types/thinking";
export interface AjoraChatThoughtsBubbleColors {
    background?: string;
    border?: string;
    title?: string;
    meta?: string;
    text?: string;
    icon?: string;
}
export interface AjoraChatThoughtsBubbleProps {
    /** The persisted thinking block attached to the assistant message. */
    thinking?: ThinkingBlock;
    /** Whether the bubble starts expanded. Defaults to false (collapsed). */
    defaultExpanded?: boolean;
    /** Theme overrides. */
    colors?: AjoraChatThoughtsBubbleColors;
    /** Container style override. */
    style?: StyleProp<ViewStyle>;
}
export declare function formatThoughtsDuration(startedAt?: number, endedAt?: number): string | null;
export declare function AjoraChatThoughtsBubble({ thinking, defaultExpanded, colors: colorOverrides, style, }: AjoraChatThoughtsBubbleProps): React.JSX.Element | null;
export default AjoraChatThoughtsBubble;
