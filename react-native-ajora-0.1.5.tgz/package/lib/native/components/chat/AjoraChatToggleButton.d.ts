import * as React from "react";
import { StyleProp, ViewStyle } from "react-native";
import { SlotValue } from "../../lib/slots";
declare const DefaultOpenIcon: React.FC;
declare const DefaultCloseIcon: React.FC;
export interface AjoraChatToggleButtonProps {
    /** Optional slot override for the chat (closed) icon. */
    openIcon?: SlotValue<typeof DefaultOpenIcon>;
    /** Optional slot override for the close icon. */
    closeIcon?: SlotValue<typeof DefaultCloseIcon>;
    /** Optional style override for the button. */
    style?: StyleProp<ViewStyle>;
    /** Whether the button is disabled. */
    disabled?: boolean;
}
export declare const AjoraChatToggleButton: React.ForwardRefExoticComponent<AjoraChatToggleButtonProps & React.RefAttributes<any>>;
export default AjoraChatToggleButton;
