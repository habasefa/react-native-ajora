import * as React from "react";
import { AssistantMessage, Message } from "@ag-ui/core";
export type AjoraChatToolCallsViewProps = {
    message: AssistantMessage;
    messages?: Message[];
};
export declare function AjoraChatToolCallsView({ message, messages, }: AjoraChatToolCallsViewProps): React.JSX.Element | null;
export default AjoraChatToolCallsView;
