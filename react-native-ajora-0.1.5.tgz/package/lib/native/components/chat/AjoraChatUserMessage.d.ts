import * as React from "react";
import { StyleProp, ViewStyle } from "react-native";
import { UserMessage } from "@ag-ui/core";
import { WithSlots } from "../../lib/slots";
export interface AjoraChatUserMessageOnEditMessageProps {
    message: UserMessage;
}
export interface AjoraChatUserMessageOnSwitchToBranchProps {
    message: UserMessage;
    branchIndex: number;
    numberOfBranches: number;
}
export interface AjoraChatUserMessageColorsOverride {
    bubbleBackground?: string;
    text?: string;
    iconColor?: string;
}
interface AjoraChatUserMessageColors {
    bubbleBackground: string;
    text: string;
    iconColor: string;
}
export type AjoraChatUserMessageProps = WithSlots<{
    messageRenderer: typeof AjoraChatUserMessage.MessageRenderer;
    toolbar: typeof AjoraChatUserMessage.Toolbar;
    copyButton: typeof AjoraChatUserMessage.CopyButton;
    editButton: typeof AjoraChatUserMessage.EditButton;
    branchNavigation: typeof AjoraChatUserMessage.BranchNavigation;
}, {
    onEditMessage?: (props: AjoraChatUserMessageOnEditMessageProps) => void;
    onSwitchToBranch?: (props: AjoraChatUserMessageOnSwitchToBranchProps) => void;
    message: UserMessage;
    branchIndex?: number;
    numberOfBranches?: number;
    additionalToolbarItems?: React.ReactNode;
    colors?: AjoraChatUserMessageColorsOverride;
    onLongPress?: (props: {
        message: UserMessage;
    }) => void;
    style?: StyleProp<ViewStyle>;
    textRenderer?: (props: {
        content: string;
    }) => React.ReactNode;
}>;
export declare function AjoraChatUserMessage({ message, onEditMessage, branchIndex, numberOfBranches, onSwitchToBranch, additionalToolbarItems, colors: colorOverrides, onLongPress, messageRenderer, toolbar, copyButton, editButton, branchNavigation, children, style, textRenderer, ...props }: AjoraChatUserMessageProps): React.JSX.Element;
export declare namespace AjoraChatUserMessage {
    const Container: React.FC<React.PropsWithChildren<{
        style?: StyleProp<ViewStyle>;
    }>>;
    const MessageRenderer: React.FC<{
        content: string;
        style?: StyleProp<ViewStyle>;
        colors?: AjoraChatUserMessageColors;
        onLongPress?: () => void;
        textRenderer?: (props: {
            content: string;
        }) => React.ReactNode;
    }>;
    const Toolbar: React.FC<{
        children: React.ReactNode;
        style?: StyleProp<ViewStyle>;
    }>;
    const ToolbarButton: React.FC<{
        title: string;
        onPress?: () => void;
        children: React.ReactNode;
        style?: StyleProp<ViewStyle>;
    }>;
    const CopyButton: React.FC<{
        onClick?: () => void;
        style?: StyleProp<ViewStyle>;
        colors: AjoraChatUserMessageColors;
    }>;
    const EditButton: React.FC<{
        onClick?: () => void;
        style?: StyleProp<ViewStyle>;
        colors: AjoraChatUserMessageColors;
    }>;
    const BranchNavigation: React.FC<{
        currentBranch?: number;
        numberOfBranches?: number;
        onSwitchToBranch?: (props: AjoraChatUserMessageOnSwitchToBranchProps) => void;
        message: UserMessage;
        style?: StyleProp<ViewStyle>;
        colors: AjoraChatUserMessageColors;
    }>;
}
export default AjoraChatUserMessage;
