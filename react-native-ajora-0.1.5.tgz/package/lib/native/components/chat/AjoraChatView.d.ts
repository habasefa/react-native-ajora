import React from "react";
import { StyleProp, ViewStyle } from "react-native";
import { WithSlots } from "../../lib/slots";
import AjoraChatInput, { AjoraChatInputProps } from "./AjoraChatInput";
import { Suggestion } from "../../../core";
import { AssistantMessage, Message } from "@ag-ui/core";
import AjoraChatSuggestionView from "./AjoraChatSuggestionView";
import AjoraChatMessageView from "./AjoraChatMessageView";
import AjoraChatThinkingIndicator from "./AjoraChatThinkingIndicator";
import AjoraChatEmptyState from "./AjoraChatEmptyState";
import AjoraChatLoadingState from "./AjoraChatLoadingState";
import AjoraChatErrorMessage, { AjoraChatErrorMessageProps } from "./AjoraChatErrorMessage";
export type AjoraChatViewProps = WithSlots<{
    messageView: typeof AjoraChatMessageView;
    scrollView: typeof AjoraChatScrollView;
    input: typeof AjoraChatInput;
    suggestionView: typeof AjoraChatSuggestionView;
    thinkingIndicator: typeof AjoraChatThinkingIndicator;
    scrollToBottomButton: typeof AjoraChatScrollToBottomButton;
    emptyState: typeof AjoraChatEmptyState;
    loadingState: typeof AjoraChatLoadingState;
    errorMessage: typeof AjoraChatErrorMessage;
}, {
    messages?: Message[];
    inputProps?: Partial<Omit<AjoraChatInputProps, "children">>;
    error?: string | null;
    /** Callback to retry the agent run upon an error */
    onRetryError?: () => void;
    /** Whether to show the thinking indicator when isRunning is true */
    showThinkingIndicator?: boolean;
    /** Whether to show the empty state when there are no messages */
    showEmptyState?: boolean;
    /** Whether to show the loading state when isLoading is true */
    showLoadingState?: boolean;
    /** Whether to auto-scroll to bottom when new messages arrive or content is streaming */
    autoScroll?: boolean;
    /** Starter suggestions to show in the empty state */
    starterSuggestions?: Suggestion[];
    suggestions?: Suggestion[];
    suggestionLoadingIndexes?: ReadonlyArray<number>;
    onSelectSuggestion?: (suggestion: Suggestion, index: number) => void;
    onRegenerate?: (message: AssistantMessage) => void;
    onMessageLongPress?: (message: Message) => void;
    textRenderer?: (props: {
        content: string;
    }) => React.ReactNode;
    style?: StyleProp<ViewStyle>;
    /** True while a "load earlier" page is in flight. */
    isLoadingEarlier?: boolean;
    /** Whether there are older messages available beyond the current page. */
    hasEarlierMessages?: boolean;
    /** Called when the user taps the "Load earlier" affordance. */
    onLoadEarlier?: () => void;
    /** Style override for the main container */
    containerStyle?: StyleProp<ViewStyle>;
    /** Style override for the message list area */
    messageListStyle?: StyleProp<ViewStyle>;
    /** Style override for the input container at the bottom */
    inputContainerStyle?: StyleProp<ViewStyle>;
    /** Style override for user message bubbles */
    userBubbleStyle?: StyleProp<ViewStyle>;
    /** Style override for assistant message bubbles */
    assistantBubbleStyle?: StyleProp<ViewStyle>;
    /** Style override for the suggestions container */
    suggestionContainerStyle?: StyleProp<ViewStyle>;
    /** Style override for the scroll view content */
    scrollContentStyle?: StyleProp<ViewStyle>;
    /** Custom message component */
    Message?: (props: {
        message: Message;
        index: number;
    }) => React.ReactNode;
    /** Custom bubble wrapper component */
    Bubble?: (props: {
        message: Message;
        isUser: boolean;
        children: React.ReactNode;
    }) => React.ReactNode;
    /** Custom avatar component */
    Avatar?: (props: {
        role: "user" | "assistant";
        size?: number;
    }) => React.ReactNode;
    /** Custom empty state component */
    EmptyState?: () => React.ReactNode;
    /** Custom loading state component */
    LoadingState?: () => React.ReactNode;
    /** Custom thinking indicator component */
    ThinkingIndicator?: () => React.ReactNode;
    /** Custom error message component */
    ErrorMessage?: (props: AjoraChatErrorMessageProps) => React.ReactNode;
    /** Custom suggestion component */
    Suggestion?: (props: {
        suggestion: Suggestion;
        onPress: () => void;
    }) => React.ReactNode;
}>;
interface AjoraChatScrollToBottomButtonProps {
    onPress: () => void;
    visible: boolean;
    style?: StyleProp<ViewStyle>;
}
export declare function AjoraChatScrollToBottomButton({ onPress, visible, style, }: AjoraChatScrollToBottomButtonProps): React.JSX.Element | null;
interface AjoraChatScrollViewProps {
    children: React.ReactNode;
    autoScroll?: boolean;
    isStreaming?: boolean;
    messages?: Message[];
    scrollToBottomButton?: React.ReactElement | null;
    showScrollToBottomButton?: boolean;
    style?: StyleProp<ViewStyle>;
    contentContainerStyle?: StyleProp<ViewStyle>;
}
export declare function AjoraChatScrollView({ children, autoScroll, isStreaming, messages, scrollToBottomButton, showScrollToBottomButton, style, contentContainerStyle, }: AjoraChatScrollViewProps): React.JSX.Element;
/**
 * Main AjoraChatView component with keyboard handling
 * Wraps content in KeyboardProvider for proper keyboard animation
 */
export declare function AjoraChatView(props: AjoraChatViewProps): React.JSX.Element;
export default AjoraChatView;
