import React from "react";
import { StyleProp, ViewStyle } from "react-native";
import { WithSlots } from "../../lib/slots";
import AjoraChatInput, { AjoraChatInputProps } from "./AjoraChatInput";
import { Suggestion } from "../../../core";
import { AssistantMessage, Message } from "@ag-ui/core";
import AjoraChatSuggestionView from "./AjoraChatSuggestionView";
import AjoraChatMessageView from "./AjoraChatMessageView";
import AjoraChatThinkingIndicator from "./AjoraChatThinkingIndicator";
import AjoraChatEmptyState from "./AjoraChatEmptyState";
import AjoraChatLoadingState from "./AjoraChatLoadingState";
import AjoraChatErrorMessage, { AjoraChatErrorMessageProps } from "./AjoraChatErrorMessage";
export type AjoraChatViewProps = WithSlots<{
    messageView: typeof AjoraChatMessageView;
    scrollView: typeof AjoraChatScrollView;
    input: typeof AjoraChatInput;
    suggestionView: typeof AjoraChatSuggestionView;
    thinkingIndicator: typeof AjoraChatThinkingIndicator;
    scrollToBottomButton: typeof AjoraChatScrollToBottomButton;
    emptyState: typeof AjoraChatEmptyState;
    loadingState: typeof AjoraChatLoadingState;
    errorMessage: typeof AjoraChatErrorMessage;
}, {
    messages?: Message[];
    inputProps?: Partial<Omit<AjoraChatInputProps, "children">>;
    error?: string | null;
    /** Callback to retry the agent run upon an error */
    onRetryError?: () => void;
    /** Whether to show the thinking indicator when isRunning is true */
    showThinkingIndicator?: boolean;
    /** Whether to show the empty state when there are no messages */
    showEmptyState?: boolean;
    /** Whether to show the loading state when isLoading is true */
    showLoadingState?: boolean;
    /** Whether to auto-scroll to bottom when new messages arrive or content is streaming */
    autoScroll?: boolean;
    /** Starter suggestions to show in the empty state */
    starterSuggestions?: Suggestion[];
    suggestions?: Suggestion[];
    suggestionLoadingIndexes?: ReadonlyArray<number>;
    /** When true and `suggestions` is empty, the suggestion view renders
     *  shimmer placeholders to signal that generation is in-flight. */
    isSuggestionsLoading?: boolean;
    onSelectSuggestion?: (suggestion: Suggestion, index: number) => void;
    onRegenerate?: (message: AssistantMessage) => void;
    onMessageLongPress?: (message: Message) => void;
    /** Renderer applied to both user and assistant messages unless a
        side-specific renderer is provided. */
    textRenderer?: (props: {
        content: string;
    }) => React.ReactNode;
    /** Overrides `textRenderer` for user messages only. */
    userTextRenderer?: (props: {
        content: string;
    }) => React.ReactNode;
    /** Overrides `textRenderer` for assistant messages only. */
    assistantTextRenderer?: (props: {
        content: string;
    }) => React.ReactNode;
    style?: StyleProp<ViewStyle>;
    /** True while a "load earlier" page is in flight. */
    isLoadingEarlier?: boolean;
    /** Whether there are older messages available beyond the current page. */
    hasEarlierMessages?: boolean;
    /** Called when the user taps the "Load earlier" affordance. */
    onLoadEarlier?: () => void;
    /** Error from the history load (initial or reload). When set, the view
     *  surfaces a retry affordance: as a full card replacing the empty state
     *  when the thread is empty, or as a banner above the message list when
     *  messages are already shown. */
    historyError?: Error | string | null;
    /** Called when the user taps "Try again" on a history error. Typically
     *  wired to `useHistory.reload`. */
    onRetryHistory?: () => void;
    /** Active thread id. When provided, the scroll view auto-pages
     *  `onLoadEarlier` on scroll-to-top and remembers per-thread scroll
     *  position across thread switches. */
    threadId?: string;
    /** Style override for the main container */
    containerStyle?: StyleProp<ViewStyle>;
    /** Style override for the message list area */
    messageListStyle?: StyleProp<ViewStyle>;
    /** Style override for the input container at the bottom */
    inputContainerStyle?: StyleProp<ViewStyle>;
    /** Style override for user message bubbles */
    userBubbleStyle?: StyleProp<ViewStyle>;
    /** Style override for assistant message bubbles */
    assistantBubbleStyle?: StyleProp<ViewStyle>;
    /** Style override for the suggestions container */
    suggestionContainerStyle?: StyleProp<ViewStyle>;
    /** Style override for the scroll view content */
    scrollContentStyle?: StyleProp<ViewStyle>;
    /** Custom message component */
    Message?: (props: {
        message: Message;
        index: number;
    }) => React.ReactNode;
    /** Custom bubble wrapper component */
    Bubble?: (props: {
        message: Message;
        isUser: boolean;
        children: React.ReactNode;
    }) => React.ReactNode;
    /** Custom avatar component */
    Avatar?: (props: {
        role: "user" | "assistant";
        size?: number;
    }) => React.ReactNode;
    /** Custom empty state component */
    EmptyState?: () => React.ReactNode;
    /** Custom loading state component */
    LoadingState?: () => React.ReactNode;
    /** Custom thinking indicator component */
    ThinkingIndicator?: () => React.ReactNode;
    /** Custom error message component */
    ErrorMessage?: (props: AjoraChatErrorMessageProps) => React.ReactNode;
    /** Custom suggestion component */
    Suggestion?: (props: {
        suggestion: Suggestion;
        onPress: () => void;
    }) => React.ReactNode;
}>;
interface AjoraChatScrollToBottomButtonProps {
    onPress: () => void;
    visible: boolean;
    style?: StyleProp<ViewStyle>;
}
export declare function AjoraChatScrollToBottomButton({ onPress, visible, style, }: AjoraChatScrollToBottomButtonProps): React.JSX.Element | null;
interface AjoraChatScrollViewProps {
    autoScroll?: boolean;
    isStreaming?: boolean;
    /** The full message array. Used for FlashList virtualization (`data`)
     *  and for streaming/last-message change detection in `useAutoScroll`. */
    messages?: Message[];
    /** Per-message render function. Receives one already-deduped message
     *  plus its index and returns the cell content. The default callsite
     *  produces this via `useRenderMessage` from `AjoraChatMessageView`. */
    renderMessage?: (message: Message, index: number) => React.ReactElement | null;
    /** Rendered above the virtualized message list (banners: history error,
     *  load-earlier). Stays visible during scroll like a non-sticky header. */
    listHeaderComponent?: React.ReactElement | null;
    /** Rendered below the virtualized message list (thinking indicator,
     *  run-error, suggestions). */
    listFooterComponent?: React.ReactElement | null;
    scrollToBottomButton?: React.ReactElement | null;
    showScrollToBottomButton?: boolean;
    style?: StyleProp<ViewStyle>;
    contentContainerStyle?: StyleProp<ViewStyle>;
    /** Fired when the user scrolls into the top threshold. Wired by the
     *  parent to `loadEarlierMessages` so pagination is automatic. */
    onScrolledToTop?: () => void;
    /** Active thread id. Enables per-thread scroll-position memory. */
    threadId?: string;
    /** Optional custom scroll component for the underlying FlashList. Used by
     *  BottomSheet-hosted chat views to wire FlashList's scroll events into
     *  @gorhom/bottom-sheet via `useBottomSheetScrollableCreator`, so vertical
     *  pans inside the list scroll the list instead of dragging the sheet. */
    renderScrollComponent?: any;
}
export declare function AjoraChatScrollView({ autoScroll, isStreaming, messages, renderMessage, listHeaderComponent, listFooterComponent, scrollToBottomButton, showScrollToBottomButton, style, contentContainerStyle, onScrolledToTop, threadId, renderScrollComponent, }: AjoraChatScrollViewProps): React.JSX.Element;
/**
 * Main AjoraChatView component with keyboard handling
 * Wraps content in KeyboardProvider for proper keyboard animation
 */
export declare function AjoraChatView(props: AjoraChatViewProps): React.JSX.Element;
export default AjoraChatView;
