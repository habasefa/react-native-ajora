import React, { FC } from "react";
import { StyleProp, ViewStyle, TextStyle } from "react-native";
import { SuggestionsProvidedProps } from "react-native-controlled-mentions";
import { Ionicons } from "@expo/vector-icons";
export interface MentionSuggestion {
    id: string;
    name: string;
    image?: string;
    subtitle?: string;
    icon?: keyof typeof Ionicons.glyphMap;
}
export interface AjoraMentionSuggestionsTheme {
    container?: StyleProp<ViewStyle>;
    item?: StyleProp<ViewStyle>;
    itemText?: StyleProp<TextStyle>;
    itemSubtitle?: StyleProp<TextStyle>;
    colors?: {
        background?: string;
        text?: string;
        subtitle?: string;
        border?: string;
        highlight?: string;
    };
}
export interface AjoraMentionSuggestionsProps extends Omit<SuggestionsProvidedProps, "onSelect"> {
    suggestions?: MentionSuggestion[];
    theme?: AjoraMentionSuggestionsTheme;
    onSelect: (suggestion: MentionSuggestion) => void;
    maxHeight?: number;
    loading?: boolean;
    SuggestionItem?: React.ComponentType<any>;
    maxSuggestions?: number;
}
export declare const AjoraMentionSuggestions: FC<AjoraMentionSuggestionsProps>;
