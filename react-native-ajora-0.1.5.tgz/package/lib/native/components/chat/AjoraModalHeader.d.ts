import * as React from "react";
import { StyleProp, ViewStyle, TextStyle } from "react-native";
import { WithSlots } from "../../lib/slots";
type HeaderSlots = {
    titleContent: typeof AjoraModalHeader.Title;
    closeButton: typeof AjoraModalHeader.CloseButton;
};
type HeaderRestProps = {
    title?: string;
    style?: StyleProp<ViewStyle>;
};
export type AjoraModalHeaderProps = WithSlots<HeaderSlots, HeaderRestProps>;
export declare function AjoraModalHeader({ title, titleContent, closeButton, children, style, ...rest }: AjoraModalHeaderProps): React.JSX.Element;
export declare namespace AjoraModalHeader {
    const Title: React.FC<{
        children: React.ReactNode;
        style?: StyleProp<TextStyle>;
    }>;
    const CloseButton: React.FC<{
        onPress?: () => void;
        style?: StyleProp<ViewStyle>;
    }>;
}
export default AjoraModalHeader;
