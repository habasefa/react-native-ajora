import React from "react";
import { AjoraChatProps } from "./AjoraChat";
import { AjoraPopupViewProps } from "./AjoraPopupView";
export type AjoraPopupProps = Omit<AjoraChatProps, "chatView"> & {
    header?: AjoraPopupViewProps["header"];
    defaultOpen?: boolean;
};
export declare function AjoraPopup({ header, defaultOpen, ...chatProps }: AjoraPopupProps): React.JSX.Element;
export declare namespace AjoraPopup {
    var displayName: string;
}
export default AjoraPopup;
