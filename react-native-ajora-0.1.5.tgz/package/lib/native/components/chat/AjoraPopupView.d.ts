import React from "react";
import { StyleProp, ViewStyle } from "react-native";
import { AjoraChatViewProps } from "./AjoraChatView";
import { AjoraModalHeader } from "./AjoraModalHeader";
import { SlotValue } from "../../lib/slots";
export type AjoraPopupViewProps = AjoraChatViewProps & {
    header?: SlotValue<typeof AjoraModalHeader>;
    style?: StyleProp<ViewStyle>;
};
export declare function AjoraPopupView({ header, style, ...restProps }: AjoraPopupViewProps): React.JSX.Element;
export declare namespace AjoraPopupView {
    var displayName: string;
}
export default AjoraPopupView;
