import React from "react";
import { AjoraChatProps } from "./AjoraChat";
import { AjoraSidebarViewProps } from "./AjoraSidebarView";
export type AjoraSidebarProps = Omit<AjoraChatProps, "chatView"> & {
    header?: AjoraSidebarViewProps["header"];
    defaultOpen?: boolean;
    /** Placeholder text for the collapsed input bar */
    collapsedPlaceholder?: string;
};
export declare function AjoraSidebar({ header, defaultOpen, collapsedPlaceholder, ...chatProps }: AjoraSidebarProps): React.JSX.Element;
export declare namespace AjoraSidebar {
    var displayName: string;
}
export default AjoraSidebar;
