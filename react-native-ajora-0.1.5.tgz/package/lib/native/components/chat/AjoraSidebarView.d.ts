import React from "react";
import { StyleProp, ViewStyle } from "react-native";
import { AjoraChatViewProps } from "./AjoraChatView";
import { AjoraModalHeader } from "./AjoraModalHeader";
import { SlotValue } from "../../lib/slots";
export type AjoraSidebarViewProps = AjoraChatViewProps & {
    header?: SlotValue<typeof AjoraModalHeader>;
    style?: StyleProp<ViewStyle>;
    /** Placeholder text for the collapsed input bar */
    collapsedPlaceholder?: string;
    /**
     * Renderer for the collapsed affordance (shown when the sheet is closed).
     * Receives `onPress` to open the sheet. Defaults to the bundled pill-shaped
     * input bar. Provide a custom component — e.g. a floating action button —
     * when the host screen's layout demands a smaller footprint.
     */
    collapsed?: SlotValue<typeof CollapsedInputBar>;
};
export declare function CollapsedInputBar({ placeholder, onPress, }: {
    placeholder?: string;
    onPress: () => void;
}): React.JSX.Element;
export declare function AjoraSidebarView({ header, style, collapsedPlaceholder, collapsed, ...props }: AjoraSidebarViewProps): React.JSX.Element;
export declare namespace AjoraSidebarView {
    var displayName: string;
}
export default AjoraSidebarView;
