import * as React from "react";
import { StyleProp, ViewStyle } from "react-native";
export interface MessageAttachmentsProps {
    content: unknown;
    align?: "flex-start" | "flex-end";
    style?: StyleProp<ViewStyle>;
}
/**
 * Renders `binary` content parts attached to a message — images as
 * lightbox-capable thumbnails, non-images as tappable file chips. Returns
 * `null` when the content has no binary parts so callers can drop it in
 * unconditionally.
 */
export declare const MessageAttachments: React.FC<MessageAttachmentsProps>;
export default MessageAttachments;
