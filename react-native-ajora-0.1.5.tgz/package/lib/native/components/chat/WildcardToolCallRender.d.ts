/**
 * WildcardToolCallRender for React Native.
 * Provides a fallback renderer for any tool call that doesn't have a specific renderer.
 */
export declare const WildcardToolCallRender: import("../..").ReactToolCallRenderer<any>;
export default WildcardToolCallRender;
