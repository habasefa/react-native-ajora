import React from "react";
import { StyleProp, ViewStyle, TextStyle } from "react-native";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { Ionicons } from "@expo/vector-icons";
export interface AgentOption {
    id: string;
    name: string;
    description?: string;
    icon?: keyof typeof Ionicons.glyphMap;
    /** Whether this agent is disabled (not selectable) */
    isDisabled?: boolean;
    /** Badge (e.g. "New" badge) */
    badge?: string;
    /** Any additional data for the agent */
    extraData?: any;
}
export interface AgentPickerSheetIcons {
    back?: React.ReactNode;
    close?: React.ReactNode;
    check?: React.ReactNode;
    lock?: React.ReactNode;
    empty?: React.ReactNode;
}
export interface AgentPickerSheetProps {
    /** Currently selected agent ID */
    selectedAgentId?: string;
    /** Callback when an agent is selected */
    onSelect?: (agent: AgentOption) => void;
    /** Callback when the sheet is closed */
    onClose?: () => void;
    /** Agent options - if not provided, nothing is shown */
    agents?: AgentOption[];
    /** Sheet title */
    title?: string;
    /** Sheet description */
    description?: string;
    /** Test ID for testing */
    testID?: string;
    /** Custom icons */
    icons?: AgentPickerSheetIcons;
    /** Style for the sheet container (top-level) */
    containerStyle?: StyleProp<ViewStyle>;
    /** Style for the sheet content background */
    sheetContentStyle?: StyleProp<ViewStyle>;
    /** Style for the sheet header */
    sheetHeaderStyle?: StyleProp<ViewStyle>;
    /** Style for the sheet title text */
    sheetTitleStyle?: StyleProp<TextStyle>;
    /** Style for the scroll view content container */
    listContentStyle?: StyleProp<ViewStyle>;
    /** Style for each item container */
    itemStyle?: StyleProp<ViewStyle>;
    /** Style for item text (name) */
    itemTextStyle?: StyleProp<TextStyle>;
    /** Style for active/selected item container */
    activeItemStyle?: StyleProp<ViewStyle>;
    /** Style for active/selected item text */
    activeItemTextStyle?: StyleProp<TextStyle>;
    /** Custom render function for each agent item */
    renderItem?: (props: {
        item: AgentOption;
        isSelected: boolean;
        isDisabled: boolean;
        onPress: () => void;
        theme: any;
    }) => React.ReactNode;
    /** Custom render function for header */
    renderHeader?: (props: {
        title: string;
        onClose?: () => void;
    }) => React.ReactNode;
    /** Custom colors override (highest priority) */
    colors?: {
        text?: string;
        textSecondary?: string;
        border?: string;
        optionBackground?: string;
        optionBackgroundPressed?: string;
        selectedBackground?: string;
        selectedBorder?: string;
        selectedText?: string;
        iconColor?: string;
        iconBackground?: string;
        handleIndicator?: string;
        background?: string;
        disabledBackground?: string;
        disabledText?: string;
        badgeBackground?: string;
        badgeText?: string;
    };
}
export declare const AgentPickerSheet: React.ForwardRefExoticComponent<AgentPickerSheetProps & React.RefAttributes<BottomSheetModal>>;
export default AgentPickerSheet;
