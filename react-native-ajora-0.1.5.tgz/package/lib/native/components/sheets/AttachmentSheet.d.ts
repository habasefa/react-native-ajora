import React from "react";
import { StyleProp, ViewStyle, TextStyle } from "react-native";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { Ionicons } from "@expo/vector-icons";
import { type AttachmentSource } from "../../lib/fileSystem";
export type AttachmentType = AttachmentSource;
export interface AttachmentOption {
    id: AttachmentType;
    label: string;
    description?: string;
    icon: keyof typeof Ionicons.glyphMap;
}
export interface AttachmentSheetIcons {
    close?: React.ReactNode;
}
export interface AttachmentSheetProps {
    /** Callback when an attachment option is selected */
    onSelect?: (type: AttachmentType) => void;
    /** Callback when the sheet is closed */
    onClose?: () => void;
    /** Custom attachment options */
    options?: AttachmentOption[];
    /** Test ID for testing */
    testID?: string;
    /** Custom icons */
    icons?: AttachmentSheetIcons;
    /** Style for the sheet container (top-level) */
    containerStyle?: StyleProp<ViewStyle>;
    /** Style for the sheet content background */
    sheetContentStyle?: StyleProp<ViewStyle>;
    /** Style for the sheet header */
    sheetHeaderStyle?: StyleProp<ViewStyle>;
    /** Style for the sheet title text */
    sheetTitleStyle?: StyleProp<TextStyle>;
    /** Style for the options container */
    optionsContainerStyle?: StyleProp<ViewStyle>;
    /** Style for each option item container */
    optionItemStyle?: StyleProp<ViewStyle>;
    /** Style for option label text */
    optionLabelStyle?: StyleProp<TextStyle>;
    /** Custom render function for each attachment option */
    renderItem?: (props: {
        item: AttachmentOption;
        onPress: () => void;
        theme: any;
    }) => React.ReactNode;
    /** Custom render function for header */
    renderHeader?: (props: {
        title: string;
        onClose?: () => void;
    }) => React.ReactNode;
    /** Custom colors override (highest priority) */
    colors?: {
        text?: string;
        textSecondary?: string;
        border?: string;
        optionBackground?: string;
        optionBackgroundPressed?: string;
        iconColor?: string;
        iconBackground?: string;
        handleIndicator?: string;
        background?: string;
    };
}
export declare const AttachmentSheet: React.ForwardRefExoticComponent<AttachmentSheetProps & React.RefAttributes<BottomSheetModal>>;
export default AttachmentSheet;
