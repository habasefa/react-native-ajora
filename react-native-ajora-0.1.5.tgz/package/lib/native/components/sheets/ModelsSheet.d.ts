import React from "react";
import { StyleProp, ViewStyle, TextStyle } from "react-native";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
export interface ModelOption {
    id: string;
    name: string;
    provider?: string;
    description?: string;
    tier?: string;
    contextWindow?: string;
    /** Whether this model is disabled (not selectable) */
    isDisabled?: boolean;
    /** Badge (e.g. "New" badge) */
    badge?: string;
    /** Any additional data for the model */
    extraData?: any;
}
export interface ModelsSheetIcons {
    back?: React.ReactNode;
    close?: React.ReactNode;
    check?: React.ReactNode;
    lock?: React.ReactNode;
    empty?: React.ReactNode;
}
export interface ModelsSheetProps {
    /** Currently selected model ID */
    selectedModelId?: string;
    /** Callback when a model is selected */
    onSelect?: (model: ModelOption) => void;
    /** Callback when the sheet is closed */
    onClose?: () => void;
    /** Model options - if not provided, nothing is shown */
    models?: ModelOption[];
    /** Sheet title */
    title?: string;
    /** Sheet description */
    description?: string;
    /** Test ID for testing */
    testID?: string;
    /** Custom icons */
    icons?: ModelsSheetIcons;
    /** Style for the sheet container (top-level) */
    containerStyle?: StyleProp<ViewStyle>;
    /** Style for the sheet content background */
    sheetContentStyle?: StyleProp<ViewStyle>;
    /** Style for the sheet header */
    sheetHeaderStyle?: StyleProp<ViewStyle>;
    /** Style for the sheet title text */
    sheetTitleStyle?: StyleProp<TextStyle>;
    /** Style for the scroll view content container */
    listContentStyle?: StyleProp<ViewStyle>;
    /** Style for each item container */
    itemStyle?: StyleProp<ViewStyle>;
    /** Style for item text (name) */
    itemTextStyle?: StyleProp<TextStyle>;
    /** Style for active/selected item container */
    activeItemStyle?: StyleProp<ViewStyle>;
    /** Style for active/selected item text */
    activeItemTextStyle?: StyleProp<TextStyle>;
    /** Custom render function for each model item */
    renderItem?: (props: {
        item: ModelOption;
        isSelected: boolean;
        isDisabled: boolean;
        onPress: () => void;
        theme: any;
    }) => React.ReactNode;
    /** Custom render function for header */
    renderHeader?: (props: {
        title: string;
        onClose?: () => void;
    }) => React.ReactNode;
    /** Custom colors override (highest priority) */
    colors?: {
        text?: string;
        textSecondary?: string;
        border?: string;
        optionBackground?: string;
        optionBackgroundPressed?: string;
        selectedBackground?: string;
        selectedBorder?: string;
        selectedText?: string;
        iconColor?: string;
        handleIndicator?: string;
        background?: string;
        disabledBackground?: string;
        disabledText?: string;
        badgeBackground?: string;
        badgeText?: string;
    };
}
export declare const ModelsSheet: React.ForwardRefExoticComponent<ModelsSheetProps & React.RefAttributes<BottomSheetModal>>;
export default ModelsSheet;
