import { BottomSheetModal } from "@gorhom/bottom-sheet";
import React from "react";
import { UserMessage } from "@ag-ui/core";
interface UserMessageActionSheetProps {
    message?: UserMessage;
    onRegenerate?: (message: UserMessage) => void;
    onCopy?: (message: UserMessage) => void;
    onClose?: () => void;
}
declare const UserMessageActionSheet: React.ForwardRefExoticComponent<UserMessageActionSheetProps & React.RefAttributes<BottomSheetModal>>;
export default UserMessageActionSheet;
