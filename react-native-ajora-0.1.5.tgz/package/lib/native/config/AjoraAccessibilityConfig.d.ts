/**
 * Accessibility labels for all interactive elements
 */
export interface AjoraAccessibilityLabels {
    /** Send button label */
    sendButton: string;
    /** Stop button label */
    stopButton: string;
    /** Chat input field label */
    chatInput: string;
    /** Chat input hint */
    chatInputHint: string;
    /** Message list label */
    messageList: string;
    /** User message prefix */
    userMessagePrefix: string;
    /** Assistant message prefix */
    assistantMessagePrefix: string;
    /** Attachment button label */
    attachmentButton: string;
    /** Microphone button label */
    microphoneButton: string;
    /** Model selector label */
    modelSelector: string;
    /** Agent selector label */
    agentSelector: string;
    /** Scroll to bottom button */
    scrollToBottomButton: string;
    /** Copy message button */
    copyButton: string;
    /** Regenerate response button */
    regenerateButton: string;
    /** Suggestion pill prefix */
    suggestionPrefix: string;
}
/**
 * Complete accessibility configuration
 */
export interface AjoraAccessibilityConfig {
    /** Custom labels for accessibility */
    labels: AjoraAccessibilityLabels;
    /** Announce new messages to screen readers */
    announceNewMessages: boolean;
    /** Announce when AI is thinking/typing */
    announceThinking: boolean;
    /** Reduce motion for users with vestibular disorders */
    reduceMotion: boolean;
    /** High contrast mode for better visibility */
    highContrast: boolean;
    /** Minimum touch target size in pixels (WCAG recommends 44px) */
    minimumTouchTarget: number;
    /** Enable keyboard navigation */
    keyboardNavigation: boolean;
    /** Focus ring visibility */
    showFocusRing: boolean;
}
/**
 * Default accessibility labels
 */
export declare const defaultAccessibilityLabels: AjoraAccessibilityLabels;
/**
 * Default accessibility configuration
 */
export declare const defaultAccessibilityConfig: AjoraAccessibilityConfig;
/**
 * Color overrides for high contrast mode
 */
export declare const highContrastColorOverrides: {
    light: {
        text: string;
        textSecondary: string;
        border: string;
        userBubble: string;
        userBubbleText: string;
        assistantBubble: string;
        assistantBubbleText: string;
    };
    dark: {
        text: string;
        textSecondary: string;
        border: string;
        userBubble: string;
        userBubbleText: string;
        assistantBubble: string;
        assistantBubbleText: string;
    };
};
/**
 * Create custom accessibility config by merging with defaults
 */
export declare function createAccessibilityConfig(customConfig: Partial<AjoraAccessibilityConfig>): AjoraAccessibilityConfig;
/**
 * Generate screen reader announcement for a new message
 */
export declare function getMessageAnnouncement(role: "user" | "assistant", content: string, labels: AjoraAccessibilityLabels): string;
