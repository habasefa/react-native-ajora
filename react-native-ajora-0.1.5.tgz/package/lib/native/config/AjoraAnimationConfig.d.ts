/**
 * Animation entrance/exit types for messages
 */
export type AjoraAnimationType = "slideUp" | "slideDown" | "fadeIn" | "fadeOut" | "scale" | "spring" | "none";
/**
 * Spring animation configuration
 */
export interface AjoraSpringConfig {
    /** Damping ratio (default: 15) */
    damping: number;
    /** Stiffness (default: 150) */
    stiffness: number;
    /** Mass (default: 1) */
    mass: number;
}
/**
 * Timing animation configuration
 */
export interface AjoraTimingConfig {
    /** Duration in milliseconds */
    duration: number;
    /** Easing function name */
    easing: "linear" | "easeIn" | "easeOut" | "easeInOut" | "bezier";
}
/**
 * Complete animation configuration for Ajora components
 */
export interface AjoraAnimationConfig {
    /** Enable/disable all animations */
    enabled: boolean;
    /** Respect system reduce motion setting */
    respectReduceMotion: boolean;
    /** Message animations */
    message: {
        /** Animation when message enters */
        enter: AjoraAnimationType;
        /** Animation when message exits */
        exit: AjoraAnimationType;
        /** Duration in ms (for timing animations) */
        duration: number;
        /** Spring config (for spring animations) */
        spring: AjoraSpringConfig;
    };
    /** Typing indicator animations */
    typingIndicator: {
        enabled: boolean;
        /** Dot pulse animation speed in ms */
        pulseSpeed: number;
    };
    /** Suggestion pills animations */
    suggestions: {
        enabled: boolean;
        /** Stagger delay between each pill */
        staggerDelay: number;
        /** Animation type */
        type: AjoraAnimationType;
    };
    /** Scroll to bottom button */
    scrollButton: {
        enabled: boolean;
        /** Fade in/out duration */
        duration: number;
    };
    /** Input area animations */
    input: {
        /** Animate height changes */
        animateHeight: boolean;
        /** Button press feedback */
        buttonFeedback: boolean;
    };
}
/**
 * Default animation configuration
 */
export declare const defaultAnimationConfig: AjoraAnimationConfig;
/**
 * Minimal animation configuration (subtle animations)
 */
export declare const minimalAnimationConfig: AjoraAnimationConfig;
/**
 * No animations configuration
 */
export declare const noAnimationConfig: AjoraAnimationConfig;
/**
 * Spring-heavy configuration (bouncy feel)
 */
export declare const springAnimationConfig: AjoraAnimationConfig;
/**
 * Merge custom animation config with defaults
 */
export declare function createAnimationConfig(customConfig: Partial<AjoraAnimationConfig>): AjoraAnimationConfig;
