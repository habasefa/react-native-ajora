/**
 * Test helpers for native hook tests.
 *
 * Provides a lightweight renderWithAjora wrapper that creates a real
 * AjoraCoreReact instance and injects it via context, avoiding heavy
 * React Native provider setup.
 */
import React from "react";
import { RenderOptions, RenderResult } from "@testing-library/react";
import { AjoraCoreReact } from "../../lib/react-core";
import { AjoraContextValue } from "../../providers/AjoraProvider";
import { AbstractAgent } from "@ag-ui/client";
export { MockAgent } from "../../../core/__tests__/test-utils";
/**
 * Minimal AjoraContext reproduction for testing hooks outside of
 * AjoraProvider (which pulls in React Native modules we can't load in jsdom).
 */
declare const AjoraContext: React.Context<AjoraContextValue>;
/** Re-export so hooks can resolve via the same reference. */
export { AjoraContext };
interface RenderWithAjoraOptions {
    agents?: Record<string, AbstractAgent>;
    runtimeUrl?: string;
    executingToolCallIds?: ReadonlySet<string>;
    renderOptions?: Omit<RenderOptions, "wrapper">;
}
/**
 * Creates a real AjoraCoreReact and wraps children with a context provider.
 */
export declare function renderWithAjora(ui: React.ReactElement, options?: RenderWithAjoraOptions): RenderResult & {
    ajora: AjoraCoreReact;
};
