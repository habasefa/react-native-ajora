/**
 * Represents any value that can be serialized to JSON.
 */
export type JsonSerializable = string | number | boolean | null | JsonSerializable[] | {
    [key: string]: JsonSerializable;
};
/**
 * Context configuration for useAgentContext.
 * Accepts any JSON-serializable value which will be converted to a string.
 */
export interface AgentContextInput {
    /** A human-readable description of what this context represents */
    description: string;
    /** The context value - will be converted to a JSON string if not already a string */
    value: JsonSerializable;
}
export declare function useAgentContext(context: AgentContextInput): void;
