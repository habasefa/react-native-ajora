import { AbstractAgent } from "@ag-ui/client";
export declare enum UseAgentUpdate {
    OnMessagesChanged = "OnMessagesChanged",
    OnStateChanged = "OnStateChanged",
    OnRunStatusChanged = "OnRunStatusChanged"
}
export interface UseAgentProps {
    agentId?: string;
    updates?: UseAgentUpdate[];
}
export declare function useAgent({ agentId, updates }?: UseAgentProps): {
    agent: AbstractAgent;
};
