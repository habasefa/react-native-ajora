import type { FileAttachment } from "../lib/fileSystem";
import { type AttachmentLimits, type UploadAttachmentFn } from "../lib/uploader";
export interface AttachmentAddResult {
    accepted: FileAttachment[];
    rejected: Array<{
        file: FileAttachment;
        reason: string;
    }>;
}
export interface UseAttachmentUploaderOptions {
    uploadAttachment?: UploadAttachmentFn;
    limits?: AttachmentLimits;
}
export interface UseAttachmentUploaderResult {
    attachments: FileAttachment[];
    add: (files: FileAttachment[]) => AttachmentAddResult;
    remove: (id: string) => void;
    retry: (id: string) => void;
    clear: () => void;
    /** No attachments, or every attachment is terminal "uploaded". */
    allSettled: boolean;
    /** Any attachment currently uploading. Send button should be disabled. */
    isUploading: boolean;
    /** Any attachment in error state. User must retry or remove. */
    hasErrors: boolean;
}
/**
 * Owns the lifecycle of in-progress attachment uploads for a single composer.
 *
 * Responsibilities:
 * - Validate files against {@link AttachmentLimits} before they enter state
 *   (rejected files are returned to the caller, never added to the list).
 * - Start an upload per accepted file with its own AbortController.
 * - Throttle progress updates to avoid re-render storms.
 * - Abort in-flight uploads on remove/clear/unmount.
 * - Expose gating flags (`isUploading`, `hasErrors`, `allSettled`) so the UI
 *   can block send until every attachment is terminal.
 */
export declare function useAttachmentUploader(options: UseAttachmentUploaderOptions): UseAttachmentUploaderResult;
