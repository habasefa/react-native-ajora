import { DynamicSuggestionsConfig, StaticSuggestionsConfig, Suggestion } from "../../core";
type StaticSuggestionInput = Omit<Suggestion, "isLoading"> & Partial<Pick<Suggestion, "isLoading">>;
type StaticSuggestionsConfigInput = Omit<StaticSuggestionsConfig, "suggestions"> & {
    suggestions: StaticSuggestionInput[];
};
type SuggestionsConfigInput = DynamicSuggestionsConfig | StaticSuggestionsConfigInput;
export declare function useConfigureSuggestions(config: SuggestionsConfigInput | null | undefined, deps?: ReadonlyArray<unknown>): void;
export {};
