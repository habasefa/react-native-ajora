import { ReactFrontendTool } from "../types";
export declare function useFrontendTool<T extends Record<string, unknown> = Record<string, unknown>>(tool: ReactFrontendTool<T>, deps?: ReadonlyArray<unknown>): void;
