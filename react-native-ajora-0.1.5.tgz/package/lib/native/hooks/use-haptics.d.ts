export interface AjoraHaptics {
    /** Light tap — streaming ticks, toolbar button presses, regenerate. */
    impactLight: () => void;
    /** Medium tap — discrete affirmative actions (thumbs up/down). */
    impactMedium: () => void;
    /** Success notification — e.g. copy succeeded. */
    notifySuccess: () => void;
    /** Error notification — e.g. copy failed. */
    notifyError: () => void;
}
/**
 * Single gate for every haptic in the library. Returns referentially-stable
 * callbacks that no-op unless the consumer opted in via
 * `<AjoraProvider preferences={{ hapticsEnabled }} />` (default is OFF — see
 * {@link DEFAULT_AJORA_PREFERENCES}) and `expo-haptics` is installed.
 *
 * The enabled flag is read through a ref so callbacks captured in long-lived
 * subscriptions (e.g. `useAgent`'s message subscription) always observe the
 * current preference without forcing a re-subscribe when it toggles.
 */
export declare function useAjoraHaptics(): AjoraHaptics;
