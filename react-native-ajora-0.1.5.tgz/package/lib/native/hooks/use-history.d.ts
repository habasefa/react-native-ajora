export interface UseHistoryProps {
    /** Agent to load history for. Defaults to `DEFAULT_AGENT_ID`. */
    agentId?: string;
    /** Active thread id. When null/undefined the hook is idle. */
    threadId?: string | null;
    /** Page size for each request. Defaults to 50. */
    pageSize?: number;
}
export interface UseHistoryResult {
    /** True while the initial page is loading for the current threadId. */
    isLoading: boolean;
    /** True while a "load earlier" page is in flight. */
    isLoadingMore: boolean;
    /** Whether older messages exist beyond the oldest currently loaded. */
    hasMore: boolean;
    /** Last error encountered (cleared on the next attempt). */
    error: Error | null;
    /**
     * Fetch the next earlier page of messages and prepend them to the agent's
     * `messages` array. No-op when there's no more history, when a load is
     * already in flight, or when the thread is empty.
     */
    loadMore: () => Promise<void>;
    /**
     * Force-refetch the initial page for the current thread. Useful after a
     * connection error or pull-to-refresh.
     */
    reload: () => Promise<void>;
}
/**
 * Loads persisted thread history into the agent's in-memory `messages` array
 * and exposes pagination state for a "Load earlier" UI.
 *
 * Behavior:
 *  - On `threadId` change, runs an initial load (`beforeMessageId` undefined)
 *    which replaces the agent's messages with the most recent page.
 *  - `loadMore()` fetches the previous page using `oldestMessageId` as the
 *    cursor and prepends it (deduped by id) to the existing messages.
 *  - In-flight requests for stale threadIds are discarded so rapid thread
 *    switches don't race.
 */
export declare function useHistory({ agentId, threadId, pageSize, }: UseHistoryProps): UseHistoryResult;
