import { ReactHumanInTheLoop } from "../types";
export declare function useHumanInTheLoop<T extends Record<string, unknown> = Record<string, unknown>>(tool: ReactHumanInTheLoop<T>, deps?: ReadonlyArray<unknown>): void;
