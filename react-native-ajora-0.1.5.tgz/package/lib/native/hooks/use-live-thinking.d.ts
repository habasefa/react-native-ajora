import type { LiveThinkingState } from "../types/thinking";
export interface UseLiveThinkingProps {
    agentId?: string;
}
/**
 * Live snapshot of the in-flight thinking buffer for an agent.
 *
 * Returns `{ title, text, isActive }`. `isActive` is true while a thinking
 * stream is open (between `THINKING_START` and the next `TEXT_MESSAGE_START`
 * or `THINKING_END`). When idle, `text` is empty.
 *
 * Intended for the in-flight indicator only — persisted thinking lives on the
 * assistant message itself (see {@link AjoraAssistantMessage.thinking}).
 */
export declare function useLiveThinking({ agentId, }?: UseLiveThinkingProps): LiveThinkingState;
