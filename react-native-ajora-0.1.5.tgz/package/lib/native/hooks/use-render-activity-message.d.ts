import { ActivityMessage } from "@ag-ui/core";
import { ReactActivityMessageRenderer } from "../types";
export declare function useRenderActivityMessage(): {
    renderActivityMessage: (message: ActivityMessage) => React.ReactElement | null;
    findRenderer: (activityType: string) => ReactActivityMessageRenderer<unknown> | null;
};
