import { ReactCustomMessageRendererPosition } from "../types/react-custom-message-renderer";
import { Message } from "@ag-ui/core";
interface UseRenderCustomMessagesParams {
    message: Message;
    position: ReactCustomMessageRendererPosition;
}
export declare function useRenderCustomMessages(): ((params: UseRenderCustomMessagesParams) => import("react").JSX.Element | null) | null;
export {};
