import React from "react";
import { ToolCall, ToolMessage } from "@ag-ui/core";
export interface UseRenderToolCallProps {
    toolCall: ToolCall;
    toolMessage?: ToolMessage;
}
/**
 * Hook that returns a function to render tool calls based on the render functions
 * defined in CopilotKitProvider.
 *
 * @returns A function that takes a tool call and optional tool message and returns the rendered component
 */
export declare function useRenderToolCall(): ({ toolCall, toolMessage, }: UseRenderToolCallProps) => React.ReactElement | null;
