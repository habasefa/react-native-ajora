import type { ThreadRecord, CreateThreadRequest } from "../../core";
export interface UseThreadsProps {
    /** Agent whose runtime provides the threads endpoint. Defaults to DEFAULT_AGENT_ID. */
    agentId?: string;
    /** Resource / user ID to filter threads by. Required. */
    resourceId: string;
    /** Page size for each request. Defaults to 20. */
    pageSize?: number;
}
export interface UseThreadsResult {
    /** The currently loaded threads (newest first from API). */
    threads: ThreadRecord[];
    /** True while the initial page is loading. */
    isLoading: boolean;
    /** True while a "load more" page is in flight. */
    isLoadingMore: boolean;
    /** Whether older threads exist beyond the last loaded page. */
    hasMore: boolean;
    /** Last error encountered. */
    error: Error | null;
    /** Fetch the next page of threads and append them. */
    loadMore: () => Promise<void>;
    /** Re-fetch from the beginning. Useful after creating a thread. */
    reload: () => Promise<void>;
    /** Create a new thread and prepend it to the local list. */
    createThread: (request?: Omit<CreateThreadRequest, "signal">) => Promise<ThreadRecord>;
}
/**
 * Hook for listing and creating threads, backed by the server's
 * `/magnus/threads` endpoint. Exposes cursor-based pagination.
 */
export declare function useThreads({ agentId, resourceId, pageSize, }: UseThreadsProps): UseThreadsResult;
