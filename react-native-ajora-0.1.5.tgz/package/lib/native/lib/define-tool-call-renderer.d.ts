import React from "react";
import { z } from "zod";
import { ReactToolCallRenderer } from "../types";
import { ToolCallStatus } from "../../core";
type RenderProps<T> = {
    name: string;
    args: Partial<T>;
    status: ToolCallStatus.InProgress;
    result: undefined;
} | {
    name: string;
    args: T;
    status: ToolCallStatus.Executing;
    result: undefined;
} | {
    name: string;
    args: T;
    status: ToolCallStatus.Complete;
    result: string;
};
export declare function defineToolCallRenderer(def: {
    name: "*";
    render: (props: RenderProps<any>) => React.ReactElement;
    agentId?: string;
}): ReactToolCallRenderer<any>;
export declare function defineToolCallRenderer<S extends z.ZodTypeAny>(def: {
    name: string;
    args: S;
    render: (props: RenderProps<z.infer<S>>) => React.ReactElement;
    agentId?: string;
}): ReactToolCallRenderer<z.infer<S>>;
export {};
