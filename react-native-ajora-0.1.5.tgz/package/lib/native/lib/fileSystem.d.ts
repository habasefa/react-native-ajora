import * as ImagePicker from "expo-image-picker";
import * as FileSystem from "expo-file-system";
/**
 * Represents a file attachment with metadata
 */
/**
 * Attachment upload state
 */
export type AttachmentUploadState = "idle" | "uploading" | "uploaded" | "error";
/**
 * Represents a file attachment with metadata
 */
export interface FileAttachment {
    /** Unique identifier for the attachment */
    id: string;
    /** File URI (local path) */
    uri: string;
    /** File name to display */
    displayName: string;
    /** MIME type of the file */
    mimeType: string;
    /** File size in bytes */
    size?: number;
    /** File type: 'image', 'file', 'document' */
    type: "image" | "file" | "document";
    /** Upload state */
    uploadState: AttachmentUploadState;
    /** Upload progress (0-100) */
    uploadProgress?: number;
    /** Whether the file is from camera */
    isFromCamera?: boolean;
}
/**
 * Source of the attachment
 */
export type AttachmentSource = "camera" | "gallery" | "files";
/**
 * Options for picking images from gallery
 */
export interface ImagePickerOptions {
    /** Allow multiple selection */
    allowsMultipleSelection?: boolean;
    /** Allow editing before selection */
    allowsEditing?: boolean;
    /** Aspect ratio for editing [width, height] */
    aspect?: [number, number];
    /** Quality of the image (0-1) */
    quality?: number;
    /** Media types to pick */
    mediaTypes?: ImagePicker.MediaTypeOptions;
}
/**
 * Options for camera capture
 */
export interface CameraOptions {
    /** Allow editing before capture */
    allowsEditing?: boolean;
    /** Aspect ratio for editing [width, height] */
    aspect?: [number, number];
    /** Quality of the image/video (0-1) */
    quality?: number;
    /** Media type to capture */
    mediaTypes?: ImagePicker.MediaTypeOptions;
    /** Video quality */
    videoQuality?: number;
    /** Maximum duration for video in seconds */
    videoMaxDuration?: number;
}
/**
 * Options for document picker
 */
export interface DocumentPickerOptions {
    /** MIME types to allow */
    type?: string | string[];
    /** Whether to copy file to cache directory */
    copyToCacheDirectory?: boolean;
    /** Whether to allow multiple selection */
    multiple?: boolean;
}
/**
 * Result of a file operation
 */
export interface FileOperationResult {
    /** Whether the operation was successful */
    success: boolean;
    /** Error message if operation failed */
    error?: string;
    /** File attachment if successful */
    attachment?: FileAttachment;
    /** Multiple file attachments if multiple selection */
    attachments?: FileAttachment[];
}
/**
 * Request camera permission
 */
export declare function requestCameraPermission(): Promise<boolean>;
/**
 * Request media library permission
 */
export declare function requestMediaLibraryPermission(): Promise<boolean>;
/**
 * Take a photo using the camera
 */
export declare function takePhoto(options?: CameraOptions): Promise<FileOperationResult>;
/**
 * Pick images from the gallery
 */
export declare function pickImages(options?: ImagePickerOptions): Promise<FileOperationResult>;
/**
 * Pick videos from the gallery
 */
export declare function pickVideos(options?: ImagePickerOptions): Promise<FileOperationResult>;
/**
 * Pick documents/files
 */
export declare function pickDocuments(options?: DocumentPickerOptions): Promise<FileOperationResult>;
/**
 * Get file info from URI
 */
export declare function getFileInfo(uri: string): Promise<FileSystem.FileInfo | null>;
/**
 * Check if file exists
 */
export declare function fileExists(uri: string): Promise<boolean>;
/**
 * Read file as base64 string
 */
export declare function readFileAsBase64(uri: string): Promise<string | null>;
/**
 * Read file as string
 */
export declare function readFileAsString(uri: string): Promise<string | null>;
/**
 * Copy file to a new location
 */
export declare function copyFile(fromUri: string, toUri: string): Promise<boolean>;
/**
 * Delete a file
 */
export declare function deleteFile(uri: string): Promise<boolean>;
/**
 * Get file size in bytes
 */
export declare function getFileSize(uri: string): Promise<number | null>;
/**
 * Format file size to human-readable string
 */
export declare function formatFileSize(bytes: number): string;
/**
 * Handle attachment selection based on type
 * This is the main function to use with AttachmentSheet
 */
export declare function handleAttachmentSelection(type: AttachmentSource, options?: {
    camera?: CameraOptions;
    gallery?: ImagePickerOptions;
    files?: DocumentPickerOptions;
}): Promise<FileOperationResult>;
