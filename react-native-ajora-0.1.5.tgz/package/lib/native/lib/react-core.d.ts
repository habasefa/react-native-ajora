import { ReactActivityMessageRenderer, ReactToolCallRenderer, ReactCustomMessageRenderer } from "../types";
import { AjoraCore, AjoraCoreConfig, AjoraCoreSubscriber, AjoraCoreSubscription } from "../../core";
export interface AjoraCoreReactConfig extends AjoraCoreConfig {
    renderToolCalls?: ReactToolCallRenderer<any>[];
    renderActivityMessages?: ReactActivityMessageRenderer<any>[];
    renderCustomMessages?: ReactCustomMessageRenderer[];
}
export interface AjoraCoreReactSubscriber extends AjoraCoreSubscriber {
    onRenderToolCallsChanged?: (event: {
        ajora: AjoraCore;
        renderToolCalls: ReactToolCallRenderer<any>[];
    }) => void | Promise<void>;
}
export declare class AjoraCoreReact extends AjoraCore {
    private _renderToolCalls;
    private _renderCustomMessages;
    private _renderActivityMessages;
    constructor(config: AjoraCoreReactConfig);
    get renderCustomMessages(): Readonly<ReactCustomMessageRenderer[]>;
    get renderActivityMessages(): Readonly<ReactActivityMessageRenderer<any>>[];
    get renderToolCalls(): Readonly<ReactToolCallRenderer<any>>[];
    setRenderToolCalls(renderToolCalls: ReactToolCallRenderer<any>[]): void;
    subscribe(subscriber: AjoraCoreReactSubscriber): AjoraCoreSubscription;
}
