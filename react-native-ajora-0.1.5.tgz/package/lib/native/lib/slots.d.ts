import React from "react";
/**
 * Union for slot values.
 * In React Native, string slots (often used for classNames in web) are less common,
 * but reserved here for potential NativeWind or other usage.
 */
export type SlotValue<C extends React.ComponentType<any>> = C | string | Partial<React.ComponentProps<C>>;
/**
 * Shallow equality comparison for objects.
 */
export declare function shallowEqual<T extends Record<string, unknown>>(obj1: T, obj2: T): boolean;
/** Utility: concrete React elements for every slot */
type SlotElements<S> = {
    [K in keyof S]: React.ReactElement;
};
export type WithSlots<S extends Record<string, React.ComponentType<any>>, Rest = {}> = {
    [K in keyof S]?: SlotValue<S[K]>;
} & {
    children?: (props: SlotElements<S> & Rest) => React.ReactNode;
} & Omit<Rest, "children">;
/**
 * Renders a slot value as a memoized React element.
 * Automatically prevents unnecessary re-renders using shallow prop comparison.
 * Supports ref forwarding.
 *
 * @example
 * renderSlot(customInput, AjoraChatInput, { onSubmit: handleSubmit })
 */
export declare function renderSlot<C extends React.ComponentType<any>, P = React.ComponentProps<C>>(slot: SlotValue<C> | undefined, DefaultComponent: C, props: P): React.ReactElement;
export {};
