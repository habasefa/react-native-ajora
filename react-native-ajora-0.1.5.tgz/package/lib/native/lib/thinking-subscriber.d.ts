import { AbstractAgent } from "@ag-ui/client";
import type { LiveThinkingState } from "../types/thinking";
/**
 * Per-agent thinking subscriber.
 *
 * AG-UI thinking events (`THINKING_START`, `THINKING_TEXT_MESSAGE_CONTENT`,
 * `THINKING_END`) carry no `messageId`, so we buffer them client-side and
 * attach the resulting block to the next assistant message that materializes
 * (matched by `TEXT_MESSAGE_START.messageId`).
 *
 * Installed once per `AbstractAgent` instance via `installThinkingSubscriber`,
 * which is idempotent — subsequent calls are no-ops. State is held in
 * module-level `WeakMap`s so it's freed when the agent is garbage-collected.
 *
 * Two outputs:
 *   1. The buffered `ThinkingBlock` is mutated onto the matching assistant
 *      message as `(message as any).thinking` once it appears in
 *      `agent.messages`.
 *   2. A live snapshot is broadcast to listeners registered via
 *      `subscribeLiveThinking` so React hooks can render the in-flight UI.
 */
type Listener = (state: LiveThinkingState) => void;
export declare function installThinkingSubscriber(agent: AbstractAgent): void;
/**
 * Subscribe to live thinking state changes for an agent. Returns an
 * unsubscribe function. Safe to call before {@link installThinkingSubscriber};
 * the listener will start receiving snapshots once events arrive.
 */
export declare function subscribeLiveThinking(agent: AbstractAgent, listener: Listener): () => void;
/** Read the current live thinking snapshot synchronously. */
export declare function getLiveThinking(agent: AbstractAgent): LiveThinkingState;
export {};
