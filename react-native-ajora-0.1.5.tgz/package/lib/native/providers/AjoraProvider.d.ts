import React, { ReactNode } from "react";
import { AbstractAgent } from "@ag-ui/client";
import { AjoraCoreReact } from "../lib/react-core";
import { ReactToolCallRenderer, ReactActivityMessageRenderer, ReactCustomMessageRenderer, ReactFrontendTool, ReactHumanInTheLoop } from "../types";
export interface AjoraContextValue {
    ajora: AjoraCoreReact;
    executingToolCallIds: ReadonlySet<string>;
}
export interface AjoraProviderProps {
    children: ReactNode;
    runtimeUrl?: string;
    headers?: Record<string, string>;
    properties?: Record<string, unknown>;
    useSingleEndpoint?: boolean;
    agents__unsafe_dev_only?: Record<string, AbstractAgent>;
    renderToolCalls?: ReactToolCallRenderer<any>[];
    renderActivityMessages?: ReactActivityMessageRenderer<any>[];
    renderCustomMessages?: ReactCustomMessageRenderer[];
    frontendTools?: ReactFrontendTool[];
    humanInTheLoop?: ReactHumanInTheLoop[];
}
export declare const AjoraProvider: React.FC<AjoraProviderProps>;
export declare const useAjora: () => AjoraContextValue;
