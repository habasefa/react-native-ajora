import React, { ReactNode } from "react";
import { AjoraCoreRuntimeConnectionStatus } from "../../core";
import { AbstractAgent } from "@ag-ui/client";
import { AjoraCoreReact } from "../lib/react-core";
import { ReactToolCallRenderer, ReactActivityMessageRenderer, ReactCustomMessageRenderer, ReactFrontendTool, ReactHumanInTheLoop } from "../types";
import type { AttachmentLimits, UploadAttachmentFn } from "../lib/uploader";
export interface AjoraContextValue {
    ajora: AjoraCoreReact;
    executingToolCallIds: ReadonlySet<string>;
    /**
     * Runtime connection status mirrored into React state so consumers get a
     * single, batched re-render when the status changes — instead of each
     * `useAjora()` caller opening its own subscription (which previously
     * produced one forceUpdate per consumer per status change).
     */
    runtimeConnectionStatus: AjoraCoreRuntimeConnectionStatus;
    /**
     * Consumer-provided uploader for file attachments. When absent, the chat
     * input surfaces an "Upload handler not configured" error if a user tries
     * to attach something — the attach button itself is hidden by
     * {@link AjoraContextValue.attachmentsEnabled}.
     */
    uploadAttachment?: UploadAttachmentFn;
    /**
     * Optional overrides for attachment validation. Missing fields fall back to
     * `DEFAULT_ATTACHMENT_LIMITS`.
     */
    attachmentLimits?: AttachmentLimits;
    /**
     * True iff `uploadAttachment` is wired. The input uses this to decide
     * whether to render the attach button at all — avoids dead UI in apps that
     * haven't opted in.
     */
    attachmentsEnabled: boolean;
}
export interface AjoraProviderProps {
    children: ReactNode;
    runtimeUrl?: string;
    headers?: Record<string, string>;
    properties?: Record<string, unknown>;
    useSingleEndpoint?: boolean;
    agents__unsafe_dev_only?: Record<string, AbstractAgent>;
    renderToolCalls?: ReactToolCallRenderer<any>[];
    renderActivityMessages?: ReactActivityMessageRenderer<any>[];
    renderCustomMessages?: ReactCustomMessageRenderer[];
    frontendTools?: ReactFrontendTool[];
    humanInTheLoop?: ReactHumanInTheLoop[];
    /**
     * Uploader called for each attachment the user picks. The hook resolves
     * with a remote URL (and optional storage key); the library owns
     * cancellation, progress, retry, and sends the URL in the outgoing message
     * as a multimodal `binary` content part. When omitted, the attach button
     * is hidden.
     */
    uploadAttachment?: UploadAttachmentFn;
    /**
     * Overrides for attachment validation (max count, size, allowed MIME types).
     * Fields not set fall back to `DEFAULT_ATTACHMENT_LIMITS`.
     */
    attachmentLimits?: AttachmentLimits;
}
export declare const AjoraProvider: React.FC<AjoraProviderProps>;
export declare const useAjora: () => AjoraContextValue;
