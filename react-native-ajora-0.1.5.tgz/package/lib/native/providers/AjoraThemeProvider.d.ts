import React, { ReactNode } from "react";
/**
 * Shadow style compatible with React Native
 */
export interface AjoraShadow {
    shadowColor: string;
    shadowOffset: {
        width: number;
        height: number;
    };
    shadowOpacity: number;
    shadowRadius: number;
    elevation: number;
}
/**
 * Complete color palette for Ajora components
 */
export interface AjoraColors {
    /** Primary brand color */
    primary: string;
    /** Primary color variant (darker/lighter) */
    primaryVariant: string;
    /** Background color for screens */
    background: string;
    /** Surface color for cards/containers */
    surface: string;
    /** Primary text color */
    text: string;
    /** Secondary/muted text color */
    textSecondary: string;
    /** Border color */
    border: string;
    /** Error color */
    error: string;
    /** Success color */
    success: string;
    /** Warning color */
    warning: string;
    /** User message bubble background */
    userBubble: string;
    /** User message bubble text */
    userBubbleText: string;
    /** Assistant message bubble background */
    assistantBubble: string;
    /** Assistant message bubble text */
    assistantBubbleText: string;
    /** Input background */
    inputBackground: string;
    /** Placeholder text */
    placeholder: string;
    /** Icon default color */
    iconDefault: string;
    /** Icon active/highlighted color */
    iconActive: string;
    /** Selected item background (menus, lists) */
    itemSelected: string;
    /** Selected item text */
    itemSelectedText: string;
}
/**
 * Typography configuration
 */
export interface AjoraTypography {
    /** Font family for regular weight */
    regular: string;
    /** Font family for medium weight */
    medium: string;
    /** Font family for bold weight */
    bold: string;
    /** Font sizes */
    sizes: {
        xs: number;
        sm: number;
        md: number;
        lg: number;
        xl: number;
        xxl: number;
    };
    /** Line heights */
    lineHeights: {
        tight: number;
        normal: number;
        relaxed: number;
    };
}
/**
 * Spacing scale
 */
export interface AjoraSpacing {
    xs: number;
    sm: number;
    md: number;
    lg: number;
    xl: number;
    xxl: number;
}
/**
 * Border radius scale
 */
export interface AjoraBorderRadius {
    none: number;
    sm: number;
    md: number;
    lg: number;
    xl: number;
    full: number;
}
/**
 * Shadow presets
 */
export interface AjoraShadows {
    none: AjoraShadow;
    sm: AjoraShadow;
    md: AjoraShadow;
    lg: AjoraShadow;
}
/**
 * Complete Ajora theme configuration
 */
export interface AjoraTheme {
    /** Color scheme name */
    name: "light" | "dark" | "custom";
    /** Color palette */
    colors: AjoraColors;
    /** Typography settings */
    typography: AjoraTypography;
    /** Spacing scale */
    spacing: AjoraSpacing;
    /** Border radius scale */
    borderRadius: AjoraBorderRadius;
    /** Shadow presets */
    shadows: AjoraShadows;
}
/**
 * Deep partial type utility for nested partial objects
 */
export type DeepPartial<T> = {
    [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};
/**
 * Partial theme type for customization
 */
export type AjoraThemeCustomization = DeepPartial<Omit<AjoraTheme, "name">> & {
    name?: AjoraTheme["name"];
};
/**
 * Default light theme
 */
export declare const lightTheme: AjoraTheme;
/**
 * Default dark theme
 */
export declare const darkTheme: AjoraTheme;
export interface AjoraThemeProviderProps {
    children: ReactNode;
    /** Custom theme to use */
    theme?: AjoraThemeCustomization;
    /** Use dark mode (default: false) */
    darkMode?: boolean;
}
/**
 * Theme provider component
 * Wraps your app to provide theming to all Ajora components
 *
 * @example
 * ```tsx
 * <AjoraThemeProvider darkMode>
 *   <AjoraChat ... />
 * </AjoraThemeProvider>
 *
 * // With custom theme
 * <AjoraThemeProvider theme={{ colors: { primary: '#FF5722' } }}>
 *   <AjoraChat ... />
 * </AjoraThemeProvider>
 * ```
 */
export declare function AjoraThemeProvider({ children, theme, darkMode, }: AjoraThemeProviderProps): React.JSX.Element;
/**
 * Hook to access the current theme
 * Returns the default light theme if no provider is found
 *
 * @example
 * ```tsx
 * function MyComponent() {
 *   const theme = useAjoraTheme();
 *   return <View style={{ backgroundColor: theme.colors.background }} />;
 * }
 * ```
 */
export declare function useAjoraTheme(): AjoraTheme;
/**
 * Hook to access theme colors only
 * Convenience hook for simpler color access
 */
export declare function useAjoraColors(): AjoraColors;
/**
 * Hook to access theme spacing only
 */
export declare function useAjoraSpacing(): AjoraSpacing;
/**
 * Utility to create a custom theme by extending the base themes
 */
export declare function createAjoraTheme(customizations: AjoraThemeCustomization, baseTheme?: "light" | "dark"): AjoraTheme;
