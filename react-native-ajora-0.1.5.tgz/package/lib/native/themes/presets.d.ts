import { AjoraTheme } from "../providers/AjoraThemeProvider";
/**
 * Visual style variants for chat interface
 */
export type AjoraVariant = "default" | "minimal" | "bubbles" | "cards" | "compact";
/**
 * Size presets affecting spacing and typography
 */
export type AjoraSize = "sm" | "md" | "lg";
/**
 * Color scheme options
 */
export type AjoraColorScheme = "light" | "dark" | "system";
interface VariantConfig {
    borderRadius: Partial<AjoraTheme["borderRadius"]>;
    spacing: Partial<AjoraTheme["spacing"]>;
    bubbleStyle: {
        showTail: boolean;
        maxWidth: string;
        padding: number;
    };
    inputStyle: {
        borderWidth: number;
        borderRadius: number;
    };
}
interface SizeConfig {
    typography: Partial<AjoraTheme["typography"]["sizes"]>;
    spacing: Partial<AjoraTheme["spacing"]>;
    iconSize: number;
    avatarSize: number;
}
/**
 * Pre-built theme presets for common use cases
 */
export declare const themePresets: {
    /** Default light theme */
    light: AjoraTheme;
    /** Default dark theme */
    dark: AjoraTheme;
    /** Gemini-inspired dark theme */
    gemini: AjoraTheme;
    /** ChatGPT-inspired theme */
    chatgpt: AjoraTheme;
    /** Claude-inspired theme */
    claude: AjoraTheme;
};
/**
 * Get the style configuration for a variant
 */
export declare function getVariantConfig(variant: AjoraVariant): VariantConfig;
/**
 * Get the size configuration
 */
export declare function getSizeConfig(size: AjoraSize): SizeConfig;
/**
 * Create a themed style based on variant and size
 */
export declare function createPresetTheme(variant?: AjoraVariant, size?: AjoraSize, colorScheme?: AjoraColorScheme): AjoraTheme;
export {};
