import { AbstractAgent, BaseEvent, RunAgentInput, Message } from "@ag-ui/client";
import { LanguageModel, ModelMessage, ToolChoice, ToolSet } from "ai";
import { Observable } from "rxjs";
import { z } from "zod";
import { StreamableHTTPClientTransportOptions } from "@modelcontextprotocol/sdk/client/streamableHttp.js";
/**
 * Properties that can be overridden by forwardedProps
 * These match the exact parameter names in streamText
 */
export type OverridableProperty = "model" | "toolChoice" | "maxOutputTokens" | "temperature" | "topP" | "topK" | "presencePenalty" | "frequencyPenalty" | "stopSequences" | "seed" | "maxRetries" | "prompt";
/**
 * Supported model identifiers for BuiltInAgent
 */
export type BuiltInAgentModel = "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-4.1" | "openai/gpt-4.1-mini" | "openai/gpt-4.1-nano" | "openai/gpt-4o" | "openai/gpt-4o-mini" | "openai/o3" | "openai/o3-mini" | "openai/o4-mini" | "anthropic/claude-sonnet-4.5" | "anthropic/claude-sonnet-4" | "anthropic/claude-3.7-sonnet" | "anthropic/claude-opus-4.1" | "anthropic/claude-opus-4" | "anthropic/claude-3.5-haiku" | "google/gemini-2.5-pro" | "google/gemini-2.5-flash" | "google/gemini-2.5-flash-lite" | (string & {});
/**
 * Model specifier - can be a string like "openai/gpt-4o" or a LanguageModel instance
 */
export type ModelSpecifier = string | LanguageModel;
/**
 * MCP Client configuration for HTTP transport
 */
export interface MCPClientConfigHTTP {
    /**
     * Type of MCP client
     */
    type: "http";
    /**
     * URL of the MCP server
     */
    url: string;
    /**
     * Optional transport options for HTTP client
     */
    options?: StreamableHTTPClientTransportOptions;
}
/**
 * MCP Client configuration for SSE transport
 */
export interface MCPClientConfigSSE {
    /**
     * Type of MCP client
     */
    type: "sse";
    /**
     * URL of the MCP server
     */
    url: string;
    /**
     * Optional HTTP headers (e.g., for authentication)
     */
    headers?: Record<string, string>;
}
/**
 * MCP Client configuration
 */
export type MCPClientConfig = MCPClientConfigHTTP | MCPClientConfigSSE;
/**
 * Resolves a model specifier to a LanguageModel instance
 * @param spec - Model string (e.g., "openai/gpt-4o") or LanguageModel instance
 * @returns LanguageModel instance
 */
export declare function resolveModel(spec: ModelSpecifier): LanguageModel;
/**
 * Tool definition for BuiltInAgent
 */
export interface ToolDefinition<TParameters extends z.ZodTypeAny = z.ZodTypeAny> {
    name: string;
    description: string;
    parameters: TParameters;
    execute: (args: z.infer<TParameters>) => Promise<unknown>;
}
/**
 * Define a tool for use with BuiltInAgent
 * @param name - The name of the tool
 * @param description - Description of what the tool does
 * @param parameters - Zod schema for the tool's input parameters
 * @param execute - Function to execute the tool server-side
 * @returns Tool definition
 */
export declare function defineTool<TParameters extends z.ZodTypeAny>(config: {
    name: string;
    description: string;
    parameters: TParameters;
    execute: (args: z.infer<TParameters>) => Promise<unknown>;
}): ToolDefinition<TParameters>;
/**
 * Converts AG-UI messages to Vercel AI SDK ModelMessage format
 */
export declare function convertMessagesToVercelAISDKMessages(messages: Message[]): ModelMessage[];
/**
 * JSON Schema type definition
 */
interface JsonSchema {
    type: "object" | "string" | "number" | "boolean" | "array";
    description?: string;
    properties?: Record<string, JsonSchema>;
    required?: string[];
    items?: JsonSchema;
}
/**
 * Converts JSON Schema to Zod schema
 */
export declare function convertJsonSchemaToZodSchema(jsonSchema: JsonSchema, required: boolean): z.ZodSchema;
export declare function convertToolsToVercelAITools(tools: RunAgentInput["tools"]): ToolSet;
/**
 * Converts ToolDefinition array to Vercel AI SDK ToolSet
 */
export declare function convertToolDefinitionsToVercelAITools(tools: ToolDefinition[]): ToolSet;
/**
 * Configuration for BuiltInAgent
 */
export interface BuiltInAgentConfiguration {
    /**
     * The model to use
     */
    model: BuiltInAgentModel | LanguageModel;
    /**
     * Maximum number of steps/iterations for tool calling (default: 1)
     */
    maxSteps?: number;
    /**
     * Tool choice setting - how tools are selected for execution (default: "auto")
     */
    toolChoice?: ToolChoice<Record<string, unknown>>;
    /**
     * Maximum number of tokens to generate
     */
    maxOutputTokens?: number;
    /**
     * Temperature setting (range depends on provider)
     */
    temperature?: number;
    /**
     * Nucleus sampling (topP)
     */
    topP?: number;
    /**
     * Top K sampling
     */
    topK?: number;
    /**
     * Presence penalty
     */
    presencePenalty?: number;
    /**
     * Frequency penalty
     */
    frequencyPenalty?: number;
    /**
     * Sequences that will stop the generation
     */
    stopSequences?: string[];
    /**
     * Seed for deterministic results
     */
    seed?: number;
    /**
     * Maximum number of retries
     */
    maxRetries?: number;
    /**
     * Prompt for the agent
     */
    prompt?: string;
    /**
     * List of properties that can be overridden by forwardedProps.
     */
    overridableProperties?: OverridableProperty[];
    /**
     * Optional list of MCP server configurations
     */
    mcpServers?: MCPClientConfig[];
    /**
     * Optional tools available to the agent
     */
    tools?: ToolDefinition[];
}
export declare class BuiltInAgent extends AbstractAgent {
    private config;
    private abortController?;
    constructor(config: BuiltInAgentConfiguration);
    /**
     * Check if a property can be overridden by forwardedProps
     */
    canOverride(property: OverridableProperty): boolean;
    run(input: RunAgentInput): Observable<BaseEvent>;
    clone(): BuiltInAgent;
    abortRun(): void;
}
/**
 * @deprecated Use BuiltInAgent instead
 */
export declare class BasicAgent extends BuiltInAgent {
    constructor(config: BuiltInAgentConfiguration);
}
export type BasicAgentConfiguration = BuiltInAgentConfiguration;
export {};
