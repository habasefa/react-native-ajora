import { BaseEvent, HttpAgent, HttpAgentConfig, Message, RunAgentInput } from "@ag-ui/client";
import { Observable } from "rxjs";
import { AjoraRuntimeTransport } from "./types";
export interface ProxiedAjoraRuntimeAgentConfig extends Omit<HttpAgentConfig, "url"> {
    runtimeUrl?: string;
    transport?: AjoraRuntimeTransport;
}
export interface FetchHistoryRequest {
    threadId: string;
    /** Cursor: return messages that appear BEFORE this message id. */
    beforeMessageId?: string;
    /** Page size (default 50, server clamps to [1, 200]). */
    limit?: number;
}
export interface FetchHistoryResponse {
    /** Messages ordered oldest → newest. */
    messages: Message[];
    /** Whether more messages exist before `oldestMessageId`. */
    hasMore: boolean;
    /** Cursor to pass as `beforeMessageId` for the next "load earlier" page. */
    oldestMessageId: string | null;
}
export declare class FetchHistoryError extends Error {
    readonly status: number;
    constructor(message: string, status: number);
}
export declare class ProxiedAjoraRuntimeAgent extends HttpAgent {
    runtimeUrl?: string;
    private transport;
    private singleEndpointUrl?;
    constructor(config: ProxiedAjoraRuntimeAgentConfig);
    abortRun(): void;
    connect(input: RunAgentInput): Observable<BaseEvent>;
    run(input: RunAgentInput): Observable<BaseEvent>;
    /**
     * Fetch persisted messages for a thread from the runtime's history endpoint.
     *
     * Unlike `connect()`/`run()`, this is a plain JSON POST (not SSE) and does
     * not feed events into the agent's internal `apply` pipeline. The caller
     * (typically `AjoraCore.loadHistory`) decides how to merge the returned
     * messages into the in-memory `messages` array.
     *
     * Throws `FetchHistoryError` for any non-2xx response so the caller can
     * surface auth failures (401/403) distinctly from network errors.
     */
    fetchHistory(request: FetchHistoryRequest): Promise<FetchHistoryResponse>;
    clone(): ProxiedAjoraRuntimeAgent;
    private createSingleRouteRequestInit;
}
