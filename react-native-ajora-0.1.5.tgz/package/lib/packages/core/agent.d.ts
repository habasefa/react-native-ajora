import { BaseEvent, HttpAgent, HttpAgentConfig, RunAgentInput } from "@ag-ui/client";
import { Observable } from "rxjs";
import { AjoraRuntimeTransport } from "./types";
export interface ProxiedAjoraRuntimeAgentConfig extends Omit<HttpAgentConfig, "url"> {
    runtimeUrl?: string;
    transport?: AjoraRuntimeTransport;
}
export declare class ProxiedAjoraRuntimeAgent extends HttpAgent {
    runtimeUrl?: string;
    private transport;
    private singleEndpointUrl?;
    constructor(config: ProxiedAjoraRuntimeAgentConfig);
    abortRun(): void;
    connect(input: RunAgentInput): Observable<BaseEvent>;
    run(input: RunAgentInput): Observable<BaseEvent>;
    clone(): ProxiedAjoraRuntimeAgent;
    private createSingleRouteRequestInit;
}
