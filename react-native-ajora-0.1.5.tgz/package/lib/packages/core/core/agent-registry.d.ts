import { AbstractAgent } from "@ag-ui/client";
import { RuntimeModelInfo } from "../../shared";
import type { AjoraCore } from "./core";
import { AjoraCoreRuntimeConnectionStatus } from "./core-types";
import { AjoraRuntimeTransport } from "../types";
export interface AjoraCoreAddAgentParams {
    id: string;
    agent: AbstractAgent;
}
/**
 * Manages agent registration, lifecycle, and runtime connectivity for AjoraCore.
 * Handles both local development agents and remote runtime agents.
 */
export declare class AgentRegistry {
    private core;
    private _agents;
    private localAgents;
    private remoteAgents;
    private _models;
    private _extraData;
    private _runtimeUrl?;
    private _runtimeVersion?;
    private _runtimeConnectionStatus;
    private _runtimeTransport;
    /** Monotonic counter used to cancel stale `updateRuntimeConnection` calls. */
    private _connectionGeneration;
    constructor(core: AjoraCore);
    /**
     * Get all agents as a readonly record
     */
    get agents(): Readonly<Record<string, AbstractAgent>>;
    get runtimeUrl(): string | undefined;
    get runtimeVersion(): string | undefined;
    get runtimeConnectionStatus(): AjoraCoreRuntimeConnectionStatus;
    get runtimeTransport(): AjoraRuntimeTransport;
    /**
     * Get models received from the runtime
     */
    get models(): Readonly<RuntimeModelInfo[]>;
    /**
     * Get extra data received from the runtime
     */
    get extraData(): Readonly<Record<string, unknown>>;
    /**
     * Initialize agents from configuration
     */
    initialize(agents: Record<string, AbstractAgent>): void;
    /**
     * Set the runtime URL and update connection
     */
    setRuntimeUrl(runtimeUrl: string | undefined): void;
    setRuntimeTransport(runtimeTransport: AjoraRuntimeTransport, options?: {
        skipUpdate?: boolean;
    }): void;
    /**
     * Set all agents at once (for development use)
     */
    setAgents__unsafe_dev_only(agents: Record<string, AbstractAgent>): void;
    /**
     * Add a single agent (for development use)
     */
    addAgent__unsafe_dev_only({ id, agent }: AjoraCoreAddAgentParams): void;
    /**
     * Remove an agent by ID (for development use)
     */
    removeAgent__unsafe_dev_only(id: string): void;
    /**
     * Get an agent by ID
     */
    getAgent(id: string): AbstractAgent | undefined;
    /**
     * Apply current headers to an agent
     */
    applyHeadersToAgent(agent: AbstractAgent): void;
    /**
     * Apply current headers to all agents
     */
    applyHeadersToAgents(agents: Record<string, AbstractAgent>): void;
    /**
     * Update runtime connection and fetch remote agents.
     *
     * Uses a generation counter to cancel stale calls: if `setRuntimeUrl` or
     * `setRuntimeTransport` fires while a previous `updateRuntimeConnection`
     * is in flight, the new call increments the generation and the old call
     * bails at every await point where it checks `myGeneration`.
     */
    private updateRuntimeConnection;
    private fetchRuntimeInfo;
    /**
     * Assign agent IDs to a record of agents
     */
    private assignAgentIds;
    /**
     * Validate and assign an agent ID
     */
    private validateAndAssignAgentId;
    /**
     * Notify subscribers of runtime status changes
     */
    private notifyRuntimeStatusChanged;
    /**
     * Notify subscribers of agent changes
     */
    private notifyAgentsChanged;
    /**
     * Notify subscribers of model changes
     */
    private notifyModelsChanged;
}
