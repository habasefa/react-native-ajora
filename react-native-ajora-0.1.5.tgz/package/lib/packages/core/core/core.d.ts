import { AbstractAgent, Context, State } from "@ag-ui/client";
import type { RuntimeModelInfo } from "../../shared";
import { FrontendTool, SuggestionsConfig, AjoraRuntimeTransport } from "../types";
import { AjoraCoreAddAgentParams } from "./agent-registry";
import { SuggestionEngine, AjoraCoreGetSuggestionsResult } from "./suggestion-engine";
export type { AjoraCoreGetSuggestionsResult };
import { AjoraCoreRunAgentParams, AjoraCoreConnectAgentParams, AjoraCoreLoadHistoryParams, AjoraCoreGetToolParams } from "./run-handler";
import type { FetchHistoryResponse } from "../agent";
import { AjoraCoreErrorCode, AjoraCoreRuntimeConnectionStatus, AjoraCoreSubscriber, AjoraCoreSubscription } from "./core-types";
export { AjoraCoreErrorCode, AjoraCoreRuntimeConnectionStatus, AjoraCoreFriendsAccess, AjoraCoreSubscriber, AjoraCoreSubscription, } from "./core-types";
/** Configuration options for `AjoraCore`. */
export interface AjoraCoreConfig {
    /** The endpoint of the AjoraRuntime. */
    runtimeUrl?: string;
    /** Transport style for AjoraRuntime endpoints. Defaults to REST. */
    runtimeTransport?: AjoraRuntimeTransport;
    /** Mapping from agent name to its `AbstractAgent` instance. For development only - production requires AjoraRuntime. */
    agents__unsafe_dev_only?: Record<string, AbstractAgent>;
    /** Headers appended to every HTTP request made by `AjoraCore`. */
    headers?: Record<string, string>;
    /** Properties sent as `forwardedProps` to the AG-UI agent. */
    properties?: Record<string, unknown>;
    /** Ordered collection of frontend tools available to the core. */
    tools?: FrontendTool<any>[];
    /** Suggestions config for the core. */
    suggestionsConfig?: SuggestionsConfig[];
}
export type { AjoraCoreAddAgentParams };
export type { AjoraCoreRunAgentParams, AjoraCoreConnectAgentParams, AjoraCoreLoadHistoryParams, AjoraCoreGetToolParams, };
export type { FetchHistoryResponse } from "../agent";
export interface AjoraCoreStopAgentParams {
    agent: AbstractAgent;
}
export declare class AjoraCore {
    private _headers;
    private _properties;
    private subscribers;
    /** Cleanup handle for the internal onAgentsChanged subscription. */
    private _agentsChangedSubscription;
    private agentRegistry;
    private contextStore;
    /** @internal — accessed by delegate classes via `AjoraCoreFriendsAccess`. */
    readonly suggestionEngine: SuggestionEngine;
    private runHandler;
    private stateManager;
    constructor({ runtimeUrl, runtimeTransport, headers, properties, agents__unsafe_dev_only, tools, suggestionsConfig, }: AjoraCoreConfig);
    /**
     * Tear down internal subscriptions. Call this when the AjoraCore instance
     * is no longer needed (e.g. on provider unmount) to avoid memory leaks.
     */
    dispose(): void;
    /**
     * @internal — used by delegate classes to notify subscribers.
     */
    notifySubscribers(handler: (subscriber: AjoraCoreSubscriber) => void | Promise<void>, errorMessage: string): Promise<void>;
    /**
     * @internal — used by delegate classes to emit errors.
     */
    emitError({ error, code, context, }: {
        error: Error;
        code: AjoraCoreErrorCode;
        context?: Record<string, any>;
    }): Promise<void>;
    /**
     * Snapshot accessors
     */
    get context(): Readonly<Record<string, Context>>;
    get agents(): Readonly<Record<string, AbstractAgent>>;
    get tools(): Readonly<FrontendTool<any>[]>;
    get runtimeUrl(): string | undefined;
    setRuntimeUrl(runtimeUrl: string | undefined): void;
    get runtimeTransport(): AjoraRuntimeTransport;
    setRuntimeTransport(runtimeTransport: AjoraRuntimeTransport): void;
    get runtimeVersion(): string | undefined;
    get headers(): Readonly<Record<string, string>>;
    get properties(): Readonly<Record<string, unknown>>;
    get runtimeConnectionStatus(): AjoraCoreRuntimeConnectionStatus;
    get models(): Readonly<RuntimeModelInfo[]>;
    get extraData(): Readonly<Record<string, unknown>>;
    /**
     * Configuration updates
     *
     * Both `setHeaders` and `setProperties` short-circuit on shallow equality.
     * React callers typically pass freshly-constructed objects on every render
     * (e.g. `{ Authorization: ... }`), and the consumer expects the subscribers
     * to only fire on semantic changes — not on reference-only updates. Without
     * the shallow check, every render would cascade into
     * `onHeadersChanged`/`onPropertiesChanged` → `useAjora` forceUpdate →
     * `useAgent` memo recompute → AjoraChat connect effect re-fire.
     */
    setHeaders(headers: Record<string, string>): void;
    setProperties(properties: Record<string, unknown>): void;
    /**
     * Agent management (delegated to AgentRegistry)
     */
    setAgents__unsafe_dev_only(agents: Record<string, AbstractAgent>): void;
    addAgent__unsafe_dev_only(params: AjoraCoreAddAgentParams): void;
    removeAgent__unsafe_dev_only(id: string): void;
    getAgent(id: string): AbstractAgent | undefined;
    /**
     * Context management (delegated to ContextStore)
     */
    addContext(context: Context): string;
    removeContext(id: string): void;
    /**
     * Suggestions management (delegated to SuggestionEngine)
     */
    addSuggestionsConfig(config: SuggestionsConfig): string;
    removeSuggestionsConfig(id: string): void;
    reloadSuggestions(agentId: string): void;
    clearSuggestions(agentId: string): void;
    getSuggestions(agentId: string): AjoraCoreGetSuggestionsResult;
    /**
     * Tool management (delegated to RunHandler)
     */
    addTool<T extends Record<string, unknown> = Record<string, unknown>>(tool: FrontendTool<T>): void;
    removeTool(id: string, agentId?: string): void;
    getTool(params: AjoraCoreGetToolParams): FrontendTool<any> | undefined;
    setTools(tools: FrontendTool<any>[]): void;
    /**
     * Subscription lifecycle
     */
    subscribe(subscriber: AjoraCoreSubscriber): AjoraCoreSubscription;
    /**
     * Agent connectivity (delegated to RunHandler)
     */
    connectAgent(params: AjoraCoreConnectAgentParams): Promise<import("@ag-ui/client").RunAgentResult>;
    stopAgent(params: AjoraCoreStopAgentParams): void;
    runAgent(params: AjoraCoreRunAgentParams): Promise<import("@ag-ui/client").RunAgentResult>;
    /**
     * Load persisted history for a thread and merge it into the agent's
     * in-memory `messages` array. See {@link RunHandler.loadHistory}.
     */
    loadHistory(params: AjoraCoreLoadHistoryParams): Promise<FetchHistoryResponse>;
    /**
     * State management (delegated to StateManager)
     */
    getStateByRun(agentId: string, threadId: string, runId: string): State | undefined;
    getRunIdForMessage(agentId: string, threadId: string, messageId: string): string | undefined;
    getRunIdsForThread(agentId: string, threadId: string): string[];
    /**
     * @internal — used by delegate classes to build frontend tools.
     */
    buildFrontendTools(agentId?: string): import("@ag-ui/client").Tool[];
}
