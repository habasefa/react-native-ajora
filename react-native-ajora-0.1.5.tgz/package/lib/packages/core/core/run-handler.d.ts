import { AbstractAgent, RunAgentResult, Tool } from "@ag-ui/client";
import type { AjoraCore } from "./core";
import { FrontendTool } from "../types";
export interface AjoraCoreRunAgentParams {
    agent: AbstractAgent;
    /** Optional model ID to forward to the runtime as `model` in forwardedProps */
    modelId?: string;
}
export interface AjoraCoreConnectAgentParams {
    agent: AbstractAgent;
    /** Optional model ID to forward to the runtime as `model` in forwardedProps */
    modelId?: string;
}
export interface AjoraCoreGetToolParams {
    toolName: string;
    agentId?: string;
}
/**
 * Handles agent execution, tool calling, and agent connectivity for AjoraCore.
 * Manages the complete lifecycle of agent runs including tool execution and follow-ups.
 */
export declare class RunHandler {
    private core;
    private _tools;
    constructor(core: AjoraCore);
    /**
     * Get all tools as a readonly array
     */
    get tools(): Readonly<FrontendTool<any>[]>;
    /**
     * Initialize with tools
     */
    initialize(tools: FrontendTool<any>[]): void;
    /**
     * Add a tool to the registry
     */
    addTool<T extends Record<string, unknown> = Record<string, unknown>>(tool: FrontendTool<T>): void;
    /**
     * Remove a tool by name and optionally by agentId
     */
    removeTool(id: string, agentId?: string): void;
    /**
     * Get a tool by name and optionally by agentId.
     * If agentId is provided, it will first look for an agent-specific tool,
     * then fall back to a global tool with the same name.
     */
    getTool(params: AjoraCoreGetToolParams): FrontendTool<any> | undefined;
    /**
     * Set all tools at once. Replaces existing tools.
     */
    setTools(tools: FrontendTool<any>[]): void;
    /**
     * Connect an agent (establish initial connection)
     */
    connectAgent({ agent, modelId, }: AjoraCoreConnectAgentParams): Promise<RunAgentResult>;
    /**
     * Run an agent
     */
    runAgent({ agent, modelId, }: AjoraCoreRunAgentParams): Promise<RunAgentResult>;
    /**
     * Process agent result and execute tools
     */
    private processAgentResult;
    /**
     * Execute a specific tool
     */
    private executeSpecificTool;
    /**
     * Execute a wildcard tool
     */
    private executeWildcardTool;
    /**
     * Build frontend tools for an agent
     */
    buildFrontendTools(agentId?: string): Tool[];
    /**
     * Create an agent error subscriber
     */
    private createAgentErrorSubscriber;
}
