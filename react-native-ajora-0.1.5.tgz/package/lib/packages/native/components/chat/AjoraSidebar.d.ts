import React from "react";
import { AjoraChatProps } from "./AjoraChat";
import { AjoraSidebarViewProps } from "./AjoraSidebarView";
export type AjoraSidebarProps = Omit<AjoraChatProps, "chatView"> & {
    header?: AjoraSidebarViewProps["header"];
    defaultOpen?: boolean;
};
export declare function AjoraSidebar({ header, defaultOpen, ...chatProps }: AjoraSidebarProps): React.JSX.Element;
export declare namespace AjoraSidebar {
    var displayName: string;
}
export default AjoraSidebar;
