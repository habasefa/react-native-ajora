import React from "react";
import { StyleProp, ViewStyle } from "react-native";
import { AjoraChatViewProps } from "./AjoraChatView";
import { AjoraModalHeader } from "./AjoraModalHeader";
import { SlotValue } from "../../lib/slots";
export type AjoraSidebarViewProps = AjoraChatViewProps & {
    header?: SlotValue<typeof AjoraModalHeader>;
    style?: StyleProp<ViewStyle>;
};
export declare function AjoraSidebarView({ header, style, ...props }: AjoraSidebarViewProps): React.JSX.Element;
export declare namespace AjoraSidebarView {
    var displayName: string;
}
export default AjoraSidebarView;
