import { DynamicSuggestionsConfig, StaticSuggestionsConfig, Suggestion } from "../../core";
export type StaticSuggestionInput = Omit<Suggestion, "isLoading"> & Partial<Pick<Suggestion, "isLoading">>;
export type StaticSuggestionsConfigInput = Omit<StaticSuggestionsConfig, "suggestions"> & {
    suggestions: StaticSuggestionInput[];
};
export type SuggestionsConfigInput = DynamicSuggestionsConfig | StaticSuggestionsConfigInput;
export declare function useConfigureSuggestions(config: SuggestionsConfigInput | null | undefined, deps?: ReadonlyArray<unknown>): void;
