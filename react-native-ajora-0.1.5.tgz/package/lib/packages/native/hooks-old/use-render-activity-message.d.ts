import { ActivityMessage } from "@ag-ui/core";
import React from "react";
export declare function useRenderActivityMessage(): (message: ActivityMessage) => React.ReactElement | null;
