import { ReactCustomMessageRendererPosition } from "../types";
import { Message } from "@ag-ui/core";
import React from "react";
interface UseRenderCustomMessagesParams {
    message: Message;
    position: ReactCustomMessageRendererPosition;
}
export declare function useRenderCustomMessages(): ((params: UseRenderCustomMessagesParams) => React.JSX.Element | null) | null;
export {};
