import React from "react";
import { ToolCall, ToolMessage } from "@ag-ui/core";
export interface UseRenderToolCallProps {
    toolCall: ToolCall;
    toolMessage?: ToolMessage;
}
export declare function useRenderToolCall(): ({ toolCall, toolMessage, }: UseRenderToolCallProps) => React.ReactElement | null;
