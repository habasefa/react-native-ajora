import { Suggestion } from "../../core";
export interface UseSuggestionsOptions {
    agentId?: string;
}
export interface UseSuggestionsResult {
    suggestions: Suggestion[];
    reloadSuggestions: () => void;
    clearSuggestions: () => void;
    isLoading: boolean;
}
export declare function useSuggestions({ agentId, }?: UseSuggestionsOptions): UseSuggestionsResult;
