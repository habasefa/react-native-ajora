import React, { ReactNode } from "react";
export declare const AjoraChatDefaultLabels: {
    chatInputPlaceholder: string;
    chatInputToolbarStartTranscribeButtonLabel: string;
    chatInputToolbarCancelTranscribeButtonLabel: string;
    chatInputToolbarFinishTranscribeButtonLabel: string;
    chatInputToolbarAddButtonLabel: string;
    chatInputToolbarToolsButtonLabel: string;
    assistantMessageToolbarCopyCodeLabel: string;
    assistantMessageToolbarCopyCodeCopiedLabel: string;
    assistantMessageToolbarCopyMessageLabel: string;
    assistantMessageToolbarThumbsUpLabel: string;
    assistantMessageToolbarThumbsDownLabel: string;
    assistantMessageToolbarReadAloudLabel: string;
    assistantMessageToolbarRegenerateLabel: string;
    userMessageToolbarCopyMessageLabel: string;
    userMessageToolbarEditMessageLabel: string;
    chatDisclaimerText: string;
    chatToggleOpenLabel: string;
    chatToggleCloseLabel: string;
    modalHeaderTitle: string;
    chatHeaderTitle: string;
    chatHeaderMenuButtonLabel: string;
    chatHeaderNewThreadButtonLabel: string;
    threadDrawerTitle: string;
    threadDrawerNewButtonLabel: string;
    threadDrawerEmptyTitle: string;
    threadDrawerEmptySubtitle: string;
    threadDrawerDeleteConfirmTitle: string;
    threadDrawerDeleteConfirmMessage: string;
    threadDrawerDeleteConfirmButton: string;
    threadDrawerDeleteCancelButton: string;
    chatEmptyStateTitle: string;
    chatEmptyStateSubtitle: string;
    chatLoadingConnecting: string;
    chatLoadingMessages: string;
    chatLoadingThinking: string;
    chatLoadingReconnecting: string;
};
export type AjoraChatLabels = typeof AjoraChatDefaultLabels;
export interface AjoraChatConfigurationValue {
    labels: AjoraChatLabels;
    agentId: string;
    threadId: string;
    modelId: string;
    isModalDefaultOpen: boolean;
    isModalOpen: boolean;
    setModalOpen: (open: boolean) => void;
}
export interface AjoraChatConfigurationProviderProps {
    children: ReactNode;
    labels?: Partial<AjoraChatLabels>;
    agentId?: string;
    threadId?: string;
    modelId?: string;
    isModalDefaultOpen?: boolean;
}
export declare const AjoraChatConfigurationProvider: React.FC<AjoraChatConfigurationProviderProps>;
export declare const useAjoraChatConfiguration: () => AjoraChatConfigurationValue | null;
