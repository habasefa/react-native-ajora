export declare const DEFAULT_AGENT_ID = "default";
export declare const DEFAULT_MODEL_ID = "default";
