import { BaseEvent } from "@ag-ui/client";
interface FinalizeRunOptions {
    stopRequested?: boolean;
    interruptionMessage?: string;
}
export declare function finalizeRunEvents(events: BaseEvent[], options?: FinalizeRunOptions): BaseEvent[];
export {};
