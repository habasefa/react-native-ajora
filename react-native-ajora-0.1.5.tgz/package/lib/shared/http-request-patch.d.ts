/**
 * Patch for runHttpRequest to support React Native streaming via expo/fetch
 * This is a temporary workaround until ag-ui is fixed
 */
import { Observable } from "rxjs";
declare enum HttpEventType {
    HEADERS = "headers",
    DATA = "data"
}
interface HttpDataEvent {
    type: HttpEventType.DATA;
    data?: Uint8Array;
}
interface HttpHeadersEvent {
    type: HttpEventType.HEADERS;
    status: number;
    headers: Headers;
}
type HttpEvent = HttpDataEvent | HttpHeadersEvent;
/**
 * Patched version of runHttpRequest that uses expo/fetch in React Native
 * This fixes the "Failed to getReader() from response" error
 */
export declare function patchedRunHttpRequest(url: string, requestInit: RequestInit, originalRunHttpRequest: (url: string, requestInit: RequestInit) => Observable<HttpEvent>): Observable<HttpEvent>;
export {};
