export declare function randomUUID(): string;
export declare function partialJSONParse(json: string): any;
