// @ts-nocheck
import * as React from "react";
import { View, StyleSheet, StyleProp, ViewStyle } from "react-native";
import { renderSlot, WithSlots } from "../../lib/slots";
import AjoraChatAssistantMessage from "./AjoraChatAssistantMessage";
import AjoraChatUserMessage from "./AjoraChatUserMessage";
import AjoraChatThinkingIndicator from "./AjoraChatThinkingIndicator";
import {
  ActivityMessage,
  AssistantMessage,
  Message,
  UserMessage,
} from "@ag-ui/core";
import { useRenderActivityMessage, useRenderCustomMessages } from "../../hooks";
import AjoraChatErrorMessage from "./AjoraChatErrorMessage";

const MemoizedAssistantMessage = React.memo(
  function MemoizedAssistantMessage({
    message,
    messages,
    isRunning,
    onRegenerate,
    AssistantMessageComponent,
    textRenderer,
  }: {
    message: AssistantMessage;
    messages: Message[];
    isRunning: boolean;
    onRegenerate?: (message: AssistantMessage) => void;
    AssistantMessageComponent: typeof AjoraChatAssistantMessage;
    textRenderer?: (props: { content: string }) => React.ReactNode;
  }) {
    return (
      <AssistantMessageComponent
        message={message}
        messages={messages}
        isRunning={isRunning}
        onRegenerate={onRegenerate}
        textRenderer={textRenderer}
      />
    );
  },
  (prevProps, nextProps) => {
    if (prevProps.message.id !== nextProps.message.id) return false;
    if (prevProps.message.content !== nextProps.message.content) return false;

    const prevToolCalls = prevProps.message.toolCalls;
    const nextToolCalls = nextProps.message.toolCalls;
    if (prevToolCalls?.length !== nextToolCalls?.length) return false;

    if (prevToolCalls && nextToolCalls) {
      for (let i = 0; i < prevToolCalls.length; i++) {
        const prevTc = prevToolCalls[i];
        const nextTc = nextToolCalls[i];
        if (!prevTc || !nextTc) return false;
        if (prevTc.id !== nextTc.id) return false;
        if (prevTc.function.arguments !== nextTc.function.arguments)
          return false;
      }
    }

    if (prevToolCalls && prevToolCalls.length > 0) {
      const toolCallIds = new Set(prevToolCalls.map((tc) => tc.id));

      const prevToolResults = prevProps.messages.filter(
        (m) => m.role === "tool" && toolCallIds.has((m as any).toolCallId),
      );
      const nextToolResults = nextProps.messages.filter(
        (m) => m.role === "tool" && toolCallIds.has((m as any).toolCallId),
      );

      if (prevToolResults.length !== nextToolResults.length) return false;

      for (let i = 0; i < prevToolResults.length; i++) {
        if (
          (prevToolResults[i] as any).content !==
          (nextToolResults[i] as any).content
        )
          return false;
      }
    }

    const nextIsLatest =
      nextProps.messages[nextProps.messages.length - 1]?.id ===
      nextProps.message.id;
    if (nextIsLatest && prevProps.isRunning !== nextProps.isRunning)
      return false;

    if (
      prevProps.AssistantMessageComponent !==
      nextProps.AssistantMessageComponent
    )
      return false;

    if (prevProps.textRenderer !== nextProps.textRenderer) return false;

    return true;
  },
);

const MemoizedUserMessage = React.memo(
  function MemoizedUserMessage({
    message,
    UserMessageComponent,
    onLongPress,
    textRenderer,
  }: {
    message: UserMessage;
    UserMessageComponent: typeof AjoraChatUserMessage;
    onLongPress?: (message: UserMessage) => void;
    textRenderer?: (props: { content: string }) => React.ReactNode;
  }) {
    return (
      <UserMessageComponent
        message={message}
        onLongPress={onLongPress ? () => onLongPress(message) : undefined}
        textRenderer={textRenderer}
      />
    );
  },
  (prevProps, nextProps) => {
    if (prevProps.message.id !== nextProps.message.id) return false;
    if (prevProps.message.content !== nextProps.message.content) return false;
    if (prevProps.UserMessageComponent !== nextProps.UserMessageComponent)
      return false;
    if (prevProps.textRenderer !== nextProps.textRenderer) return false;
    return true;
  },
);

const MemoizedActivityMessage = React.memo(
  function MemoizedActivityMessage({
    message,
    renderActivityMessage,
  }: {
    message: ActivityMessage;
    renderActivityMessage: (
      message: ActivityMessage,
    ) => React.ReactElement | null;
  }) {
    return renderActivityMessage(message);
  },
  (prevProps, nextProps) => {
    if (prevProps.message.id !== nextProps.message.id) return false;
    if (prevProps.message.activityType !== nextProps.message.activityType)
      return false;
    if (
      JSON.stringify(prevProps.message.content) !==
      JSON.stringify(nextProps.message.content)
    )
      return false;
    return true;
  },
);

const MemoizedCustomMessage = React.memo(
  function MemoizedCustomMessage({
    message,
    position,
    renderCustomMessage,
  }: {
    message: Message;
    position: "before" | "after";
    renderCustomMessage: (params: {
      message: Message;
      position: "before" | "after";
    }) => React.ReactElement | null;
  }) {
    return renderCustomMessage({ message, position });
  },
  (prevProps, nextProps) => {
    if (prevProps.message.id !== nextProps.message.id) return false;
    if (prevProps.position !== nextProps.position) return false;
    if (prevProps.message.content !== nextProps.message.content) return false;
    if (prevProps.message.role !== nextProps.message.role) return false;
    return true;
  },
);

export type AjoraChatMessageViewProps = Omit<
  WithSlots<
    {
      assistantMessage: typeof AjoraChatAssistantMessage;
      userMessage: typeof AjoraChatUserMessage;
      thinkingIndicator: typeof AjoraChatThinkingIndicator;
      errorMessage: typeof AjoraChatErrorMessage;
    },
    {
      isRunning?: boolean;
      messages?: Message[];
      onRegenerate?: (message: AssistantMessage) => void;
      onMessageLongPress?: (message: Message) => void;
      textRenderer?: (props: { content: string }) => React.ReactNode;
      /** Whether to show the thinking indicator when isRunning is true */
      showThinkingIndicator?: boolean;
      /** Error message to display at the bottom of the chat */
      error?: string | null;
      /** Callback to retry the agent run upon an error */
      onRetryError?: () => void;
      style?: StyleProp<ViewStyle>;
    }
  >,
  "children"
> & {
  children?: (props: {
    isRunning: boolean;
    messages: Message[];
    messageElements: React.ReactElement[];
    thinkingIndicator: React.ReactElement | null;
  }) => React.ReactElement;
};

/**
 * Stable per-message renderer suitable for both the legacy `<View>`-based
 * `AjoraChatMessageView` and FlashList's `renderItem`. Returns a single
 * React element per message (custom-before + main + custom-after wrapped
 * in a Fragment) so FlashList can virtualize one cell per data row.
 *
 * Pulled out of `AjoraChatMessageView` so the FlashList code path inside
 * `AjoraChatViewInner` doesn't need to construct the entire `messageElements`
 * array up-front — that defeats virtualization.
 */
export function useRenderMessage({
  messages,
  isRunning,
  assistantMessage,
  userMessage,
  onRegenerate,
  onMessageLongPress,
  textRenderer,
}: {
  messages: Message[];
  isRunning: boolean;
  assistantMessage?: AjoraChatMessageViewProps["assistantMessage"];
  userMessage?: AjoraChatMessageViewProps["userMessage"];
  onRegenerate?: (message: AssistantMessage) => void;
  onMessageLongPress?: (message: Message) => void;
  textRenderer?: (props: { content: string }) => React.ReactNode;
}) {
  const renderCustomMessage = useRenderCustomMessages();
  const renderActivityMessage = useRenderActivityMessage();

  return React.useCallback(
    (message: Message, _index: number): React.ReactElement | null => {
      const parts: React.ReactElement[] = [];

      if (renderCustomMessage) {
        parts.push(
          <MemoizedCustomMessage
            key={`${message.id}-custom-before`}
            message={message}
            position="before"
            renderCustomMessage={renderCustomMessage}
          />,
        );
      }

      if (message.role === "assistant") {
        const AssistantComponent = (
          typeof assistantMessage === "function"
            ? assistantMessage
            : AjoraChatAssistantMessage
        ) as typeof AjoraChatAssistantMessage;

        parts.push(
          <MemoizedAssistantMessage
            key={message.id}
            message={message as AssistantMessage}
            messages={messages}
            isRunning={isRunning}
            onRegenerate={onRegenerate}
            AssistantMessageComponent={AssistantComponent}
            textRenderer={textRenderer}
          />,
        );
      } else if (message.role === "user") {
        const UserComponent = (
          typeof userMessage === "function" ? userMessage : AjoraChatUserMessage
        ) as typeof AjoraChatUserMessage;

        parts.push(
          <MemoizedUserMessage
            key={message.id}
            message={message as UserMessage}
            UserMessageComponent={UserComponent}
            onLongPress={onMessageLongPress}
            textRenderer={textRenderer}
          />,
        );
      } else if (message.role === "activity") {
        parts.push(
          <MemoizedActivityMessage
            key={message.id}
            message={message as ActivityMessage}
            renderActivityMessage={renderActivityMessage}
          />,
        );
      }

      if (renderCustomMessage) {
        parts.push(
          <MemoizedCustomMessage
            key={`${message.id}-custom-after`}
            message={message}
            position="after"
            renderCustomMessage={renderCustomMessage}
          />,
        );
      }

      if (parts.length === 0) return null;
      return <React.Fragment key={message.id}>{parts}</React.Fragment>;
    },
    [
      assistantMessage,
      userMessage,
      messages,
      isRunning,
      onRegenerate,
      onMessageLongPress,
      textRenderer,
      renderCustomMessage,
      renderActivityMessage,
    ],
  );
}

/**
 * Deduplicate messages by id, keeping the most recent occurrence. FlashList
 * requires unique keys, and streaming sometimes emits the same message id
 * multiple times before settling. Exposed so the FlashList callsite can
 * dedupe before passing `data` instead of relying on this component.
 */
export function dedupeMessagesById(messages: Message[]): Message[] {
  const seen = new Map<string, Message>();
  for (const message of messages) {
    seen.set(message.id, message);
  }
  return Array.from(seen.values());
}

export function AjoraChatMessageView({
  messages = [],
  assistantMessage,
  userMessage,
  thinkingIndicator,
  errorMessage,
  isRunning = false,
  showThinkingIndicator = true,

  onRegenerate,
  onMessageLongPress,
  textRenderer,
  children,
  style,
  error,
  onRetryError,
  ...props
}: AjoraChatMessageViewProps) {
  // Determine if we should show the thinking indicator
  // Show when running, except when waiting for tool execution (isToolCall).
  // We WANT to show it after tool execution ends (isToolResult), so we don't exclude that.
  const lastMessage = messages[messages.length - 1];

  // Check for tool call states
  const isToolCall =
    lastMessage?.role === "assistant" &&
    Array.isArray((lastMessage as any).toolCalls) &&
    (lastMessage as any).toolCalls.length > 0;

  const shouldShowThinking = showThinkingIndicator && isRunning && !isToolCall;

  // Render the thinking indicator using the slot system
  const boundThinkingIndicator = shouldShowThinking
    ? renderSlot(thinkingIndicator, AjoraChatThinkingIndicator, {
        isThinking: true,
      })
    : null;

  const deduplicatedMessages = React.useMemo(
    () => dedupeMessagesById(messages),
    [messages],
  );

  const renderMessage = useRenderMessage({
    messages,
    isRunning,
    assistantMessage,
    userMessage,
    onRegenerate,
    onMessageLongPress,
    textRenderer,
  });

  const messageElements: React.ReactElement[] = deduplicatedMessages
    .map((message, index) => renderMessage(message, index))
    .filter(Boolean) as React.ReactElement[];

  if (error) {
    const BoundErrorMessage = renderSlot(errorMessage, AjoraChatErrorMessage, {
      message: error,
      onRetry: onRetryError,
    });

    if (BoundErrorMessage) {
      messageElements.push(
        <React.Fragment key="error-message">
          {BoundErrorMessage}
        </React.Fragment>,
      );
    }
  }

  if (children) {
    return children({
      messageElements,
      messages,
      isRunning,
      thinkingIndicator: boundThinkingIndicator,
    });
  }

  return (
    <View style={[styles.container, style]} {...props}>
      {messageElements}
      {boundThinkingIndicator}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "column",
  },
});

export default AjoraChatMessageView;
